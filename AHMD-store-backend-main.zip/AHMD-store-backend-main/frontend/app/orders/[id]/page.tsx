import { STRAPI_URL } from "@/lib/strapi";
import Link from "next/link";
import { notFound } from "next/navigation";

interface OrderPageProps {
  params: Promise<{ id: string }>;
}


async function getOrder(id: string) {
  const strapiUrl = STRAPI_URL;

  try {
    const res = await fetch(`${strapiUrl}/api/orders/${id}?populate=*`, {
      cache: "no-store",
    });

    if (!res.ok) {
   
      const searchRes = await fetch(
        `${strapiUrl}/api/orders?filters[orderId][$eq]=${id}&populate=*`,
        { cache: "no-store" }
      );
      if (!searchRes.ok) return null;
      const searchData = await searchRes.json();
      return searchData.data?.[0] || null;
    }

    const data = await res.json();
    return data.data || null;
  } catch (err) {
    console.error("Error fetching order from Strapi:", err);
    return null;
  }
}

const OrderPage = async ({ params }: OrderPageProps) => {
  const { id } = await params;
  const orderData = await getOrder(id);

  if (!orderData) {
    return notFound();
  }

  
  const order = orderData.attributes || orderData;
  const orderId = order.orderId || orderData.id || orderData.documentId;

  const receiverName =
    order.receiverName ||
    `${order.firstName || ""} ${order.lastName || ""}`.trim() ||
    "غير متوفر";

  const deliveryAddress =
    order.deliveryAddress ||
    order.address ||
    `${order.addressLine1 || ""} ${order.city || ""}`.trim() ||
    "غير متوفر";

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] items-center justify-center">
      <div className="shadow-[rgba(0,_0,_0,_0.25)_0px_25px_50px_-12px] px-40 py-20">
        <h1 className="text-xl">تفاصيل الطلب</h1>
        <div className="mt-12 flex flex-col gap-6">
          <div className="">
            <span className="font-medium">رقم الطلب: </span>
            <span>{orderId}</span>
          </div>
          <div className="">
            <span className="font-medium">اسم المستلم: </span>
            <span>{receiverName}</span>
          </div>
          <div className="">
            <span className="font-medium">بريد المستلم: </span>
            <span>{order.email || order.buyerEmail || "غير متوفر"}</span>
          </div>
          <div className="">
            <span className="font-medium">السعر: </span>
            <span>{order.totalPrice || order.amount || 0} دج</span>
          </div>
          <div className="">
            <span className="font-medium">حالة الدفع: </span>
            <span>{order.paymentStatus || order.status || "قيد الانتظار"}</span>
          </div>
          <div className="">
            <span className="font-medium">حالة الطلب: </span>
            <span>{order.orderStatus || order.status || "قيد المعالجة"}</span>
          </div>
          <div className="">
            <span className="font-medium">عنوان التوصيل: </span>
            <span>{deliveryAddress}</span>
          </div>
        </div>
      </div>
      <Link href="/contact" className="underline mt-6">
        تواجه مشكلة؟ اتصل بنا
      </Link>
    </div>
  );
};

export default OrderPage;