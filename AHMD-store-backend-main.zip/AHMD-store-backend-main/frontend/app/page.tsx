import NewArrivalsSection from "@/components/NewArrivalsSection";
import BestSellersSection from "@/components/BestSellersSection";
import CategoryList from "@/components/CategoryList";

export const dynamic = "force-dynamic";

const HomePage = () => {
  return (
    <div>
      {/* New Arrivals Section */}
      <NewArrivalsSection />

      {/* Best Sellers Section */}
      <BestSellersSection />

      {/* Categories from Strapi */}
      <CategoryList />
    </div>
  );
};

export default HomePage;
