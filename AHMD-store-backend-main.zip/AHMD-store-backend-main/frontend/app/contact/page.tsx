import type { Metadata } from "next";
import { Mail } from "lucide-react";
import { FacebookIcon, InstagramIcon } from "@/components/SocialIcons";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: `اتصل بنا — ${SITE.name}`,
  description: `تواصل مع ${SITE.name} عبر البريد أو فيسبوك أو إنستغرام.`,
};

const channels = [
  {
    label: "البريد الإلكتروني",
    value: SITE.email,
    href: `mailto:${SITE.email}`,
    description: "",
    icon: Mail,
  },
  {
    label: "Facebook",
    value: "auraShop",
    href: SITE.facebookUrl,
    description: "",
    icon: FacebookIcon,
  },
  {
    label: "Instagram",
    value: "@aurashop",
    href: SITE.instagramUrl,
    description: "",
    icon: InstagramIcon,
  },
];

export default function ContactPage() {
  return (
    <div className="page-wrap py-14 md:py-20">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <p className="section-kicker">خدمة الزبائن</p>
        <h1 className="section-title text-4xl md:text-5xl mb-4">اتصل بنا</h1>
        <p className="text-muted leading-relaxed">
          سؤال عن منتج أو طلب أو التوصيل؟ فريقنا يرد عليك بسرعة.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto">
        {channels.map((channel) => {
          const Icon = channel.icon;
          return (
            <a
              key={channel.label}
              href={channel.href}
              target={channel.href.startsWith("http") ? "_blank" : undefined}
              rel={channel.href.startsWith("http") ? "noreferrer" : undefined}
              className="surface-card p-6 flex flex-col items-center text-center gap-3 hover:border-brand/30 transition"
            >
              <span className="h-12 w-12 rounded-full bg-cream text-brand flex items-center justify-center">
                <Icon className="w-5 h-5" />
              </span>
              <p className="text-xs text-muted">{channel.label}</p>
              <p className="font-medium text-ink">{channel.value}</p>
              {channel.description && <p className="text-sm text-muted">{channel.description}</p>}
            </a>
          );
        })}
      </div>
    </div>
  );
}
