import Filter from "@/components/Filter";
import ProductList from "@/components/ProductList";
import Skeleton from "@/components/Skeleton";
import { Suspense } from "react";
import { STRAPI_URL } from "@/lib/strapi";

async function getCategoryBySlug(slug: string) {
  try {
    const res = await fetch(
      `${STRAPI_URL}/api/categories?filters[slug][$eq]=${slug}`,
      { cache: "no-store" },
    );

    if (!res.ok) return null;
    const data = await res.json();
    return data.data?.[0] || null;
  } catch (err) {
    console.error("Error fetching category from Strapi:", err);
    return null;
  }
}

const ListPage = async ({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) => {
  const resolvedSearchParams = await searchParams;
  const categorySlug = (resolvedSearchParams.cat as string) || "all-products";

  const categoryData = await getCategoryBySlug(categorySlug);

  const category = categoryData?.attributes || categoryData;
  const categoryId = categoryData?.id || categoryData?.documentId || "all";
  const categoryName = category?.name || category?.title || "كل المنتجات";
  const categoryDescription = category?.description || "";

  return (
    <div className="py-12 md:py-16 bg-white">
      <div className="page-wrap">
        <Suspense fallback={<div className="mt-10 h-10" />}>
          <Filter />
        </Suspense>

        <div className="mt-8 md:mt-10">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
            {categoryName}
          </h1>
          {categoryDescription && (
            <p className="text-gray-500 text-sm md:text-base">
              {categoryDescription}
            </p>
          )}
        </div>

        <Suspense fallback={<Skeleton />}>
          <ProductList
            categoryId={categoryId}
            searchParams={resolvedSearchParams}
          />
        </Suspense>
      </div>
    </div>
  );
};

export default ListPage;
