import Image from "next/image";
import Link from "next/link";
import { getImageUrl, STRAPI_URL, unwrapStrapi } from "@/lib/strapi";

type Category = {
  id: string;
  documentId?: string;
  name?: string;
  title?: string;
  slug?: string;
  description?: string;
  image?: any;
  media?: any;
};

async function getCategories() {
  try {
    const res = await fetch(`${STRAPI_URL}/api/categories?populate=*`, {
      next: { revalidate: 60 },
    });
    const data = await res.json();
    return data.data || [];
  } catch (err) {
    console.error("Error fetching categories from Strapi:", err);
    return [];
  }
}

const CategoriesPage = async () => {
  const categories: Category[] = await getCategories();

  return (
    <div className="py-12 md:py-16 bg-white">
      <div className="page-wrap">
        <div className="text-right mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
            جميع التصنيفات
          </h1>
          <p className="text-gray-500 text-sm md:text-base">
            تصفح جميع الأقسام بالتفصيل واختر القسم الذي تريده
          </p>
        </div>

        <div dir="rtl" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-start">
          {categories.map((cat: Category) => {
            const item = unwrapStrapi(cat);
            // Handle new image field and legacy media fields
            const imgData =
              item.image?.data || item.image || 
              item.media?.data || item.media;
            const imageObj = Array.isArray(imgData) ? imgData[0] : imgData;
            const categoryImage = getImageUrl(imageObj, "/category.png");
            const name = item.name || item.title;
            const description = item.description;

            return (
              <Link
                href={`/list?cat=${item.slug || cat.id}`}
                className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-cream-2 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
                key={cat.id || item.documentId}
              >
                <div className="relative w-full aspect-[4/3] overflow-hidden rounded-t-2xl bg-gradient-to-b from-cream to-cream/50">
                  <Image
                    src={categoryImage}
                    alt={name || "تصنيف"}
                    fill
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-ink/20 to-transparent" />
                </div>
                <div className="flex flex-col px-4 sm:px-5 py-4">
                  <h3 className="font-semibold text-gray-800 text-lg line-clamp-1 text-center mb-2 group-hover:text-gray-600 transition-colors duration-300">
                    {name}
                  </h3>
                  {description && (
                    <p className="text-gray-500 text-sm line-clamp-2 text-center">
                      {description}
                    </p>
                  )}
                </div>
              </Link>
            );
          })}
        </div>

        {categories.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">لا توجد تصنيفات حالياً</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoriesPage;
