import type { Metadata } from "next";
import "./globals.css";
import AnnouncementBar from "@/components/AnnouncementBar";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import FacebookPixel from "@/components/FacebookPixel";
import TikTokPixel from "@/components/TikTokPixel";
import FloatingContactButtons from "@/components/FloatingContactButtons";
import { SITE } from "@/lib/site";
import { Cairo, Playfair_Display } from "next/font/google";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
  display: "swap",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

export const metadata: Metadata = {
  title: `${SITE.name} | وجهتك الأولى للتسوق العصري`,
  description: `اكتشف أحدث المنتجات وأفضل العروض حصرياً على ${SITE.name}. تجربة تسوق فريدة، جودة عالية، وتوصيل سريع حتى باب منزلك.`,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" data-scroll-behavior="smooth" className={`${cairo.variable} ${playfair.variable}`}>
      <body className={`${cairo.className} min-h-screen bg-white text-ink antialiased`}>
        <FacebookPixel />
        <TikTokPixel pixelIds={['D2ADR8BC77U3NVKIT0K0']} />

        <AnnouncementBar />
        <Navbar />
        <main>{children}</main>
        <Footer />
        <FloatingContactButtons />
      </body>
    </html>
  );
}