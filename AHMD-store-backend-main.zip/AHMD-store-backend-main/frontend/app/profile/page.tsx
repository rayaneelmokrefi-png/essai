import UpdateButton from "@/components/UpdateButton";
import { updateUser } from "@/lib/actions";
import { STRAPI_URL } from "@/lib/strapi";
import Link from "next/link";
import { format } from "timeago.js";

export const dynamic = "force-dynamic";

async function getUserProfileData() {
  const strapiUrl = STRAPI_URL;

  try {
    const userRes = await fetch(`${strapiUrl}/api/users/me`, {
      headers: {
        Authorization: `Bearer ${process.env.STRAPI_API_TOKEN || process.env.NEXT_PUBLIC_STRAPI_API_TOKEN}`,
      },
      next: { revalidate: 60 },
    });

    if (!userRes.ok) return { user: null, orders: [] };
    const user = await userRes.json();

    // 2. جلب طلبات هذا المستخدم من Strapi
    const ordersRes = await fetch(
      `${strapiUrl}/api/orders?filters[user][id][$eq]=${user.id}&populate=*`,
      { next: { revalidate: 60 } },
    );
    const ordersData = await ordersRes.json();
    const orders = ordersData.data || [];

    return { user, orders };
  } catch (err) {
    console.error("Error fetching profile from Strapi:", err);
    return { user: null, orders: [] };
  }
}

const ProfilePage = async () => {
  const { user, orders } = await getUserProfileData();

  if (!user) {
    return <div className="p-8 text-center text-lg">يرجى تسجيل الدخول</div>;
  }

  return (
    <div className="flex flex-col md:flex-row gap-24 md:h-[calc(100vh-180px)] items-center px-4 md:px-8 lg:px-16 xl:px-32 2xl:px-64">
      <div className="w-full md:w-1/2">
        <h1 className="text-2xl font-semibold">الحساب</h1>
        <form action={updateUser} className="mt-12 flex flex-col gap-4">
          <input
            type="text"
            hidden
            name="id"
            value={user.id}
            defaultValue={user.id}
          />

          <label className="text-sm text-gray-700">اسم المستخدم</label>
          <input
            type="text"
            name="username"
            defaultValue={user.username || ""}
            placeholder={user.username || "john"}
            className="ring-1 ring-gray-300 rounded-md p-2 max-w-96"
          />

          <label className="text-sm text-gray-700">الاسم</label>
          <input
            type="text"
            name="firstName"
            defaultValue={user.firstName || ""}
            placeholder={user.firstName || "John"}
            className="ring-1 ring-gray-300 rounded-md p-2 max-w-96"
          />

          <label className="text-sm text-gray-700">اللقب</label>
          <input
            type="text"
            name="lastName"
            defaultValue={user.lastName || ""}
            placeholder={user.lastName || "Doe"}
            className="ring-1 ring-gray-300 rounded-md p-2 max-w-96"
          />

          <label className="text-sm text-gray-700">الهاتف</label>
          <input
            type="text"
            name="phone"
            defaultValue={user.phone || ""}
            placeholder={user.phone || "+1234567"}
            className="ring-1 ring-gray-300 rounded-md p-2 max-w-96"
          />

          <label className="text-sm text-gray-700">البريد الإلكتروني</label>
          <input
            type="email"
            name="email"
            defaultValue={user.email || ""}
            placeholder={user.email || "john@gmail.com"}
            className="ring-1 ring-gray-300 rounded-md p-2 max-w-96"
          />

          <UpdateButton />
        </form>
      </div>

      <div className="w-full md:w-1/2">
        <h1 className="text-2xl font-semibold">الطلبات</h1>
        <div className="mt-12 flex flex-col">
          {orders.length === 0 ? (
            <p className="text-gray-500">لا توجد طلبات.</p>
          ) : (
            orders.map((item: any) => {
              const order = item.attributes || item;
              const orderId = order.orderId || item.id || item.documentId;
              const price = order.totalPrice || order.amount || 0;
              const date = order.createdAt || order.publishedAt;
              return (
                <Link
                  href={`/orders/${orderId}`}
                  key={orderId}
                  className="flex justify-between px-2 py-6 rounded-md hover:bg-green-50 even:bg-slate-100 text-sm"
                >
                  <span className="w-1/4 truncate">
                    #{String(orderId).substring(0, 10)}
                  </span>
                  <span className="w-1/4">{price} DZD</span>
                  {date && <span className="w-1/4">{format(date)}</span>}
                  <span className="w-1/4 capitalize">
                    {order.status || "Pending"}
                  </span>
                </Link>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
