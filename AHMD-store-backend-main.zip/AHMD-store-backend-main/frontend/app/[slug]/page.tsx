import { redirect } from "next/navigation";

const LegacyProductPage = async ({
  params,
}: {
  params: Promise<{ slug: string }>;
}) => {
  const { slug } = await params;
  redirect(`/products/${encodeURIComponent(slug)}`);
};

export default LegacyProductPage;
