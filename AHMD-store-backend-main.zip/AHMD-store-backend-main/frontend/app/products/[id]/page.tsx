import ProductImages from "@/components/ProductImages";
import ProductOrderForm from "@/components/ProductOrderForm";
import ProductCard from "@/components/ProductCard";
import LandingPageMedia from "@/components/LandingPageMedia";
import ProductFloatingBar from "@/components/ProductFloatingBar";
import FeaturesSection from "@/components/FeaturesSection";
import MetaPixel from "@/components/MetaPixel";
import TikTokPixel from "@/components/TikTokPixel";
import { getProductById, getRelatedProducts } from "@/lib/products";
import { getLandingPageImages } from "@/lib/landingMedia";
import { notFound } from "next/navigation";
import { unwrapStrapi } from "@/lib/strapi";

const ProductPage = async ({
  params,
}: {
  params: Promise<{ id: string }>;
}) => {
  const { id } = await params;
  const product = await getProductById(id);

  if (!product) {
    return notFound();
  }

  const isMielPage = (product.name || product.title || "").toLowerCase().includes("miel");

  const metaPixelIds = product.meta_pixel_ids?.data?.map((pixel: any) => pixel.pixelId || pixel.id) || [];
  const tiktokPixelIds = product.tiktok_pixel_ids?.data?.map((pixel: any) => pixel.pixelId || pixel.id) || [];

  const mediaItems =
    product.images?.data || product.images || product.media || [];

  // Handle both Strapi v4 (attributes.offers) and v5 (offers) response structures
  const offersData = product.offers?.data || product.attributes?.offers?.data || product.offers || product.attributes?.offers || [];
  const offers = Array.isArray(offersData) ? offersData.map((offer: any) => {
    // Only unwrap if it has attributes (Strapi v4 structure), otherwise use as-is (Strapi v5)
    return offer?.attributes ? unwrapStrapi(offer) : offer;
  }) : [];
  const defaultOffer = offers.find((offer: any) => offer.isDefault) || offers[0] || null;
  
  const basePrice = product.price || 0;
  const oldPrice = product.oldPrice || product.originalPrice || null;
  const price = defaultOffer?.price || basePrice;
  const discountedPrice = product.discountedPrice || product.salePrice || price;
  const related = await getRelatedProducts(product);
  const name = product.name || product.title;
  const landingPageImages = getLandingPageImages(product);
  const hasValidOffers = offers && offers.length > 0;

  // Only show discount if oldPrice exists and is greater than current price
  const hasValidDiscount = oldPrice && oldPrice > price && !hasValidOffers;
  
  const calculateDiscountPercentage = (original: number, discounted: number) => {
    if (!original || !discounted || original <= discounted) return 0;
    return Math.round(((original - discounted) / original) * 100);
  };
  
  const discountPercentage = hasValidDiscount ? calculateDiscountPercentage(oldPrice, price) : 0;

  return (
    <div className={`${isMielPage ? '!bg-[#fafaf9]' : ''} ${isMielPage ? 'miel-page' : ''} pb-28 md:pb-32`} style={isMielPage ? { backgroundColor: '#fafaf9' } : {}}>
      <MetaPixel pixelIds={metaPixelIds} />
      <TikTokPixel pixelIds={tiktokPixelIds} />
      <section className="page-wrap pt-5 md:pt-10" style={isMielPage ? { backgroundColor: '#fafaf9' } : {}}>
        <div className="flex flex-col lg:grid lg:grid-cols-2 lg:gap-x-14 lg:gap-y-6 lg:items-start">
          <div className="order-1 lg:col-start-2 lg:row-start-1 flex flex-col gap-3 mb-4 lg:mb-0">
            <h1 className={`font-display text-3xl md:text-4xl ${isMielPage ? 'miel-text-primary' : 'text-ink'}`} style={isMielPage ? { color: '#1c1917' } : {}}>{name}</h1>
            {!hasValidOffers && hasValidDiscount && discountPercentage > 0 ? (
              <div className="flex items-center gap-3 dir-rtl">
                <p className={`text-3xl font-bold ${isMielPage ? 'miel-text-price' : 'text-emerald-800'}`} style={isMielPage ? { color: '#d4820a' } : {}}>
                  {Number(price).toLocaleString("ar-DZ")} دج
                </p>
                <p className="text-lg text-gray-400 line-through">
                  {Number(oldPrice).toLocaleString("ar-DZ")} دج
                </p>
                <span className="bg-red-100 text-red-600 text-xs px-2 py-1 rounded-md font-bold">
                  -{discountPercentage}%
                </span>
              </div>
            ) : !hasValidOffers ? (
              <p className={`text-3xl font-bold ${isMielPage ? 'miel-text-price' : 'text-emerald-800'}`} style={isMielPage ? { color: '#d4820a' } : {}}>
                {Number(price).toLocaleString("ar-DZ")} دج
              </p>
            ) : null}
            {product.description ? (
              <p className={`${isMielPage ? 'miel-text-secondary' : 'text-muted'} leading-relaxed text-sm md:text-base`} style={isMielPage ? { color: '#57534e' } : {}}>
                {product.description}
              </p>
            ) : null}
          </div>

          <div className="order-2 lg:col-start-1 lg:row-start-1 lg:row-span-2 lg:sticky lg:top-28">
            <ProductImages items={mediaItems} />
            <FeaturesSection />
          </div>

          <div className="order-3 lg:col-start-2 lg:row-start-2 mt-6 lg:mt-0">
            <div className={`${isMielPage ? 'miel-surface-card' : 'surface-card'} p-4 sm:p-7 flex flex-col gap-6`} style={isMielPage ? { backgroundColor: '#fff', border: '1px solid #e7e5e4', borderRadius: '1rem' } : {}}>
              <ProductOrderForm
                productName={name}
                productId={id}
                price={price}
                stockNumber={product.stock ?? product.quantity ?? 10}
                variants={product.variants || []}
                productOptions={product.productOptions || []}
                colors={product.colors || []}
                sizes={product.sizes || product.size || []}
                offers={offers}
                basePrice={basePrice}
                isMielPage={isMielPage}
                hasValidOffers={hasValidOffers}
              />

              {product.additionalInfoSections?.map((section: any) => (
                <div className="text-sm" key={section.title}>
                  <h4 className="font-medium mb-2">{section.title}</h4>
                  <p className="text-muted">{section.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <LandingPageMedia images={landingPageImages} productName={name} />

      {related.length > 0 ? (
        <section className="page-wrap mt-8 md:mt-12">
          <div className="text-right mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
              منتجات مشابهة
            </h2>
            <p className="text-gray-500 text-sm md:text-base">
              قد يعجبك أيضاً
            </p>
          </div>
          <div dir="rtl" className={`grid gap-4 px-4 md:px-0 ${
            related.length === 1 
              ? 'grid-cols-1 justify-center max-w-md mx-auto' 
              : 'grid-cols-2 md:grid-cols-4 justify-start'
          }`}>
            {related.map((item: any) => (
              <ProductCard
                key={item.documentId || item.id}
                product={item}
              />
            ))}
          </div>
        </section>
      ) : null}

      <ProductFloatingBar productName={name} isMielPage={isMielPage} />
    </div>
  );
};

export default ProductPage;
