import { NextResponse } from "next/server";
import { STRAPI_URL } from "@/lib/strapi";

type OrderPayload = {
  name?: string;
  phone?: string;
  email?: string;
  wilaya?: string;
  baladia?: string;
  address?: string;
  orderItems?: Array<{
    productName: string;
    color?: string;
    size?: string;
    quantity: number;
    price: number;
  }>;
  totalAmount?: number;
  notes?: string;
  paymentMethod?: string;
  selectedOffer?: {
    id?: string | number;
    title?: string;
    name?: string;
    price?: number;
    attributes?: {
      title?: string;
      name?: string;
    };
  } | null;
  offerTitle?: string;
};

function required(value: unknown) {
  return typeof value === "string" && value.trim().length > 0;
}

export async function POST(request: Request) {
  let body: OrderPayload;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  if (
    !required(body.name) ||
    !required(body.phone) ||
    !required(body.wilaya) ||
    !required(body.address) ||
    !body.orderItems ||
    body.orderItems.length === 0
  ) {
    return NextResponse.json(
      { error: "يرجى ملء كل الحقول المطلوبة." },
      { status: 400 },
    );
  }

  // Format order items for Google Sheets
  const firstItem = body.orderItems?.[0];
  const selectedOffer = body.selectedOffer;

  // Extract plain text title from Strapi offer object
  const offerTitle = selectedOffer?.attributes?.title || selectedOffer?.attributes?.name || selectedOffer?.title || selectedOffer?.name || body.offerTitle || '';

  // Build product details with offer information
  const productDetails = offerTitle
    ? `${firstItem?.quantity || 1}x ${firstItem?.productName || ''} - ${offerTitle}`
    : `${firstItem?.quantity || 1}x ${firstItem?.productName || ''}`;

  const googleSheetsPayload = {
    name: body.name!.trim(),
    phone: body.phone!.trim(),
    email: body.email?.trim() || "",
    wilaya: body.wilaya,
    baladia: body.baladia || "",
    address: body.address!.trim(),
    productName: firstItem?.productName || "",
    color: firstItem?.color || "",
    size: firstItem?.size || "",
    quantity: firstItem?.quantity || 1,
    price: firstItem?.price || 0,
    totalAmount: Number(body.totalAmount) || 0,
    paymentMethod: body.paymentMethod || "COD",
    notes: body.notes || "",
    selectedOffer: selectedOffer || null,
    selectedOfferTitle: offerTitle,
    productDetails: productDetails,
  };

  // Format payload for Strapi
  const strapiPayload = {
    data: {
      customerName: body.name!.trim(),
      customerPhone: body.phone!.trim(),
      customerEmail: body.email?.trim() || null,
      customerAddress: body.address!.trim(),
      customerCity: body.baladia || "",
      customerWilaya: body.wilaya,
      totalAmount: Number(body.totalAmount) || 0,
      status: "pending",
      paymentMethod: body.paymentMethod || "cod",
      paymentStatus: "pending",
      notes: body.notes || "",
      orderItems: body.orderItems,
      shippingCost: 0,
    },
  };

  const scriptUrl =
    process.env.GOOGLE_SCRIPT_URL || process.env.NEXT_PUBLIC_GOOGLE_SCRIPT_URL;

  let strapiSuccess = false;
  let googleSheetsSuccess = false;
  let strapiData: any = null;
  let error: string | null = null;

  // Try to send to Strapi
  try {
    const strapiResponse = await fetch(`${STRAPI_URL}/api/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.STRAPI_API_TOKEN || process.env.NEXT_PUBLIC_STRAPI_API_TOKEN}`,
      },
      body: JSON.stringify(strapiPayload),
    });

    if (strapiResponse.ok) {
      strapiData = await strapiResponse.json();
      strapiSuccess = true;
    } else {
      const errorData = await strapiResponse.json();
      console.error("Strapi API error:", errorData);
      error = "تعذر إرسال الطلب إلى Strapi";
    }
  } catch (strapiError) {
    console.error("Failed to submit order to Strapi:", strapiError);
    error = "تعذر إرسال الطلب إلى Strapi";
  }

  // Try to send to Google Sheets
  if (scriptUrl) {
    try {
      await fetch(scriptUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(googleSheetsPayload),
      });
      googleSheetsSuccess = true;
    } catch (googleError) {
      console.error("Failed to submit order to Google Sheets:", googleError);
      if (!error) error = "تعذر إرسال الطلب إلى Google Sheets";
    }
  }

  // Return response based on success
  if (strapiSuccess && googleSheetsSuccess) {
    return NextResponse.json({ 
      ok: true, 
      orderId: strapiData.data.id,
      trackingNumber: strapiData.data.attributes.trackingNumber,
      message: "تم إرسال الطلب بنجاح"
    });
  } else if (strapiSuccess) {
    return NextResponse.json({ 
      ok: true, 
      orderId: strapiData.data.id,
      trackingNumber: strapiData.data.attributes.trackingNumber,
      message: "تم إرسال الطلب (فشل النسخ الاحتياطي)"
    });
  } else if (googleSheetsSuccess) {
    return NextResponse.json({ 
      ok: true, 
      message: "تم إرسال الطلب (فشل التخزين الرئيسي)"
    });
  } else {
    return NextResponse.json(
      { error: error || "تعذر إرسال الطلب." },
      { status: 502 },
    );
  }
}
