import { NextRequest, NextResponse } from 'next/server';

async function checkBlackList(phone: string, clientIp: string): Promise<{ isBlocked: boolean }> {
  const strapiUrl = process.env.NEXT_PUBLIC_STRAPI_URL || process.env.STRAPI_URL;
  if (!strapiUrl) {
    console.error('STRAPI_URL not configured');
    return { isBlocked: false };
  }

  try {
    const checkUrl = `${strapiUrl}/api/black-lists?filters[$or][0][phone][$eq]=${encodeURIComponent(phone)}&filters[$or][1][ipAddress][$eq]=${encodeURIComponent(clientIp)}`;
    const response = await fetch(checkUrl, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed to check blacklist:', response.statusText);
      return { isBlocked: false };
    }

    const data = await response.json();
    const isBlocked = data.data && data.data.length > 0;
    
    if (isBlocked) {
      console.log('User is blacklisted:', { phone, clientIp });
    }
    
    return { isBlocked };
  } catch (error) {
    console.error('Error checking blacklist:', error);
    return { isBlocked: false };
  }
}

export async function POST(request: NextRequest) {
  try {
   
    const body = await request.json();
    console.log('Order received:', body);
    
    
    const orderItems = body.orderItems || [];
    
    
    const clientIp = request.headers.get('x-forwarded-for') || 
                     request.headers.get('x-real-ip') || 
                     'Unknown';
    
    const phone = body.phone?.trim() || '';
    
    
    if (phone && clientIp !== 'Unknown') {
      const { isBlocked } = await checkBlackList(phone, clientIp);
      if (isBlocked) {
        console.log('Order blocked - user is blacklisted');
        return NextResponse.json(
          { status: 'BLOCKED', message: 'User is blacklisted' },
          { status: 403 }
        );
      }
    }
    
    
    const items = orderItems.map((item: any) => ({
      size: item.size || '',
      color: item.color || '',
      quantity: item.quantity || 1
    }));

    const selectedOffer = body.selectedOffer;
    const productName = orderItems[0]?.productName || '';

    // Extract plain text title from Strapi offer object
    const offerTitle = selectedOffer?.attributes?.title || selectedOffer?.attributes?.name || selectedOffer?.title || selectedOffer?.name || body.offerTitle || '';

    const orderDetails = items.map((item: any) => {
      const details = [];
      if (item.size) details.push(item.size);
      if (item.color) details.push(item.color);
      const variantText = details.length > 0 ? ` (${details.join(" - ")})` : "";

      // Add offer title if selected
      const offerText = offerTitle ? ` - ${offerTitle}` : '';

      return `${item.quantity}x ${productName}${offerText}${variantText}`;
    }).join(" | ");

    const totalQuantity = items.reduce((sum: number, item: any) => sum + item.quantity, 0);

    const googleSheetData = {
      ipAddress: clientIp,
      name: body.name?.trim() || '',
      phone: phone,
      wilaya: body.wilaya || '',
      baladia: body.baladia || '',
      productName: productName,
      items: items,
      orderDetails: orderDetails || 'بدون تحديد',
      productDetails: orderDetails || 'بدون تحديد',
      totalQuantity: totalQuantity,
      totalPrice: body.totalAmount || 0,
      selectedOffer: selectedOffer || null,
      selectedOfferTitle: offerTitle,
    };
    
    console.log('Sending to Google Sheets:', googleSheetData);


    const googleSheetUrl = process.env.GOOGLE_SHEET_WEB_APP_URL;
    if (!googleSheetUrl) {
      console.error('Google Sheet URL not configured');
      return NextResponse.json(
        { error: 'Google Sheet URL not configured in environment variables' },
        { status: 500 }
      );
    }

    console.log('Google Sheet URL exists, making request...');

   
    const response = await fetch(googleSheetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(googleSheetData),
    });

    console.log('Google Sheets response status:', response.status);

   
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Google Sheets error:', errorText);
      return NextResponse.json(
        { error: 'Failed to send to Google Sheets', details: errorText },
        { status: response.status }
      );
    }

   
    const data = await response.json();
    console.log('Google Sheets success:', data);
    return NextResponse.json({ success: true, data }, { status: 200 });

  } catch (error) {

    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error('Error processing order:', error);
    
    return NextResponse.json(
      { error: 'Internal server error', details: errorMessage },
      { status: 500 }
    );
  }
}
