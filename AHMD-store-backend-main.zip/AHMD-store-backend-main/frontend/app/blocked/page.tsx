"use client";
import { Suspense } from "react";
import { useRouter } from "next/navigation";
import { ShieldAlert } from "lucide-react";
import Link from "next/link";

const BlockedContent = () => {
  const router = useRouter();

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-180px)] px-4" style={{ backgroundColor: '#F8F7F3' }}>
      <div className="flex flex-col items-center gap-8 max-w-md w-full">
        {/* Shield Alert Icon Animation */}
        <div className="relative">
          <div className="w-24 h-24 rounded-full flex items-center justify-center animate-pulse" style={{ backgroundColor: '#F8F7F3', border: '2px solid #B69A63' }}>
            <ShieldAlert className="w-12 h-12" style={{ color: '#B69A63' }} strokeWidth={2} />
          </div>
          <div className="absolute inset-0 rounded-full animate-ping opacity-20" style={{ backgroundColor: '#B69A63' }} />
        </div>

        {/* Main Heading */}
        <h1 className="text-3xl md:text-4xl font-bold text-center" style={{ color: '#1C1C1C' }}>
          عذراً، لا يمكن معالجة طلبك
        </h1>

        {/* Modern Alert Card */}
        <div className="w-full rounded-2xl p-6 shadow-lg" style={{ backgroundColor: '#FFFFFF', border: '1px solid #E8E7E3' }}>
          {/* Main Message */}
          <div className="flex items-start gap-4 mb-4">
            <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#7A8065' }}>
              <ShieldAlert className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <p className="text-base leading-relaxed" style={{ color: '#1C1C1C' }}>
              تعذر إتمام الطلب. يرجى التواصل مع خدمة العملاء إذا كنت تعتقد أن هناك خطأ.
            </p>
          </div>

          {/* Additional Note */}
          <div className="pt-4 border-t" style={{ borderColor: '#E8E7E3' }}>
            <p className="text-sm" style={{ color: '#7A8065' }}>
              نحن هنا لمساعدتك في حل أي مشكلة قد تواجهها.
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <Link
          href="/"
          className="w-full rounded-xl py-4 px-6 font-semibold tracking-wide transition-all duration-300 ease-in-out text-center"
          style={{ 
            backgroundColor: '#1C1C1C', 
            color: '#FFFFFF',
            border: '1px solid #1C1C1C'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#B69A63';
            e.currentTarget.style.borderColor = '#B69A63';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#1C1C1C';
            e.currentTarget.style.borderColor = '#1C1C1C';
          }}
        >
          العودة للمتجر
        </Link>
      </div>
    </div>
  );
};

const BlockedPage = () => {
  return (
    <Suspense fallback={<div className="h-[calc(100vh-180px)]" style={{ backgroundColor: '#F8F7F3' }} />}>
      <BlockedContent />
    </Suspense>
  );
};

export default BlockedPage;
