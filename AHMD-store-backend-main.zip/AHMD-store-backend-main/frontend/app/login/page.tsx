"use client";

import { useRouter } from "next/navigation";
import Cookies from "js-cookie";
import { useState, useEffect } from "react";

enum MODE {
  LOGIN = "LOGIN",
  REGISTER = "REGISTER",
}

const LoginPage = () => {
  const router = useRouter();


  useEffect(() => {
    const token = Cookies.get("jwt");
    if (token) {
      router.push("/");
    }
  }, [router]);

  const [mode, setMode] = useState(MODE.LOGIN);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const formTitle = mode === MODE.LOGIN ? "تسجيل الدخول" : "إنشاء حساب جديد";
  const buttonTitle = mode === MODE.LOGIN ? "دخول" : "تسجيل";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    setMessage("");

    const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_API_URL || "http://localhost:1337";

    try {
      let endpoint = `${STRAPI_URL}/api/auth/local`;
      let payload: any = { identifier: email, password };

      if (mode === MODE.REGISTER) {
        endpoint = `${STRAPI_URL}/api/auth/local/register`;
        payload = { username, email, password };
      }

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data?.error?.message || "حدث خطأ ما، يرجى التأكد من البيانات!");
        return;
      }

      Cookies.set("jwt", data.jwt, { expires: 7 });
      if (typeof window !== "undefined") {
        localStorage.setItem("strapi_token", data.jwt);
        if (data.user) {
          localStorage.setItem("strapi_user", JSON.stringify(data.user));
        }
      }
      setMessage("تم بنجاح! يتم تحويلك الآن...");
      
      setTimeout(() => {
        router.push("/");
      }, 1000);

    } catch (err) {
      console.error(err);
      setError("تعذر الاتصال بالسيرفر!");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-80px)] px-4 md:px-8 lg:px-16 xl:px-32 flex items-center justify-center">
      <form className="flex flex-col gap-6 w-full max-w-md bg-white p-8 rounded-xl shadow-sm border" onSubmit={handleSubmit}>
        <h1 className="text-2xl font-semibold text-center">{formTitle}</h1>

        {mode === MODE.REGISTER && (
          <div className="flex flex-col gap-2">
            <label className="text-sm text-gray-700">اسم المستخدم</label>
            <input
              type="text"
              required
              placeholder="اسم المستخدم"
              className="ring-1 ring-gray-300 rounded-md p-3 focus:ring-2 focus:ring-black outline-none"
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
        )}

        <div className="flex flex-col gap-2">
          <label className="text-sm text-gray-700">البريد الإلكتروني</label>
          <input
            type="email"
            required
            placeholder="example@gmail.com"
            className="ring-1 ring-gray-300 rounded-md p-3 focus:ring-2 focus:ring-black outline-none"
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-sm text-gray-700">كلمة السر</label>
          <input
            type="password"
            required
            placeholder="أدخل كلمة السر"
            className="ring-1 ring-gray-300 rounded-md p-3 focus:ring-2 focus:ring-black outline-none"
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button
          className="bg-black text-white p-3 rounded-md hover:bg-gray-800 disabled:bg-gray-400 transition"
          disabled={isLoading}
        >
          {isLoading ? "جاري التحميل..." : buttonTitle}
        </button>
        {error && <div className="text-red-600 text-sm text-center">{error}</div>}
        {message && <div className="text-green-600 text-sm text-center">{message}</div>}

        {mode === MODE.LOGIN ? (
          <div
            className="text-sm text-gray-600 underline cursor-pointer text-center"
            onClick={() => setMode(MODE.REGISTER)}
          >
            ليس لديك حساب؟ أنشئ حساباً الآن
          </div>
        ) : (
          <div
            className="text-sm text-gray-600 underline cursor-pointer text-center"
            onClick={() => setMode(MODE.LOGIN)}
          >
            لديك حساب بالفعل؟ سجل الدخول
          </div>
        )}
      </form>
    </div>
  );
};

export default LoginPage;