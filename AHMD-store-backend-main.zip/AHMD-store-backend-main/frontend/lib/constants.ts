export const CHECKOUT_FORM_ID = "product-checkout";
