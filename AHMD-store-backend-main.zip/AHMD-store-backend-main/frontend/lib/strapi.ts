export const STRAPI_URL =
  process.env.NEXT_PUBLIC_STRAPI_API_URL ||
  process.env.NEXT_PUBLIC_STRAPI_URL ||
  "http://localhost:1337";

const STRAPI_TOKEN =
  process.env.STRAPI_API_TOKEN || process.env.NEXT_PUBLIC_STRAPI_API_TOKEN;

export function getStrapiMediaUrl(file: any, fallback = "/product.png") {
  if (!file) return fallback;
  const url = file.url || file.attributes?.url;
  if (!url) return fallback;
  return url.startsWith("http") ? url : `${STRAPI_URL}${url}`;
}

export function getImageUrl(image: any, fallback = "/placeholder.png") {
  if (!image) return fallback;
  const url = image.data?.attributes?.url || image.url || image.formats?.medium?.url || image.attributes?.url;
  if (!url) return fallback;
  return url.startsWith("http") ? url : `${STRAPI_URL}${url}`;
}

export function unwrapStrapi<T = any>(entry: any): T {
  if (!entry) return entry;
  return (entry.attributes ? { id: entry.id, documentId: entry.documentId, ...entry.attributes } : entry) as T;
}

export function getProductHref(item: any) {
  const slug = item?.slug;
  if (slug && slug !== "null" && slug !== "undefined") {
    return `/products/${encodeURIComponent(String(slug))}`;
  }
  const fallback = item?.documentId || item?.id;
  if (fallback) return `/products/${encodeURIComponent(String(fallback))}`;
  return "/list";
}

export async function fetchStrapi(endpoint: string, options: RequestInit = {}) {
  const defaultHeaders: HeadersInit = {
    "Content-Type": "application/json",
    ...(STRAPI_TOKEN && { Authorization: `Bearer ${STRAPI_TOKEN}` }),
  };

  const path = endpoint.startsWith("/api") ? endpoint : `/api${endpoint}`;
  const response = await fetch(`${STRAPI_URL}${path}`, {
    ...options,
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`Strapi Fetch Error: ${response.statusText}`);
  }

  return await response.json();
}
