"use server";

import { revalidatePath } from "next/cache";
import { STRAPI_URL } from "@/lib/strapi";

export const updateUser = async (formData: FormData) => {
  const userId = formData.get("id") as string;
  const username = formData.get("username") as string;
  const firstName = formData.get("firstName") as string;
  const lastName = formData.get("lastName") as string;
  const phone = formData.get("phone") as string;
  const email = formData.get("email") as string;

  const strapiUrl = STRAPI_URL;
  const token =
    process.env.STRAPI_API_TOKEN || process.env.NEXT_PUBLIC_STRAPI_API_TOKEN;

  try {
    const res = await fetch(`${strapiUrl}/api/users/${userId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: JSON.stringify({
        username,
        firstName,
        lastName,
        phone,
        email,
      }),
    });

    if (!res.ok) {
      console.error("Failed to update user in Strapi");
      return;
    }

    revalidatePath("/profile");
  } catch (err) {
    console.error("Error in updateUser action:", err);
  }
};
