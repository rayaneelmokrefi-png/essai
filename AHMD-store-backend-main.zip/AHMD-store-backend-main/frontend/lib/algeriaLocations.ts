export type Commune = { name: string; nameAscii: string };

export type Wilaya = {
  code: string;
  name: string;
  nameAscii: string;
  communes: Commune[];
};

export const ALGERIA_WILAYAS: Wilaya[] = [
  {
    "code": "01",
    "name": "أدرار",
    "nameAscii": "Adrar",
    "communes": [
      {
        "name": "أدرار",
        "nameAscii": "Adrar"
      },
      {
        "name": "اقبلي",
        "nameAscii": "Akabli"
      },
      {
        "name": "أولف",
        "nameAscii": "Aoulef"
      },
      {
        "name": "بودة",
        "nameAscii": "Bouda"
      },
      {
        "name": "فنوغيل",
        "nameAscii": "Fenoughil"
      },
      {
        "name": "إن زغمير",
        "nameAscii": "In Zghmir"
      },
      {
        "name": "أولاد أحمد تيمي",
        "nameAscii": "Ouled Ahmed Timmi"
      },
      {
        "name": "رقان",
        "nameAscii": "Reggane"
      },
      {
        "name": "سالي",
        "nameAscii": "Sali"
      },
      {
        "name": "السبع",
        "nameAscii": "Sebaa"
      },
      {
        "name": "تامنطيط",
        "nameAscii": "Tamantit"
      },
      {
        "name": "تامست",
        "nameAscii": "Tamest"
      },
      {
        "name": "تيمقتن",
        "nameAscii": "Timekten"
      },
      {
        "name": "تيت",
        "nameAscii": "Tit"
      },
      {
        "name": "تسابيت",
        "nameAscii": "Tsabit"
      },
      {
        "name": "زاوية كنتة",
        "nameAscii": "Zaouiet Kounta"
      }
    ]
  },
  {
    "code": "02",
    "name": " الشلف",
    "nameAscii": "Chlef",
    "communes": [
      {
        "name": "أبو الحسن",
        "nameAscii": "Abou El Hassane"
      },
      {
        "name": "عين مران",
        "nameAscii": "Ain Merane"
      },
      {
        "name": "بنايرية",
        "nameAscii": "Benairia"
      },
      {
        "name": "بني بوعتاب",
        "nameAscii": "Beni Bouattab"
      },
      {
        "name": "بني حواء",
        "nameAscii": "Beni Haoua"
      },
      {
        "name": "بني راشد",
        "nameAscii": "Beni Rached"
      },
      {
        "name": "بوقادير",
        "nameAscii": "Boukadir"
      },
      {
        "name": "بوزغاية",
        "nameAscii": "Bouzeghaia"
      },
      {
        "name": "بريرة",
        "nameAscii": "Breira"
      },
      {
        "name": "الشطية",
        "nameAscii": "Chettia"
      },
      {
        "name": "الشلف",
        "nameAscii": "Chlef"
      },
      {
        "name": "الظهرة",
        "nameAscii": "Dahra"
      },
      {
        "name": "الحجاج",
        "nameAscii": "El Hadjadj"
      },
      {
        "name": "الكريمية",
        "nameAscii": "El Karimia"
      },
      {
        "name": "المرسى",
        "nameAscii": "El Marsa"
      },
      {
        "name": "حرشون",
        "nameAscii": "Harchoun"
      },
      {
        "name": "الهرانفة",
        "nameAscii": "Herenfa"
      },
      {
        "name": "الأبيض مجاجة",
        "nameAscii": "Labiod Medjadja"
      },
      {
        "name": "مصدق",
        "nameAscii": "Moussadek"
      },
      {
        "name": "وادي الفضة",
        "nameAscii": "Oued Fodda"
      },
      {
        "name": "وادي قوسين",
        "nameAscii": "Oued Goussine"
      },
      {
        "name": "وادي سلي",
        "nameAscii": "Oued Sly"
      },
      {
        "name": "أولاد عباس",
        "nameAscii": "Ouled Abbes"
      },
      {
        "name": "أولاد بن عبد القادر",
        "nameAscii": "Ouled Ben Abdelkader"
      },
      {
        "name": "أولاد فارس",
        "nameAscii": "Ouled Fares"
      },
      {
        "name": "أم الدروع",
        "nameAscii": "Oum Drou"
      },
      {
        "name": "سنجاس",
        "nameAscii": "Sendjas"
      },
      {
        "name": "سيدي عبد الرحمن",
        "nameAscii": "Sidi Abderrahmane"
      },
      {
        "name": "سيدي عكاشة",
        "nameAscii": "Sidi Akkacha"
      },
      {
        "name": "الصبحة",
        "nameAscii": "Sobha"
      },
      {
        "name": "تاجنة",
        "nameAscii": "Tadjena"
      },
      {
        "name": "تلعصة",
        "nameAscii": "Talassa"
      },
      {
        "name": "تاوقريت",
        "nameAscii": "Taougrit"
      },
      {
        "name": "تنس",
        "nameAscii": "Tenes"
      },
      {
        "name": "الزبوجة",
        "nameAscii": "Zeboudja"
      }
    ]
  },
  {
    "code": "03",
    "name": "الأغواط",
    "nameAscii": "Laghouat",
    "communes": [
      {
        "name": "أفلو",
        "nameAscii": "Aflou"
      },
      {
        "name": "عين ماضي",
        "nameAscii": "Ain Madhi"
      },
      {
        "name": "عين سيدي علي",
        "nameAscii": "Ain Sidi Ali"
      },
      {
        "name": "بن ناصر بن شهرة",
        "nameAscii": "Benacer Benchohra"
      },
      {
        "name": "بريدة",
        "nameAscii": "Brida"
      },
      {
        "name": "العسافية",
        "nameAscii": "El Assafia"
      },
      {
        "name": "البيضاء",
        "nameAscii": "El Beidha"
      },
      {
        "name": "الغيشة",
        "nameAscii": "El Ghicha"
      },
      {
        "name": "الحويطة",
        "nameAscii": "El Haouaita"
      },
      {
        "name": "قلتة سيدي سعد",
        "nameAscii": "Gueltat Sidi Saad"
      },
      {
        "name": "الحاج مشري",
        "nameAscii": "Hadj Mechri"
      },
      {
        "name": "حاسي الدلاعة",
        "nameAscii": "Hassi Delaa"
      },
      {
        "name": "حاسي الرمل",
        "nameAscii": "Hassi R'mel"
      },
      {
        "name": "الخنق",
        "nameAscii": "Kheneg"
      },
      {
        "name": "قصر الحيران",
        "nameAscii": "Ksar El Hirane"
      },
      {
        "name": "الأغواط",
        "nameAscii": "Laghouat"
      },
      {
        "name": "وادي مزي",
        "nameAscii": "Oued M'zi"
      },
      {
        "name": "وادي مرة",
        "nameAscii": "Oued Morra"
      },
      {
        "name": "سبقاق",
        "nameAscii": "Sebgag"
      },
      {
        "name": "سيدي بوزيد",
        "nameAscii": "Sidi Bouzid"
      },
      {
        "name": "سيدي مخلوف",
        "nameAscii": "Sidi Makhlouf"
      },
      {
        "name": "تاجموت",
        "nameAscii": "Tadjemout"
      },
      {
        "name": "تاجرونة",
        "nameAscii": "Tadjrouna"
      },
      {
        "name": "تاويالة",
        "nameAscii": "Taouiala"
      }
    ]
  },
  {
    "code": "04",
    "name": "أم البواقي",
    "nameAscii": "Oum El Bouaghi",
    "communes": [
      {
        "name": "عين ببوش",
        "nameAscii": "Ain Babouche"
      },
      {
        "name": "عين البيضاء",
        "nameAscii": "Ain Beida"
      },
      {
        "name": "عين الديس",
        "nameAscii": "Ain Diss"
      },
      {
        "name": "عين فكرون",
        "nameAscii": "Ain Fekroun"
      },
      {
        "name": "عين كرشة",
        "nameAscii": "Ain Kercha"
      },
      {
        "name": "عين مليلة",
        "nameAscii": "Ain M'lila"
      },
      {
        "name": "عين الزيتون",
        "nameAscii": "Ain Zitoun"
      },
      {
        "name": "بحير الشرقي",
        "nameAscii": "Behir Chergui"
      },
      {
        "name": "بريش",
        "nameAscii": "Berriche"
      },
      {
        "name": "بئر الشهداء",
        "nameAscii": "Bir Chouhada"
      },
      {
        "name": "الضلعة",
        "nameAscii": "Dhalaa"
      },
      {
        "name": "العامرية",
        "nameAscii": "El Amiria"
      },
      {
        "name": "البلالة",
        "nameAscii": "El Belala"
      },
      {
        "name": "الجازية",
        "nameAscii": "El Djazia"
      },
      {
        "name": "الفجوج بوغرارة سعودي",
        "nameAscii": "El Fedjoudj Boughrara Sa"
      },
      {
        "name": "الحرملية",
        "nameAscii": "El Harmilia"
      },
      {
        "name": "فكيرينة",
        "nameAscii": "Fkirina"
      },
      {
        "name": "هنشير تومغني",
        "nameAscii": "Hanchir Toumghani"
      },
      {
        "name": "قصر الصباحي",
        "nameAscii": "Ksar Sbahi"
      },
      {
        "name": "مسكيانة",
        "nameAscii": "Meskiana"
      },
      {
        "name": "وادي نيني",
        "nameAscii": "Oued Nini"
      },
      {
        "name": "أولاد قاسم",
        "nameAscii": "Ouled Gacem"
      },
      {
        "name": "أولاد حملة",
        "nameAscii": "Ouled Hamla"
      },
      {
        "name": "أولاد زواي",
        "nameAscii": "Ouled Zouai"
      },
      {
        "name": "أم البواقي",
        "nameAscii": "Oum El Bouaghi"
      },
      {
        "name": "الرحية",
        "nameAscii": "Rahia"
      },
      {
        "name": "سيقوس",
        "nameAscii": "Sigus"
      },
      {
        "name": "سوق نعمان",
        "nameAscii": "Souk Naamane"
      },
      {
        "name": "الزرق",
        "nameAscii": "Zorg"
      }
    ]
  },
  {
    "code": "05",
    "name": "باتنة",
    "nameAscii": "Batna",
    "communes": [
      {
        "name": "عين جاسر",
        "nameAscii": "Ain Djasser"
      },
      {
        "name": "عين التوتة",
        "nameAscii": "Ain Touta"
      },
      {
        "name": "عين ياقوت",
        "nameAscii": "Ain Yagout"
      },
      {
        "name": "أريس",
        "nameAscii": "Arris"
      },
      {
        "name": "عزيل عبد القادر",
        "nameAscii": "Azil Abedelkader"
      },
      {
        "name": "بريكة",
        "nameAscii": "Barika"
      },
      {
        "name": "باتنة",
        "nameAscii": "Batna"
      },
      {
        "name": "بني فضالة الحقانية",
        "nameAscii": "Beni Foudhala El Hakania"
      },
      {
        "name": "بيطام",
        "nameAscii": "Bitam"
      },
      {
        "name": "بولهيلات",
        "nameAscii": "Boulhilat"
      },
      {
        "name": "بومقر",
        "nameAscii": "Boumagueur"
      },
      {
        "name": "بومية",
        "nameAscii": "Boumia"
      },
      {
        "name": "بوزينة",
        "nameAscii": "Bouzina"
      },
      {
        "name": "الشمرة",
        "nameAscii": "Chemora"
      },
      {
        "name": "شير",
        "nameAscii": "Chir"
      },
      {
        "name": "جرمة",
        "nameAscii": "Djerma"
      },
      {
        "name": "الجزار",
        "nameAscii": "Djezzar"
      },
      {
        "name": "الحاسي",
        "nameAscii": "El Hassi"
      },
      {
        "name": "المعذر",
        "nameAscii": "El Madher"
      },
      {
        "name": "فسديس",
        "nameAscii": "Fesdis"
      },
      {
        "name": "فم الطوب",
        "nameAscii": "Foum Toub"
      },
      {
        "name": "غسيرة",
        "nameAscii": "Ghassira"
      },
      {
        "name": "القصبات",
        "nameAscii": "Gosbat"
      },
      {
        "name": "القيقبة",
        "nameAscii": "Guigba"
      },
      {
        "name": "حيدوسة",
        "nameAscii": "Hidoussa"
      },
      {
        "name": "إشمول",
        "nameAscii": "Ichemoul"
      },
      {
        "name": "إينوغيسن",
        "nameAscii": "Inoughissen"
      },
      {
        "name": "كيمل",
        "nameAscii": "Kimmel"
      },
      {
        "name": "قصر بلزمة",
        "nameAscii": "Ksar Bellezma"
      },
      {
        "name": "لارباع",
        "nameAscii": "Larbaa"
      },
      {
        "name": "لازرو",
        "nameAscii": "Lazrou"
      },
      {
        "name": "لمسان",
        "nameAscii": "Lemcene"
      },
      {
        "name": "إمدوكل",
        "nameAscii": "M Doukal"
      },
      {
        "name": "معافة",
        "nameAscii": "Maafa"
      },
      {
        "name": "منعة",
        "nameAscii": "Menaa"
      },
      {
        "name": "مروانة",
        "nameAscii": "Merouana"
      },
      {
        "name": "نقاوس",
        "nameAscii": "N Gaous"
      },
      {
        "name": "وادي الشعبة",
        "nameAscii": "Oued Chaaba"
      },
      {
        "name": "وادي الماء",
        "nameAscii": "Oued El Ma"
      },
      {
        "name": "وادي الطاقة",
        "nameAscii": "Oued Taga"
      },
      {
        "name": "أولاد عمار",
        "nameAscii": "Ouled Ammar"
      },
      {
        "name": "أولاد عوف",
        "nameAscii": "Ouled Aouf"
      },
      {
        "name": "أولاد فاضل",
        "nameAscii": "Ouled Fadel"
      },
      {
        "name": "أولاد سلام",
        "nameAscii": "Ouled Sellem"
      },
      {
        "name": "أولاد سي سليمان",
        "nameAscii": "Ouled Si Slimane"
      },
      {
        "name": "عيون العصافير",
        "nameAscii": "Ouyoun El Assafir"
      },
      {
        "name": "الرحبات",
        "nameAscii": "Rahbat"
      },
      {
        "name": "رأس العيون",
        "nameAscii": "Ras El Aioun"
      },
      {
        "name": "سفيان",
        "nameAscii": "Sefiane"
      },
      {
        "name": "سقانة",
        "nameAscii": "Seggana"
      },
      {
        "name": "سريانة",
        "nameAscii": "Seriana"
      },
      {
        "name": "تكوت",
        "nameAscii": "T Kout"
      },
      {
        "name": "تالخمت",
        "nameAscii": "Talkhamt"
      },
      {
        "name": "تاكسلانت",
        "nameAscii": "Taxlent"
      },
      {
        "name": "تازولت",
        "nameAscii": "Tazoult"
      },
      {
        "name": "ثنية العابد",
        "nameAscii": "Teniet El Abed"
      },
      {
        "name": "تيغانمين",
        "nameAscii": "Tighanimine"
      },
      {
        "name": "تغرغار",
        "nameAscii": "Tigharghar"
      },
      {
        "name": "تيلاطو",
        "nameAscii": "Tilatou"
      },
      {
        "name": "تيمقاد",
        "nameAscii": "Timgad"
      },
      {
        "name": "زانة البيضاء",
        "nameAscii": "Zanet El Beida"
      }
    ]
  },
  {
    "code": "06",
    "name": " بجاية",
    "nameAscii": "Béjaïa",
    "communes": [
      {
        "name": "أدكار",
        "nameAscii": "Adekar"
      },
      {
        "name": "أيت رزين",
        "nameAscii": "Ait R'zine"
      },
      {
        "name": "أيت إسماعيل",
        "nameAscii": "Ait-Smail"
      },
      {
        "name": "أقبو",
        "nameAscii": "Akbou"
      },
      {
        "name": "أكفادو",
        "nameAscii": "Akfadou"
      },
      {
        "name": "أمالو",
        "nameAscii": "Amalou"
      },
      {
        "name": "أميزور",
        "nameAscii": "Amizour"
      },
      {
        "name": "أوقاس",
        "nameAscii": "Aokas"
      },
      {
        "name": "برباشة",
        "nameAscii": "Barbacha"
      },
      {
        "name": "بجاية",
        "nameAscii": "Bejaia"
      },
      {
        "name": "بني جليل",
        "nameAscii": "Beni Djellil"
      },
      {
        "name": "بني كسيلة",
        "nameAscii": "Beni K'sila"
      },
      {
        "name": "بني مليكش",
        "nameAscii": "Beni-Mallikeche"
      },
      {
        "name": "بني معوش",
        "nameAscii": "Benimaouche"
      },
      {
        "name": "بو جليل",
        "nameAscii": "Boudjellil"
      },
      {
        "name": "بوحمزة",
        "nameAscii": "Bouhamza"
      },
      {
        "name": "بوخليفة",
        "nameAscii": "Boukhelifa"
      },
      {
        "name": "شلاطة",
        "nameAscii": "Chellata"
      },
      {
        "name": "شميني",
        "nameAscii": "Chemini"
      },
      {
        "name": "درقينة",
        "nameAscii": "Darguina"
      },
      {
        "name": "ذراع القايد",
        "nameAscii": "Dra El Caid"
      },
      {
        "name": "القصر",
        "nameAscii": "El Kseur"
      },
      {
        "name": "فناية الماثن",
        "nameAscii": "Fenaia Il Maten"
      },
      {
        "name": "فرعون",
        "nameAscii": "Feraoun"
      },
      {
        "name": "إغيل علي",
        "nameAscii": "Ighil-Ali"
      },
      {
        "name": "اغرم",
        "nameAscii": "Ighram"
      },
      {
        "name": "كنديرة",
        "nameAscii": "Kendira"
      },
      {
        "name": "خراطة",
        "nameAscii": "Kherrata"
      },
      {
        "name": "الفلاي",
        "nameAscii": "Leflaye"
      },
      {
        "name": "مسيسنة",
        "nameAscii": "M'cisna"
      },
      {
        "name": "مالبو",
        "nameAscii": "Melbou"
      },
      {
        "name": "وادي غير",
        "nameAscii": "Oued Ghir"
      },
      {
        "name": "أوزلاقن",
        "nameAscii": "Ouzellaguen"
      },
      {
        "name": "صدوق",
        "nameAscii": "Seddouk"
      },
      {
        "name": "سيدي عياد",
        "nameAscii": "Sidi Ayad"
      },
      {
        "name": "سيدي عيش",
        "nameAscii": "Sidi-Aich"
      },
      {
        "name": "سمعون",
        "nameAscii": "Smaoun"
      },
      {
        "name": "سوق لإثنين",
        "nameAscii": "Souk El Tenine"
      },
      {
        "name": "سوق اوفلا",
        "nameAscii": "Souk Oufella"
      },
      {
        "name": "تالة حمزة",
        "nameAscii": "Tala Hamza"
      },
      {
        "name": "تامقرة",
        "nameAscii": "Tamokra"
      },
      {
        "name": "تامريجت",
        "nameAscii": "Tamridjet"
      },
      {
        "name": "تاوريرت إغيل",
        "nameAscii": "Taourit Ighil"
      },
      {
        "name": "تاسكريوت",
        "nameAscii": "Taskriout"
      },
      {
        "name": "تازمالت",
        "nameAscii": "Tazmalt"
      },
      {
        "name": "طيبان",
        "nameAscii": "Tibane"
      },
      {
        "name": "تيشي",
        "nameAscii": "Tichy"
      },
      {
        "name": "تيفرة",
        "nameAscii": "Tifra"
      },
      {
        "name": "تيمزريت",
        "nameAscii": "Timezrit"
      },
      {
        "name": "تينبدار",
        "nameAscii": "Tinebdar"
      },
      {
        "name": "تيزي نبربر",
        "nameAscii": "Tizi-N'berber"
      },
      {
        "name": "توجة",
        "nameAscii": "Toudja"
      }
    ]
  },
  {
    "code": "07",
    "name": "بسكرة",
    "nameAscii": "Biskra",
    "communes": [
      {
        "name": "عين الناقة",
        "nameAscii": "Ain Naga"
      },
      {
        "name": "عين زعطوط",
        "nameAscii": "Ain Zaatout"
      },
      {
        "name": "بسكرة",
        "nameAscii": "Biskra"
      },
      {
        "name": "برج بن عزوز",
        "nameAscii": "Bordj Ben Azzouz"
      },
      {
        "name": "بوشقرون",
        "nameAscii": "Bouchakroun"
      },
      {
        "name": "برانيس",
        "nameAscii": "Branis"
      },
      {
        "name": "شتمة",
        "nameAscii": "Chetma"
      },
      {
        "name": "جمورة",
        "nameAscii": "Djemorah"
      },
      {
        "name": "الفيض",
        "nameAscii": "El Feidh"
      },
      {
        "name": "الغروس",
        "nameAscii": "El Ghrous"
      },
      {
        "name": "الحاجب",
        "nameAscii": "El Hadjab"
      },
      {
        "name": "الحوش",
        "nameAscii": "El Haouch"
      },
      {
        "name": "القنطرة",
        "nameAscii": "El Kantara"
      },
      {
        "name": "الوطاية",
        "nameAscii": "El Outaya"
      },
      {
        "name": "فوغالة",
        "nameAscii": "Foughala"
      },
      {
        "name": "خنقة سيدي ناجي",
        "nameAscii": "Khenguet Sidi Nadji"
      },
      {
        "name": "ليشانة",
        "nameAscii": "Lichana"
      },
      {
        "name": "ليوة",
        "nameAscii": "Lioua"
      },
      {
        "name": "مشونش",
        "nameAscii": "M'chouneche"
      },
      {
        "name": "مليلي",
        "nameAscii": "M'lili"
      },
      {
        "name": "مخادمة",
        "nameAscii": "Mekhadma"
      },
      {
        "name": "المزيرعة",
        "nameAscii": "Meziraa"
      },
      {
        "name": "أوماش",
        "nameAscii": "Oumache"
      },
      {
        "name": "أورلال",
        "nameAscii": "Ourlal"
      },
      {
        "name": "سيدي عقبة",
        "nameAscii": "Sidi Okba"
      },
      {
        "name": "طولقة",
        "nameAscii": "Tolga"
      },
      {
        "name": "زريبة الوادي",
        "nameAscii": "Zeribet El Oued"
      }
    ]
  },
  {
    "code": "08",
    "name": "بشار",
    "nameAscii": "Béchar",
    "communes": [
      {
        "name": "العبادلة",
        "nameAscii": "Abadla"
      },
      {
        "name": "بشار",
        "nameAscii": "Bechar"
      },
      {
        "name": "بني ونيف",
        "nameAscii": "Beni-Ounif"
      },
      {
        "name": "بوكايس",
        "nameAscii": "Boukais"
      },
      {
        "name": "عرق فراج",
        "nameAscii": "Erg-Ferradj"
      },
      {
        "name": "القنادسة",
        "nameAscii": "Kenadsa"
      },
      {
        "name": "لحمر",
        "nameAscii": "Lahmar"
      },
      {
        "name": "مشرع هواري بومدين",
        "nameAscii": "Machraa-Houari-Boumediene"
      },
      {
        "name": "المريجة",
        "nameAscii": "Meridja"
      },
      {
        "name": "موغل",
        "nameAscii": "Mogheul"
      },
      {
        "name": "تبلبالة",
        "nameAscii": "Tabelbala"
      },
      {
        "name": "تاغيت",
        "nameAscii": "Taghit"
      }
    ]
  },
  {
    "code": "09",
    "name": "البليدة",
    "nameAscii": "Blida",
    "communes": [
      {
        "name": "عين الرمانة",
        "nameAscii": "Ain Romana"
      },
      {
        "name": "بني مراد",
        "nameAscii": "Beni Mered"
      },
      {
        "name": "بني تامو",
        "nameAscii": "Beni-Tamou"
      },
      {
        "name": "بن خليل",
        "nameAscii": "Benkhelil"
      },
      {
        "name": "البليدة",
        "nameAscii": "Blida"
      },
      {
        "name": "بوعرفة",
        "nameAscii": "Bouarfa"
      },
      {
        "name": "بوفاريك",
        "nameAscii": "Boufarik"
      },
      {
        "name": "بوقرة",
        "nameAscii": "Bougara"
      },
      {
        "name": "بوعينان",
        "nameAscii": "Bouinan"
      },
      {
        "name": "الشبلي",
        "nameAscii": "Chebli"
      },
      {
        "name": "الشفة",
        "nameAscii": "Chiffa"
      },
      {
        "name": "الشريعة",
        "nameAscii": "Chrea"
      },
      {
        "name": "جبابرة",
        "nameAscii": "Djebabra"
      },
      {
        "name": "العفرون",
        "nameAscii": "El-Affroun"
      },
      {
        "name": "قرواو",
        "nameAscii": "Guerrouaou"
      },
      {
        "name": "حمام ملوان",
        "nameAscii": "Hammam Elouane"
      },
      {
        "name": "الأربعاء",
        "nameAscii": "Larbaa"
      },
      {
        "name": "مفتاح",
        "nameAscii": "Meftah"
      },
      {
        "name": "موزاية",
        "nameAscii": "Mouzaia"
      },
      {
        "name": "وادي جر",
        "nameAscii": "Oued Djer"
      },
      {
        "name": "وادي العلايق",
        "nameAscii": "Oued El Alleug"
      },
      {
        "name": "اولاد سلامة",
        "nameAscii": "Ouled Slama"
      },
      {
        "name": "أولاد يعيش",
        "nameAscii": "Ouled Yaich"
      },
      {
        "name": "صوحان",
        "nameAscii": "Souhane"
      },
      {
        "name": "الصومعة",
        "nameAscii": "Soumaa"
      }
    ]
  },
  {
    "code": "10",
    "name": "البويرة",
    "nameAscii": "Bouira",
    "communes": [
      {
        "name": "أغبالو",
        "nameAscii": "Aghbalou"
      },
      {
        "name": "أهل القصر",
        "nameAscii": "Ahl El Ksar"
      },
      {
        "name": "عين الحجر",
        "nameAscii": "Ain El Hadjar"
      },
      {
        "name": "عين العلوي",
        "nameAscii": "Ain Laloui"
      },
      {
        "name": "عين الترك",
        "nameAscii": "Ain Turk"
      },
      {
        "name": "عين بسام",
        "nameAscii": "Ain-Bessem"
      },
      {
        "name": "أيت لعزيز",
        "nameAscii": "Ait Laaziz"
      },
      {
        "name": "أعمر",
        "nameAscii": "Aomar"
      },
      {
        "name": "آث منصور",
        "nameAscii": "Ath Mansour"
      },
      {
        "name": "بشلول",
        "nameAscii": "Bechloul"
      },
      {
        "name": "بئر غبالو",
        "nameAscii": "Bir Ghbalou"
      },
      {
        "name": "برج أوخريص",
        "nameAscii": "Bordj Okhriss"
      },
      {
        "name": "بودربالة",
        "nameAscii": "Bouderbala"
      },
      {
        "name": "البويرة",
        "nameAscii": "Bouira"
      },
      {
        "name": "بوكرم",
        "nameAscii": "Boukram"
      },
      {
        "name": "شرفة",
        "nameAscii": "Chorfa"
      },
      {
        "name": "الدشمية",
        "nameAscii": "Dechmia"
      },
      {
        "name": "ديرة",
        "nameAscii": "Dirah"
      },
      {
        "name": "جباحية",
        "nameAscii": "Djebahia"
      },
      {
        "name": "العجيبة",
        "nameAscii": "El Adjiba"
      },
      {
        "name": "الأسنام",
        "nameAscii": "El Asnam"
      },
      {
        "name": "الهاشمية",
        "nameAscii": "El Hachimia"
      },
      {
        "name": "الخبوزية",
        "nameAscii": "El Khabouzia"
      },
      {
        "name": "الحاكمية",
        "nameAscii": "El-Hakimia"
      },
      {
        "name": "المقراني",
        "nameAscii": "El-Mokrani"
      },
      {
        "name": "قرومة",
        "nameAscii": "Guerrouma"
      },
      {
        "name": "الحجرة الزرقاء",
        "nameAscii": "Hadjera Zerga"
      },
      {
        "name": "حيزر",
        "nameAscii": "Haizer"
      },
      {
        "name": "حنيف",
        "nameAscii": "Hanif"
      },
      {
        "name": "قادرية",
        "nameAscii": "Kadiria"
      },
      {
        "name": "الأخضرية",
        "nameAscii": "Lakhdaria"
      },
      {
        "name": "أمشدالة",
        "nameAscii": "M Chedallah"
      },
      {
        "name": "معلة",
        "nameAscii": "Maala"
      },
      {
        "name": "المعمورة",
        "nameAscii": "Maamora"
      },
      {
        "name": "مزدور",
        "nameAscii": "Mezdour"
      },
      {
        "name": "وادي البردي",
        "nameAscii": "Oued El Berdi"
      },
      {
        "name": "أولاد راشد",
        "nameAscii": "Ouled Rached"
      },
      {
        "name": "روراوة",
        "nameAscii": "Raouraoua"
      },
      {
        "name": "ريدان",
        "nameAscii": "Ridane"
      },
      {
        "name": "سحاريج",
        "nameAscii": "Saharidj"
      },
      {
        "name": "سوق الخميس",
        "nameAscii": "Souk El Khemis"
      },
      {
        "name": "سور الغزلان",
        "nameAscii": "Sour El Ghozlane"
      },
      {
        "name": "تاغزوت",
        "nameAscii": "Taghzout"
      },
      {
        "name": "تاقديت",
        "nameAscii": "Taguedite"
      },
      {
        "name": "زبربر",
        "nameAscii": "Z'barbar (El Isseri )"
      }
    ]
  },
  {
    "code": "11",
    "name": "تمنراست",
    "nameAscii": "Tamanrasset",
    "communes": [
      {
        "name": "ابلسة",
        "nameAscii": "Abelsa"
      },
      {
        "name": "عين امقل",
        "nameAscii": "Ain Amguel"
      },
      {
        "name": "أدلس",
        "nameAscii": "Idles"
      },
      {
        "name": "تمنراست",
        "nameAscii": "Tamanrasset"
      },
      {
        "name": "تاظروك",
        "nameAscii": "Tazrouk"
      }
    ]
  },
  {
    "code": "12",
    "name": "تبسة",
    "nameAscii": "Tébessa",
    "communes": [
      {
        "name": "عين الزرقاء",
        "nameAscii": "Ain Zerga"
      },
      {
        "name": "بجن",
        "nameAscii": "Bedjene"
      },
      {
        "name": "بكارية",
        "nameAscii": "Bekkaria"
      },
      {
        "name": "بئر الذهب",
        "nameAscii": "Bir Dheheb"
      },
      {
        "name": "بئر مقدم",
        "nameAscii": "Bir Mokkadem"
      },
      {
        "name": "بئر العاتر",
        "nameAscii": "Bir-El-Ater"
      },
      {
        "name": "بوخضرة",
        "nameAscii": "Boukhadra"
      },
      {
        "name": "بولحاف الدير",
        "nameAscii": "Boulhaf Dyr"
      },
      {
        "name": "الشريعة",
        "nameAscii": "Cheria"
      },
      {
        "name": "الكويف",
        "nameAscii": "El Kouif"
      },
      {
        "name": "الماء الابيض",
        "nameAscii": "El Malabiod"
      },
      {
        "name": "المريج",
        "nameAscii": "El Meridj"
      },
      {
        "name": "المزرعة",
        "nameAscii": "El Mezeraa"
      },
      {
        "name": "العقلة",
        "nameAscii": "El Ogla"
      },
      {
        "name": "العقلة المالحة",
        "nameAscii": "El Ogla El Malha"
      },
      {
        "name": "العوينات",
        "nameAscii": "El-Aouinet"
      },
      {
        "name": "الحويجبات",
        "nameAscii": "El-Houidjbet"
      },
      {
        "name": "فركان",
        "nameAscii": "Ferkane"
      },
      {
        "name": "قريقر",
        "nameAscii": "Guorriguer"
      },
      {
        "name": "الحمامات",
        "nameAscii": "Hammamet"
      },
      {
        "name": "مرسط",
        "nameAscii": "Morsott"
      },
      {
        "name": "نقرين",
        "nameAscii": "Negrine"
      },
      {
        "name": "الونزة",
        "nameAscii": "Ouenza"
      },
      {
        "name": "أم علي",
        "nameAscii": "Oum Ali"
      },
      {
        "name": "صفصاف الوسرى",
        "nameAscii": "Saf Saf El Ouesra"
      },
      {
        "name": "سطح قنطيس",
        "nameAscii": "Stah Guentis"
      },
      {
        "name": "تبسة",
        "nameAscii": "Tebessa"
      },
      {
        "name": "ثليجان",
        "nameAscii": "Telidjen"
      }
    ]
  },
  {
    "code": "13",
    "name": "تلمسان",
    "nameAscii": "Tlemcen",
    "communes": [
      {
        "name": "عين فتاح",
        "nameAscii": "Ain Fetah"
      },
      {
        "name": "عين فزة",
        "nameAscii": "Ain Fezza"
      },
      {
        "name": "عين غرابة",
        "nameAscii": "Ain Ghoraba"
      },
      {
        "name": "عين الكبيرة",
        "nameAscii": "Ain Kebira"
      },
      {
        "name": "عين النحالة",
        "nameAscii": "Ain Nehala"
      },
      {
        "name": "عين تالوت",
        "nameAscii": "Ain Tellout"
      },
      {
        "name": "عين يوسف",
        "nameAscii": "Ain Youcef"
      },
      {
        "name": "عمير",
        "nameAscii": "Amieur"
      },
      {
        "name": "العزايل",
        "nameAscii": "Azail"
      },
      {
        "name": "باب العسة",
        "nameAscii": "Bab El Assa"
      },
      {
        "name": "بني بهدل",
        "nameAscii": "Beni Bahdel"
      },
      {
        "name": "بني بوسعيد",
        "nameAscii": "Beni Boussaid"
      },
      {
        "name": "بني خلاد",
        "nameAscii": "Beni Khellad"
      },
      {
        "name": "بني مستر",
        "nameAscii": "Beni Mester"
      },
      {
        "name": "بني وارسوس",
        "nameAscii": "Beni Ouarsous"
      },
      {
        "name": "بني صميل",
        "nameAscii": "Beni Smiel"
      },
      {
        "name": "بني سنوس",
        "nameAscii": "Beni Snous"
      },
      {
        "name": "بن سكران",
        "nameAscii": "Bensekrane"
      },
      {
        "name": "بوحلو",
        "nameAscii": "Bouhlou"
      },
      {
        "name": "البويهي",
        "nameAscii": "Bouihi"
      },
      {
        "name": "شتوان",
        "nameAscii": "Chetouane"
      },
      {
        "name": "دار يغمراسن",
        "nameAscii": "Dar Yaghmoracen"
      },
      {
        "name": "جبالة",
        "nameAscii": "Djebala"
      },
      {
        "name": "العريشة",
        "nameAscii": "El Aricha"
      },
      {
        "name": "الفحول",
        "nameAscii": "El Fehoul"
      },
      {
        "name": "القور",
        "nameAscii": "El Gor"
      },
      {
        "name": "فلاوسن",
        "nameAscii": "Fellaoucene"
      },
      {
        "name": "الغزوات",
        "nameAscii": "Ghazaouet"
      },
      {
        "name": "حمام بوغرارة",
        "nameAscii": "Hammam Boughrara"
      },
      {
        "name": "الحناية",
        "nameAscii": "Hennaya"
      },
      {
        "name": "هنين",
        "nameAscii": "Honnaine"
      },
      {
        "name": "مسيردة الفواقة",
        "nameAscii": "M'sirda Fouaga"
      },
      {
        "name": "مغنية",
        "nameAscii": "Maghnia"
      },
      {
        "name": "منصورة",
        "nameAscii": "Mansourah"
      },
      {
        "name": "مرسى بن مهيدي",
        "nameAscii": "Marsa Ben M'hidi"
      },
      {
        "name": "ندرومة",
        "nameAscii": "Nedroma"
      },
      {
        "name": "وادي الخضر",
        "nameAscii": "Oued Lakhdar"
      },
      {
        "name": "أولاد ميمون",
        "nameAscii": "Ouled Mimoun"
      },
      {
        "name": "أولاد رياح",
        "nameAscii": "Ouled Riyah"
      },
      {
        "name": "الرمشي",
        "nameAscii": "Remchi"
      },
      {
        "name": "صبرة",
        "nameAscii": "Sabra"
      },
      {
        "name": "سبعة شيوخ",
        "nameAscii": "Sebbaa Chioukh"
      },
      {
        "name": "سبدو",
        "nameAscii": "Sebdou"
      },
      {
        "name": "سيدي العبدلي",
        "nameAscii": "Sidi Abdelli"
      },
      {
        "name": "سيدي الجيلالي",
        "nameAscii": "Sidi Djillali"
      },
      {
        "name": "سيدي مجاهد",
        "nameAscii": "Sidi Medjahed"
      },
      {
        "name": "السواحلية",
        "nameAscii": "Souahlia"
      },
      {
        "name": "السواني",
        "nameAscii": "Souani"
      },
      {
        "name": "سوق الثلاثاء",
        "nameAscii": "Souk Tleta"
      },
      {
        "name": "تيرني بني هديل",
        "nameAscii": "Terny Beni Hediel"
      },
      {
        "name": "تيانت",
        "nameAscii": "Tianet"
      },
      {
        "name": "تلمسان",
        "nameAscii": "Tlemcen"
      },
      {
        "name": "زناتة",
        "nameAscii": "Zenata"
      }
    ]
  },
  {
    "code": "14",
    "name": "تيارت",
    "nameAscii": "Tiaret",
    "communes": [
      {
        "name": "عين بوشقيف",
        "nameAscii": "Ain Bouchekif"
      },
      {
        "name": "عين الذهب",
        "nameAscii": "Ain Deheb"
      },
      {
        "name": "عين دزاريت",
        "nameAscii": "Ain Dzarit"
      },
      {
        "name": "عين الحديد",
        "nameAscii": "Ain El Hadid"
      },
      {
        "name": "عين كرمس",
        "nameAscii": "Ain Kermes"
      },
      {
        "name": "بوقرة",
        "nameAscii": "Bougara"
      },
      {
        "name": "شحيمة",
        "nameAscii": "Chehaima"
      },
      {
        "name": "دحموني",
        "nameAscii": "Dahmouni"
      },
      {
        "name": "جبيلات الرصفاء",
        "nameAscii": "Djebilet Rosfa"
      },
      {
        "name": "جيلالي بن عمار",
        "nameAscii": "Djillali Ben Amar"
      },
      {
        "name": "الفايجة",
        "nameAscii": "Faidja"
      },
      {
        "name": "فرندة",
        "nameAscii": "Frenda"
      },
      {
        "name": "قرطوفة",
        "nameAscii": "Guertoufa"
      },
      {
        "name": "حمادية",
        "nameAscii": "Hamadia"
      },
      {
        "name": "قصر الشلالة",
        "nameAscii": "Ksar Chellala"
      },
      {
        "name": "مادنة",
        "nameAscii": "Madna"
      },
      {
        "name": "مهدية",
        "nameAscii": "Mahdia"
      },
      {
        "name": "مشرع الصفا",
        "nameAscii": "Mechraa Safa"
      },
      {
        "name": "مدريسة",
        "nameAscii": "Medrissa"
      },
      {
        "name": "مدروسة",
        "nameAscii": "Medroussa"
      },
      {
        "name": "مغيلة",
        "nameAscii": "Meghila"
      },
      {
        "name": "ملاكو",
        "nameAscii": "Mellakou"
      },
      {
        "name": "الناظورة",
        "nameAscii": "Nadorah"
      },
      {
        "name": "النعيمة",
        "nameAscii": "Naima"
      },
      {
        "name": "وادي ليلي",
        "nameAscii": "Oued Lilli"
      },
      {
        "name": "الرحوية",
        "nameAscii": "Rahouia"
      },
      {
        "name": "الرشايقة",
        "nameAscii": "Rechaiga"
      },
      {
        "name": "السبعين",
        "nameAscii": "Sebaine"
      },
      {
        "name": "السبت",
        "nameAscii": "Sebt"
      },
      {
        "name": "سرغين",
        "nameAscii": "Serghine"
      },
      {
        "name": "سي عبد الغني",
        "nameAscii": "Si Abdelghani"
      },
      {
        "name": "سيدي عبد الرحمن",
        "nameAscii": "Sidi Abderrahmane"
      },
      {
        "name": "سيدي علي ملال",
        "nameAscii": "Sidi Ali Mellal"
      },
      {
        "name": "سيدي بختي",
        "nameAscii": "Sidi Bakhti"
      },
      {
        "name": "سيدي حسني",
        "nameAscii": "Sidi Hosni"
      },
      {
        "name": "السوقر",
        "nameAscii": "Sougueur"
      },
      {
        "name": "تاقدمت",
        "nameAscii": "Tagdempt"
      },
      {
        "name": "تخمرت",
        "nameAscii": "Takhemaret"
      },
      {
        "name": "تيارت",
        "nameAscii": "Tiaret"
      },
      {
        "name": "تيدة",
        "nameAscii": "Tidda"
      },
      {
        "name": "توسنينة",
        "nameAscii": "Tousnina"
      },
      {
        "name": "زمالة الأمير عبد القادر",
        "nameAscii": "Zmalet El Emir Abdelkade"
      }
    ]
  },
  {
    "code": "15",
    "name": "تيزي وزو",
    "nameAscii": "Tizi Ouzou",
    "communes": [
      {
        "name": "أبي يوسف",
        "nameAscii": "Abi-Youcef"
      },
      {
        "name": "أغريب",
        "nameAscii": "Aghribs"
      },
      {
        "name": "أقني قغران",
        "nameAscii": "Agouni-Gueghrane"
      },
      {
        "name": "عين الحمام",
        "nameAscii": "Ain-El-Hammam"
      },
      {
        "name": "عين الزاوية",
        "nameAscii": "Ain-Zaouia"
      },
      {
        "name": "أيت عقـواشة",
        "nameAscii": "Ait Aggouacha"
      },
      {
        "name": "أيت بــوادو",
        "nameAscii": "Ait Bouaddou"
      },
      {
        "name": "أيت بومهدي",
        "nameAscii": "Ait Boumahdi"
      },
      {
        "name": "أيت خليلي",
        "nameAscii": "Ait Khellili"
      },
      {
        "name": "أيت يحي موسى",
        "nameAscii": "Ait Yahia Moussa"
      },
      {
        "name": "أيت عيسى ميمون",
        "nameAscii": "Ait-Aissa-Mimoun"
      },
      {
        "name": "أيت شافع",
        "nameAscii": "Ait-Chafaa"
      },
      {
        "name": "أيت محمود",
        "nameAscii": "Ait-Mahmoud"
      },
      {
        "name": "أيت أومالو",
        "nameAscii": "Ait-Oumalou"
      },
      {
        "name": "أيت تودرت",
        "nameAscii": "Ait-Toudert"
      },
      {
        "name": "أيت يحيى",
        "nameAscii": "Ait-Yahia"
      },
      {
        "name": "اقبيل",
        "nameAscii": "Akbil"
      },
      {
        "name": "أقرو",
        "nameAscii": "Akerrou"
      },
      {
        "name": "أسي يوسف",
        "nameAscii": "Assi-Youcef"
      },
      {
        "name": "عزازقة",
        "nameAscii": "Azazga"
      },
      {
        "name": "أزفون",
        "nameAscii": "Azeffoun"
      },
      {
        "name": "بنــــي زمنزار",
        "nameAscii": "Beni Zmenzer"
      },
      {
        "name": "بني عيسي",
        "nameAscii": "Beni-Aissi"
      },
      {
        "name": "بني دوالة",
        "nameAscii": "Beni-Douala"
      },
      {
        "name": "بني يني",
        "nameAscii": "Beni-Yenni"
      },
      {
        "name": "بني زيكــي",
        "nameAscii": "Beni-Zikki"
      },
      {
        "name": "بوغني",
        "nameAscii": "Boghni"
      },
      {
        "name": "بوجيمة",
        "nameAscii": "Boudjima"
      },
      {
        "name": "بونوح",
        "nameAscii": "Bounouh"
      },
      {
        "name": "بوزقــن",
        "nameAscii": "Bouzeguene"
      },
      {
        "name": "ذراع بن خدة",
        "nameAscii": "Draa-Ben-Khedda"
      },
      {
        "name": "ذراع الميزان",
        "nameAscii": "Draa-El-Mizan"
      },
      {
        "name": "فريحة",
        "nameAscii": "Freha"
      },
      {
        "name": "فريقات",
        "nameAscii": "Frikat"
      },
      {
        "name": "إبودرارن",
        "nameAscii": "Iboudrarene"
      },
      {
        "name": "إيجــار",
        "nameAscii": "Idjeur"
      },
      {
        "name": "إفــرحــونان",
        "nameAscii": "Iferhounene"
      },
      {
        "name": "إيفيغاء",
        "nameAscii": "Ifigha"
      },
      {
        "name": "إفليـــسن",
        "nameAscii": "Iflissen"
      },
      {
        "name": "إيلـيــلتـن",
        "nameAscii": "Illilten"
      },
      {
        "name": "إيلولة أومـــالو",
        "nameAscii": "Illoula Oumalou"
      },
      {
        "name": "إمســوحال",
        "nameAscii": "Imsouhal"
      },
      {
        "name": "إيرجـــن",
        "nameAscii": "Irdjen"
      },
      {
        "name": "الأربعــاء ناث إيراثن",
        "nameAscii": "Larbaa Nath Irathen"
      },
      {
        "name": "مكيرة",
        "nameAscii": "M'kira"
      },
      {
        "name": "معـــاتقة",
        "nameAscii": "Maatkas"
      },
      {
        "name": "ماكودة",
        "nameAscii": "Makouda"
      },
      {
        "name": "مشطراس",
        "nameAscii": "Mechtras"
      },
      {
        "name": "مقــلع",
        "nameAscii": "Mekla"
      },
      {
        "name": "ميزرانـــة",
        "nameAscii": "Mizrana"
      },
      {
        "name": "واسيف",
        "nameAscii": "Ouacif"
      },
      {
        "name": "واضية",
        "nameAscii": "Ouadhias"
      },
      {
        "name": "واقنون",
        "nameAscii": "Ouaguenoun"
      },
      {
        "name": "سيدي نعمان",
        "nameAscii": "Sidi Namane"
      },
      {
        "name": "صوامـــع",
        "nameAscii": "Souama"
      },
      {
        "name": "سوق الإثنين",
        "nameAscii": "Souk-El-Tenine"
      },
      {
        "name": "تادمايت",
        "nameAscii": "Tadmait"
      },
      {
        "name": "تيقـزيرت",
        "nameAscii": "Tigzirt"
      },
      {
        "name": "تيمـيزار",
        "nameAscii": "Timizart"
      },
      {
        "name": "تيرمتين",
        "nameAscii": "Tirmitine"
      },
      {
        "name": "تيزي نثلاثة",
        "nameAscii": "Tizi N'tleta"
      },
      {
        "name": "تيزي غنيف",
        "nameAscii": "Tizi-Gheniff"
      },
      {
        "name": "تيزي وزو",
        "nameAscii": "Tizi-Ouzou"
      },
      {
        "name": "تيزي راشد",
        "nameAscii": "Tizi-Rached"
      },
      {
        "name": "إعــكورن",
        "nameAscii": "Yakourene"
      },
      {
        "name": "يطــافن",
        "nameAscii": "Yatafene"
      },
      {
        "name": "زكري",
        "nameAscii": "Zekri"
      }
    ]
  },
  {
    "code": "16",
    "name": "الجزائر",
    "nameAscii": "Alger",
    "communes": [
      {
        "name": "عين بنيان",
        "nameAscii": "Ain Benian"
      },
      {
        "name": "عين طاية",
        "nameAscii": "Ain Taya"
      },
      {
        "name": "الجزائر الوسطى",
        "nameAscii": "Alger Centre"
      },
      {
        "name": "باب الوادي",
        "nameAscii": "Bab El Oued"
      },
      {
        "name": "باب الزوار",
        "nameAscii": "Bab Ezzouar"
      },
      {
        "name": "بابا حسن",
        "nameAscii": "Baba Hassen"
      },
      {
        "name": "باش جراح",
        "nameAscii": "Bachedjerah"
      },
      {
        "name": "براقي",
        "nameAscii": "Baraki"
      },
      {
        "name": "ابن عكنون",
        "nameAscii": "Ben Aknoun"
      },
      {
        "name": "بني مسوس",
        "nameAscii": "Beni Messous"
      },
      {
        "name": "بئر مراد رايس",
        "nameAscii": "Bir Mourad Rais"
      },
      {
        "name": "بئر توتة",
        "nameAscii": "Bir Touta"
      },
      {
        "name": "بئر خادم",
        "nameAscii": "Birkhadem"
      },
      {
        "name": "بولوغين بن زيري",
        "nameAscii": "Bologhine Ibnou Ziri"
      },
      {
        "name": "برج البحري",
        "nameAscii": "Bordj El Bahri"
      },
      {
        "name": "برج الكيفان",
        "nameAscii": "Bordj El Kiffan"
      },
      {
        "name": "بوروبة",
        "nameAscii": "Bourouba"
      },
      {
        "name": "بوزريعة",
        "nameAscii": "Bouzareah"
      },
      {
        "name": "القصبة",
        "nameAscii": "Casbah"
      },
      {
        "name": "الشراقة",
        "nameAscii": "Cheraga"
      },
      {
        "name": "الدار البيضاء",
        "nameAscii": "Dar El Beida"
      },
      {
        "name": "دالي ابراهيم",
        "nameAscii": "Dely Ibrahim"
      },
      {
        "name": "جسر قسنطينة",
        "nameAscii": "Djasr Kasentina"
      },
      {
        "name": "الدويرة",
        "nameAscii": "Douira"
      },
      {
        "name": "الدرارية",
        "nameAscii": "Draria"
      },
      {
        "name": "العاشور",
        "nameAscii": "El Achour"
      },
      {
        "name": "الابيار",
        "nameAscii": "El Biar"
      },
      {
        "name": "الحراش",
        "nameAscii": "El Harrach"
      },
      {
        "name": "المدنية",
        "nameAscii": "El Madania"
      },
      {
        "name": "المغارية",
        "nameAscii": "El Magharia"
      },
      {
        "name": "المرسى",
        "nameAscii": "El Marsa"
      },
      {
        "name": "المرادية",
        "nameAscii": "El Mouradia"
      },
      {
        "name": "الحمامات",
        "nameAscii": "Hammamet"
      },
      {
        "name": "هراوة",
        "nameAscii": "Herraoua"
      },
      {
        "name": "حسين داي",
        "nameAscii": "Hussein Dey"
      },
      {
        "name": "حيدرة",
        "nameAscii": "Hydra"
      },
      {
        "name": "الخرايسية",
        "nameAscii": "Khraissia"
      },
      {
        "name": "القبة",
        "nameAscii": "Kouba"
      },
      {
        "name": "الكاليتوس",
        "nameAscii": "Les Eucalyptus"
      },
      {
        "name": "المعالمة",
        "nameAscii": "Maalma"
      },
      {
        "name": "محمد بلوزداد",
        "nameAscii": "Mohamed Belouzdad"
      },
      {
        "name": "المحمدية",
        "nameAscii": "Mohammadia"
      },
      {
        "name": "وادي قريش",
        "nameAscii": "Oued Koriche"
      },
      {
        "name": "وادي السمار",
        "nameAscii": "Oued Smar"
      },
      {
        "name": "اولاد شبل",
        "nameAscii": "Ouled Chebel"
      },
      {
        "name": "اولاد فايت",
        "nameAscii": "Ouled Fayet"
      },
      {
        "name": "الرحمانية",
        "nameAscii": "Rahmania"
      },
      {
        "name": "الرايس حميدو",
        "nameAscii": "Rais Hamidou"
      },
      {
        "name": "رغاية",
        "nameAscii": "Reghaia"
      },
      {
        "name": "الرويبة",
        "nameAscii": "Rouiba"
      },
      {
        "name": "السحاولة",
        "nameAscii": "Sehaoula"
      },
      {
        "name": "سيدي امحمد",
        "nameAscii": "Sidi M'hamed"
      },
      {
        "name": "سيدي موسى",
        "nameAscii": "Sidi Moussa"
      },
      {
        "name": "سويدانية",
        "nameAscii": "Souidania"
      },
      {
        "name": "سطاوالي",
        "nameAscii": "Staoueli"
      },
      {
        "name": "تسالة المرجة",
        "nameAscii": "Tessala El Merdja"
      },
      {
        "name": "زرالدة",
        "nameAscii": "Zeralda"
      }
    ]
  },
  {
    "code": "17",
    "name": "الجلفة",
    "nameAscii": "Djelfa",
    "communes": [
      {
        "name": "عين الشهداء",
        "nameAscii": "Ain Chouhada"
      },
      {
        "name": "عين الإبل",
        "nameAscii": "Ain El Ibel"
      },
      {
        "name": "عين فقه",
        "nameAscii": "Ain Fekka"
      },
      {
        "name": "عين معبد",
        "nameAscii": "Ain Maabed"
      },
      {
        "name": "عين وسارة",
        "nameAscii": "Ain Oussera"
      },
      {
        "name": "عمورة",
        "nameAscii": "Amourah"
      },
      {
        "name": "بنهار",
        "nameAscii": "Benhar"
      },
      {
        "name": "بن يعقوب",
        "nameAscii": "Benyagoub"
      },
      {
        "name": "بيرين",
        "nameAscii": "Birine"
      },
      {
        "name": "بويرة الأحداب",
        "nameAscii": "Bouira Lahdab"
      },
      {
        "name": "الشارف",
        "nameAscii": "Charef"
      },
      {
        "name": "دار الشيوخ",
        "nameAscii": "Dar Chioukh"
      },
      {
        "name": "دلدول",
        "nameAscii": "Deldoul"
      },
      {
        "name": "الجلفة",
        "nameAscii": "Djelfa"
      },
      {
        "name": "دويس",
        "nameAscii": "Douis"
      },
      {
        "name": "القديد",
        "nameAscii": "El Guedid"
      },
      {
        "name": "الادريسية",
        "nameAscii": "El Idrissia"
      },
      {
        "name": "الخميس",
        "nameAscii": "El Khemis"
      },
      {
        "name": "فيض البطمة",
        "nameAscii": "Faidh El Botma"
      },
      {
        "name": "قرنيني",
        "nameAscii": "Guernini"
      },
      {
        "name": "قطارة",
        "nameAscii": "Guettara"
      },
      {
        "name": "حد الصحاري",
        "nameAscii": "Had Sahary"
      },
      {
        "name": "حاسي بحبح",
        "nameAscii": "Hassi Bahbah"
      },
      {
        "name": "حاسي العش",
        "nameAscii": "Hassi El Euch"
      },
      {
        "name": "حاسي فدول",
        "nameAscii": "Hassi Fedoul"
      },
      {
        "name": "مليليحة",
        "nameAscii": "M'liliha"
      },
      {
        "name": "مسعد",
        "nameAscii": "Messaad"
      },
      {
        "name": "مجبارة",
        "nameAscii": "Moudjebara"
      },
      {
        "name": "أم العظام",
        "nameAscii": "Oum Laadham"
      },
      {
        "name": "سد الرحال",
        "nameAscii": "Sed Rahal"
      },
      {
        "name": "سلمانة",
        "nameAscii": "Selmana"
      },
      {
        "name": "سيدي بايزيد",
        "nameAscii": "Sidi Baizid"
      },
      {
        "name": "سيدي لعجال",
        "nameAscii": "Sidi Laadjel"
      },
      {
        "name": "تعظميت",
        "nameAscii": "Taadmit"
      },
      {
        "name": "زعفران",
        "nameAscii": "Zaafrane"
      },
      {
        "name": "زكار",
        "nameAscii": "Zaccar"
      }
    ]
  },
  {
    "code": "18",
    "name": "جيجل",
    "nameAscii": "Jijel",
    "communes": [
      {
        "name": "برج الطهر",
        "nameAscii": "Bordj T'har"
      },
      {
        "name": "بودريعة بني ياجيس",
        "nameAscii": "Boudria Beniyadjis"
      },
      {
        "name": "بوراوي بلهادف",
        "nameAscii": "Bouraoui Belhadef"
      },
      {
        "name": "بوسيف أولاد عسكر",
        "nameAscii": "Boussif Ouled Askeur"
      },
      {
        "name": "الشحنة",
        "nameAscii": "Chahna"
      },
      {
        "name": "الشقفة",
        "nameAscii": "Chekfa"
      },
      {
        "name": "الجمعة بني حبيبي",
        "nameAscii": "Djemaa Beni Habibi"
      },
      {
        "name": "جيملة",
        "nameAscii": "Djimla"
      },
      {
        "name": "العنصر",
        "nameAscii": "El Ancer"
      },
      {
        "name": "العوانة",
        "nameAscii": "El Aouana"
      },
      {
        "name": "القنار نشفي",
        "nameAscii": "El Kennar Nouchfi"
      },
      {
        "name": "الميلية",
        "nameAscii": "El Milia"
      },
      {
        "name": "الامير عبد القادر",
        "nameAscii": "Emir Abdelkader"
      },
      {
        "name": "أراقن سويسي",
        "nameAscii": "Erraguene Souissi"
      },
      {
        "name": "غبالة",
        "nameAscii": "Ghebala"
      },
      {
        "name": "جيجل",
        "nameAscii": "Jijel"
      },
      {
        "name": "قاوس",
        "nameAscii": "Kaous"
      },
      {
        "name": "خيري واد عجول",
        "nameAscii": "Khiri Oued Adjoul"
      },
      {
        "name": "وجانة",
        "nameAscii": "Oudjana"
      },
      {
        "name": "أولاد رابح",
        "nameAscii": "Ouled Rabah"
      },
      {
        "name": "أولاد يحيى خدروش",
        "nameAscii": "Ouled Yahia Khadrouch"
      },
      {
        "name": "سلمى بن زيادة",
        "nameAscii": "Selma Benziada"
      },
      {
        "name": "السطارة",
        "nameAscii": "Settara"
      },
      {
        "name": "سيدي عبد العزيز",
        "nameAscii": "Sidi Abdelaziz"
      },
      {
        "name": "سيدي معروف",
        "nameAscii": "Sidi Marouf"
      },
      {
        "name": "الطاهير",
        "nameAscii": "Taher"
      },
      {
        "name": "تاكسنة",
        "nameAscii": "Texenna"
      },
      {
        "name": "زيامة منصورية",
        "nameAscii": "Ziama Mansouriah"
      }
    ]
  },
  {
    "code": "19",
    "name": "سطيف",
    "nameAscii": "Sétif",
    "communes": [
      {
        "name": "عين عباسة",
        "nameAscii": "Ain Abessa"
      },
      {
        "name": "عين أرنات",
        "nameAscii": "Ain Arnat"
      },
      {
        "name": "عين أزال",
        "nameAscii": "Ain Azel"
      },
      {
        "name": "عين الكبيرة",
        "nameAscii": "Ain El Kebira"
      },
      {
        "name": "عين الحجر",
        "nameAscii": "Ain Lahdjar"
      },
      {
        "name": "عين ولمان",
        "nameAscii": "Ain Oulmene"
      },
      {
        "name": "عين لقراج",
        "nameAscii": "Ain-Legradj"
      },
      {
        "name": "عين الروى",
        "nameAscii": "Ain-Roua"
      },
      {
        "name": "عين السبت",
        "nameAscii": "Ain-Sebt"
      },
      {
        "name": "أيت نوال مزادة",
        "nameAscii": "Ait Naoual Mezada"
      },
      {
        "name": "ايت تيزي",
        "nameAscii": "Ait-Tizi"
      },
      {
        "name": "عموشة",
        "nameAscii": "Amoucha"
      },
      {
        "name": "بابور",
        "nameAscii": "Babor"
      },
      {
        "name": "بازر سكرة",
        "nameAscii": "Bazer-Sakra"
      },
      {
        "name": "بيضاء برج",
        "nameAscii": "Beidha Bordj"
      },
      {
        "name": "بلاعة",
        "nameAscii": "Bellaa"
      },
      {
        "name": "بني شبانة",
        "nameAscii": "Beni Chebana"
      },
      {
        "name": "بني فودة",
        "nameAscii": "Beni Fouda"
      },
      {
        "name": "بني ورتيلان",
        "nameAscii": "Beni Ourtilane"
      },
      {
        "name": "بني وسين",
        "nameAscii": "Beni Oussine"
      },
      {
        "name": "بني عزيز",
        "nameAscii": "Beni-Aziz"
      },
      {
        "name": "بني موحلي",
        "nameAscii": "Beni-Mouhli"
      },
      {
        "name": "بئر حدادة",
        "nameAscii": "Bir Haddada"
      },
      {
        "name": "بئر العرش",
        "nameAscii": "Bir-El-Arch"
      },
      {
        "name": "بوعنداس",
        "nameAscii": "Bouandas"
      },
      {
        "name": "بوقاعة",
        "nameAscii": "Bougaa"
      },
      {
        "name": "بوسلام",
        "nameAscii": "Bousselam"
      },
      {
        "name": "بوطالب",
        "nameAscii": "Boutaleb"
      },
      {
        "name": "الدهامشة",
        "nameAscii": "Dehamcha"
      },
      {
        "name": "جميلة",
        "nameAscii": "Djemila"
      },
      {
        "name": "ذراع قبيلة",
        "nameAscii": "Draa-Kebila"
      },
      {
        "name": "العلمة",
        "nameAscii": "El Eulma"
      },
      {
        "name": "أوريسيا",
        "nameAscii": "El Ouricia"
      },
      {
        "name": "الولجة",
        "nameAscii": "El-Ouldja"
      },
      {
        "name": "قلال",
        "nameAscii": "Guellal"
      },
      {
        "name": "قلتة زرقاء",
        "nameAscii": "Guelta Zerka"
      },
      {
        "name": "قنزات",
        "nameAscii": "Guenzet"
      },
      {
        "name": "قجال",
        "nameAscii": "Guidjel"
      },
      {
        "name": "حمام السخنة",
        "nameAscii": "Hamam Soukhna"
      },
      {
        "name": "الحامة",
        "nameAscii": "Hamma"
      },
      {
        "name": "حمام قرقور",
        "nameAscii": "Hammam Guergour"
      },
      {
        "name": "حربيل",
        "nameAscii": "Harbil"
      },
      {
        "name": "قصر الابطال",
        "nameAscii": "Kasr El Abtal"
      },
      {
        "name": "معاوية",
        "nameAscii": "Maaouia"
      },
      {
        "name": "ماوكلان",
        "nameAscii": "Maouaklane"
      },
      {
        "name": "مزلوق",
        "nameAscii": "Mezloug"
      },
      {
        "name": "واد البارد",
        "nameAscii": "Oued El Bared"
      },
      {
        "name": "أولاد عدوان",
        "nameAscii": "Ouled Addouane"
      },
      {
        "name": "أولاد صابر",
        "nameAscii": "Ouled Sabor"
      },
      {
        "name": "أولاد سي أحمد",
        "nameAscii": "Ouled Si Ahmed"
      },
      {
        "name": "أولاد تبان",
        "nameAscii": "Ouled Tebben"
      },
      {
        "name": "الرصفة",
        "nameAscii": "Rosfa"
      },
      {
        "name": "صالح باي",
        "nameAscii": "Salah Bey"
      },
      {
        "name": "سرج الغول",
        "nameAscii": "Serdj-El-Ghoul"
      },
      {
        "name": "سطيف",
        "nameAscii": "Setif"
      },
      {
        "name": "تاشودة",
        "nameAscii": "Tachouda"
      },
      {
        "name": "تالة إيفاسن",
        "nameAscii": "Tala-Ifacene"
      },
      {
        "name": "الطاية",
        "nameAscii": "Taya"
      },
      {
        "name": "التلة",
        "nameAscii": "Tella"
      },
      {
        "name": "تيزي نبشار",
        "nameAscii": "Tizi N'bechar"
      }
    ]
  },
  {
    "code": "20",
    "name": "سعيدة",
    "nameAscii": "Saïda",
    "communes": [
      {
        "name": "عين الحجر",
        "nameAscii": "Ain El Hadjar"
      },
      {
        "name": "عين السخونة",
        "nameAscii": "Ain Sekhouna"
      },
      {
        "name": "عين السلطان",
        "nameAscii": "Ain Soltane"
      },
      {
        "name": "دوي ثابت",
        "nameAscii": "Doui Thabet"
      },
      {
        "name": "الحساسنة",
        "nameAscii": "El Hassasna"
      },
      {
        "name": "هونت",
        "nameAscii": "Hounet"
      },
      {
        "name": "المعمورة",
        "nameAscii": "Maamora"
      },
      {
        "name": "مولاي العربي",
        "nameAscii": "Moulay Larbi"
      },
      {
        "name": "أولاد إبراهيم",
        "nameAscii": "Ouled Brahim"
      },
      {
        "name": "أولاد خالد",
        "nameAscii": "Ouled Khaled"
      },
      {
        "name": "سعيدة",
        "nameAscii": "Saida"
      },
      {
        "name": "سيدي احمد",
        "nameAscii": "Sidi Ahmed"
      },
      {
        "name": "سيدي عمر",
        "nameAscii": "Sidi Amar"
      },
      {
        "name": "سيدي بوبكر",
        "nameAscii": "Sidi Boubekeur"
      },
      {
        "name": "تيرسين",
        "nameAscii": "Tircine"
      },
      {
        "name": "يوب",
        "nameAscii": "Youb"
      }
    ]
  },
  {
    "code": "21",
    "name": "سكيكدة",
    "nameAscii": "Skikda",
    "communes": [
      {
        "name": "عين بوزيان",
        "nameAscii": "Ain Bouziane"
      },
      {
        "name": "عين شرشار",
        "nameAscii": "Ain Charchar"
      },
      {
        "name": "عين قشرة",
        "nameAscii": "Ain Kechra"
      },
      {
        "name": "عين زويت",
        "nameAscii": "Ain Zouit"
      },
      {
        "name": "عزابة",
        "nameAscii": "Azzaba"
      },
      {
        "name": "بكوش لخضر",
        "nameAscii": "Bekkouche Lakhdar"
      },
      {
        "name": "بن عزوز",
        "nameAscii": "Ben Azzouz"
      },
      {
        "name": "بني بشير",
        "nameAscii": "Beni Bechir"
      },
      {
        "name": "بني ولبان",
        "nameAscii": "Beni Oulbane"
      },
      {
        "name": "بني زيد",
        "nameAscii": "Beni Zid"
      },
      {
        "name": "بين الويدان",
        "nameAscii": "Bin El Ouiden"
      },
      {
        "name": "بوشطاطة",
        "nameAscii": "Bouchetata"
      },
      {
        "name": "الشرايع",
        "nameAscii": "Cheraia"
      },
      {
        "name": "القل",
        "nameAscii": "Collo"
      },
      {
        "name": "جندل سعدي محمد",
        "nameAscii": "Djendel Saadi Mohamed"
      },
      {
        "name": "الحروش",
        "nameAscii": "El Arrouch"
      },
      {
        "name": "الغدير",
        "nameAscii": "El Ghedir"
      },
      {
        "name": "الحدائق",
        "nameAscii": "El Hadaiek"
      },
      {
        "name": "المرسى",
        "nameAscii": "El Marsa"
      },
      {
        "name": "مجاز الدشيش",
        "nameAscii": "Emjez Edchich"
      },
      {
        "name": "السبت",
        "nameAscii": "Es Sebt"
      },
      {
        "name": "فلفلة",
        "nameAscii": "Filfila"
      },
      {
        "name": "حمادي كرومة",
        "nameAscii": "Hammadi Krouma"
      },
      {
        "name": "قنواع",
        "nameAscii": "Kanoua"
      },
      {
        "name": "الكركرة",
        "nameAscii": "Kerkara"
      },
      {
        "name": "خناق مايو",
        "nameAscii": "Khenag Maoune"
      },
      {
        "name": "وادي الزهور",
        "nameAscii": "Oued Zhour"
      },
      {
        "name": "الولجة بولبلوط",
        "nameAscii": "Ouldja Boulbalout"
      },
      {
        "name": "أولاد عطية",
        "nameAscii": "Ouled Attia"
      },
      {
        "name": "أولاد حبابة",
        "nameAscii": "Ouled Habbaba"
      },
      {
        "name": "أم الطوب",
        "nameAscii": "Oum Toub"
      },
      {
        "name": "رمضان جمال",
        "nameAscii": "Ramdane Djamel"
      },
      {
        "name": "صالح بو الشعور",
        "nameAscii": "Salah Bouchaour"
      },
      {
        "name": "سيدي مزغيش",
        "nameAscii": "Sidi Mezghiche"
      },
      {
        "name": "سكيكدة",
        "nameAscii": "Skikda"
      },
      {
        "name": "تمالوس",
        "nameAscii": "Tamalous"
      },
      {
        "name": "زردازة",
        "nameAscii": "Zerdezas"
      },
      {
        "name": "الزيتونة",
        "nameAscii": "Zitouna"
      }
    ]
  },
  {
    "code": "22",
    "name": "سيدي بلعباس",
    "nameAscii": "Sidi Bel Abbès",
    "communes": [
      {
        "name": "عين البرد",
        "nameAscii": "Ain El Berd"
      },
      {
        "name": "عين قادة",
        "nameAscii": "Ain Kada"
      },
      {
        "name": "عين الثريد",
        "nameAscii": "Ain Thrid"
      },
      {
        "name": "عين تندمين",
        "nameAscii": "Ain Tindamine"
      },
      {
        "name": "عين أدن",
        "nameAscii": "Ain- Adden"
      },
      {
        "name": "العمارنة",
        "nameAscii": "Amarnas"
      },
      {
        "name": "بضرابين المقراني",
        "nameAscii": "Bedrabine El Mokrani"
      },
      {
        "name": "بلعربي",
        "nameAscii": "Belarbi"
      },
      {
        "name": "بن باديس",
        "nameAscii": "Ben Badis"
      },
      {
        "name": "بن عشيبة شلية",
        "nameAscii": "Benachiba Chelia"
      },
      {
        "name": "بئر الحمام",
        "nameAscii": "Bir El Hammam"
      },
      {
        "name": "بوجبهة البرج",
        "nameAscii": "Boudjebaa El Bordj"
      },
      {
        "name": "بوخنفيس",
        "nameAscii": "Boukhanefis"
      },
      {
        "name": "شيطوان البلايلة",
        "nameAscii": "Chetouane Belaila"
      },
      {
        "name": "الضاية",
        "nameAscii": "Dhaya"
      },
      {
        "name": "الحصيبة",
        "nameAscii": "El Hacaiba"
      },
      {
        "name": "حاسي دحو",
        "nameAscii": "Hassi Dahou"
      },
      {
        "name": "حاسي زهانة",
        "nameAscii": "Hassi Zahana"
      },
      {
        "name": "لمطار",
        "nameAscii": "Lamtar"
      },
      {
        "name": "مسيد",
        "nameAscii": "M'cid"
      },
      {
        "name": "مكدرة",
        "nameAscii": "Makedra"
      },
      {
        "name": "مرحوم",
        "nameAscii": "Marhoum"
      },
      {
        "name": "مرين",
        "nameAscii": "Merine"
      },
      {
        "name": "مزاورو",
        "nameAscii": "Mezaourou"
      },
      {
        "name": "مصطفى بن ابراهيم",
        "nameAscii": "Mostefa Ben Brahim"
      },
      {
        "name": "مولاي سليسن",
        "nameAscii": "Moulay Slissen"
      },
      {
        "name": "وادي السبع",
        "nameAscii": "Oued Sebaa"
      },
      {
        "name": "وادي سفيون",
        "nameAscii": "Oued Sefioun"
      },
      {
        "name": "وادي تاوريرة",
        "nameAscii": "Oued Taourira"
      },
      {
        "name": "راس الماء",
        "nameAscii": "Ras El Ma"
      },
      {
        "name": "رجم دموش",
        "nameAscii": "Redjem Demouche"
      },
      {
        "name": "السهالة الثورة",
        "nameAscii": "Sehala Thaoura"
      },
      {
        "name": "سفيزف",
        "nameAscii": "Sfisef"
      },
      {
        "name": "سيدي علي بن يوب",
        "nameAscii": "Sidi Ali Benyoub"
      },
      {
        "name": "سيدي علي بوسيدي",
        "nameAscii": "Sidi Ali Boussidi"
      },
      {
        "name": "سيدي بلعباس",
        "nameAscii": "Sidi Bel-Abbes"
      },
      {
        "name": "سيدي ابراهيم",
        "nameAscii": "Sidi Brahim"
      },
      {
        "name": "سيدي شعيب",
        "nameAscii": "Sidi Chaib"
      },
      {
        "name": "سيدي دحو الزاير",
        "nameAscii": "Sidi Dahou Zairs"
      },
      {
        "name": "سيدي حمادوش",
        "nameAscii": "Sidi Hamadouche"
      },
      {
        "name": "سيدي خالد",
        "nameAscii": "Sidi Khaled"
      },
      {
        "name": "سيدي لحسن",
        "nameAscii": "Sidi Lahcene"
      },
      {
        "name": "سيدي يعقوب",
        "nameAscii": "Sidi Yacoub"
      },
      {
        "name": "طابية",
        "nameAscii": "Tabia"
      },
      {
        "name": "تاودموت",
        "nameAscii": "Taoudmout"
      },
      {
        "name": "تفسور",
        "nameAscii": "Tefessour"
      },
      {
        "name": "تغاليمت",
        "nameAscii": "Teghalimet"
      },
      {
        "name": "تلاغ",
        "nameAscii": "Telagh"
      },
      {
        "name": "تنيرة",
        "nameAscii": "Tenira"
      },
      {
        "name": "تسالة",
        "nameAscii": "Tessala"
      },
      {
        "name": "تلموني",
        "nameAscii": "Tilmouni"
      },
      {
        "name": "زروالة",
        "nameAscii": "Zerouala"
      }
    ]
  },
  {
    "code": "23",
    "name": "عنابة",
    "nameAscii": "Annaba",
    "communes": [
      {
        "name": "عين الباردة",
        "nameAscii": "Ain El Berda"
      },
      {
        "name": "عنابة",
        "nameAscii": "Annaba"
      },
      {
        "name": "برحال",
        "nameAscii": "Berrahal"
      },
      {
        "name": "شطايبي",
        "nameAscii": "Chetaibi"
      },
      {
        "name": "الشرفة",
        "nameAscii": "Cheurfa"
      },
      {
        "name": "البوني",
        "nameAscii": "El Bouni"
      },
      {
        "name": "العلمة",
        "nameAscii": "El Eulma"
      },
      {
        "name": "الحجار",
        "nameAscii": "El Hadjar"
      },
      {
        "name": "واد العنب",
        "nameAscii": "Oued El Aneb"
      },
      {
        "name": "سرايدي",
        "nameAscii": "Seraidi"
      },
      {
        "name": "سيدي عمار",
        "nameAscii": "Sidi Amar"
      },
      {
        "name": "التريعات",
        "nameAscii": "Treat"
      }
    ]
  },
  {
    "code": "24",
    "name": "قالمة",
    "nameAscii": "Guelma",
    "communes": [
      {
        "name": "عين بن بيضاء",
        "nameAscii": "Ain Ben Beida"
      },
      {
        "name": "عين العربي",
        "nameAscii": "Ain Larbi"
      },
      {
        "name": "عين مخلوف",
        "nameAscii": "Ain Makhlouf"
      },
      {
        "name": "عين رقادة",
        "nameAscii": "Ain Regada"
      },
      {
        "name": "عين صندل",
        "nameAscii": "Ain Sandel"
      },
      {
        "name": "بلخير",
        "nameAscii": "Belkheir"
      },
      {
        "name": "بن جراح",
        "nameAscii": "Bendjarah"
      },
      {
        "name": "بني مزلين",
        "nameAscii": "Beni Mezline"
      },
      {
        "name": "برج صباط",
        "nameAscii": "Bordj Sabath"
      },
      {
        "name": "بوحشانة",
        "nameAscii": "Bou Hachana"
      },
      {
        "name": "بوحمدان",
        "nameAscii": "Bou Hamdane"
      },
      {
        "name": "بوعاتي محمود",
        "nameAscii": "Bouati Mahmoud"
      },
      {
        "name": "بوشقوف",
        "nameAscii": "Bouchegouf"
      },
      {
        "name": "بومهرة أحمد",
        "nameAscii": "Boumahra Ahmed"
      },
      {
        "name": "الدهوارة",
        "nameAscii": "Dahouara"
      },
      {
        "name": "جبالة الخميسي",
        "nameAscii": "Djeballah Khemissi"
      },
      {
        "name": "الفجوج",
        "nameAscii": "El Fedjoudj"
      },
      {
        "name": "قلعة بوصبع",
        "nameAscii": "Guelaat Bou Sbaa"
      },
      {
        "name": "قالمة",
        "nameAscii": "Guelma"
      },
      {
        "name": "حمام دباغ",
        "nameAscii": "Hammam Debagh"
      },
      {
        "name": "حمام النبايل",
        "nameAscii": "Hammam N'bail"
      },
      {
        "name": "هيليوبوليس",
        "nameAscii": "Heliopolis"
      },
      {
        "name": "هواري بومدين",
        "nameAscii": "Houari Boumedienne"
      },
      {
        "name": "لخزارة",
        "nameAscii": "Khezaras"
      },
      {
        "name": "مجاز عمار",
        "nameAscii": "Medjez Amar"
      },
      {
        "name": "مجاز الصفاء",
        "nameAscii": "Medjez Sfa"
      },
      {
        "name": "نشماية",
        "nameAscii": "Nechmaya"
      },
      {
        "name": "وادي الشحم",
        "nameAscii": "Oued Cheham"
      },
      {
        "name": "وادي فراغة",
        "nameAscii": "Oued Ferragha"
      },
      {
        "name": "وادي الزناتي",
        "nameAscii": "Oued Zenati"
      },
      {
        "name": "رأس العقبة",
        "nameAscii": "Ras El Agba"
      },
      {
        "name": "الركنية",
        "nameAscii": "Roknia"
      },
      {
        "name": "سلاوة عنونة",
        "nameAscii": "Sellaoua Announa"
      },
      {
        "name": "تاملوكة",
        "nameAscii": "Tamlouka"
      }
    ]
  },
  {
    "code": "25",
    "name": "قسنطينة",
    "nameAscii": "Constantine",
    "communes": [
      {
        "name": "عين عبيد",
        "nameAscii": "Ain Abid"
      },
      {
        "name": "عين السمارة",
        "nameAscii": "Ain Smara"
      },
      {
        "name": "أبن باديس الهرية",
        "nameAscii": "Ben Badis"
      },
      {
        "name": "بني حميدان",
        "nameAscii": "Beni Hamidane"
      },
      {
        "name": "قسنطينة",
        "nameAscii": "Constantine"
      },
      {
        "name": "ديدوش مراد",
        "nameAscii": "Didouche Mourad"
      },
      {
        "name": "الخروب",
        "nameAscii": "El Khroub"
      },
      {
        "name": "حامة بوزيان",
        "nameAscii": "Hamma Bouziane"
      },
      {
        "name": "ابن زياد",
        "nameAscii": "Ibn Ziad"
      },
      {
        "name": "بوجريو مسعود",
        "nameAscii": "Messaoud Boudjeriou"
      },
      {
        "name": "أولاد رحمون",
        "nameAscii": "Ouled Rahmoun"
      },
      {
        "name": "زيغود يوسف",
        "nameAscii": "Zighoud Youcef"
      }
    ]
  },
  {
    "code": "26",
    "name": "المدية",
    "nameAscii": "Médéa",
    "communes": [
      {
        "name": "عين بوسيف",
        "nameAscii": "Ain Boucif"
      },
      {
        "name": "عين اقصير",
        "nameAscii": "Ain Ouksir"
      },
      {
        "name": "العيساوية",
        "nameAscii": "Aissaouia"
      },
      {
        "name": "عزيز",
        "nameAscii": "Aziz"
      },
      {
        "name": "بعطة",
        "nameAscii": "Baata"
      },
      {
        "name": "بن شكاو",
        "nameAscii": "Ben Chicao"
      },
      {
        "name": "بني سليمان",
        "nameAscii": "Beni Slimane"
      },
      {
        "name": "البرواقية",
        "nameAscii": "Berrouaghia"
      },
      {
        "name": "بئر بن عابد",
        "nameAscii": "Bir Ben Laabed"
      },
      {
        "name": "بوغار",
        "nameAscii": "Boghar"
      },
      {
        "name": "بوعيش",
        "nameAscii": "Bouaiche"
      },
      {
        "name": "بوعيشون",
        "nameAscii": "Bouaichoune"
      },
      {
        "name": "بوشراحيل",
        "nameAscii": "Bouchrahil"
      },
      {
        "name": "بوغزول",
        "nameAscii": "Boughzoul"
      },
      {
        "name": "بوسكن",
        "nameAscii": "Bouskene"
      },
      {
        "name": "الشهبونية",
        "nameAscii": "Chabounia"
      },
      {
        "name": "شلالة العذاورة",
        "nameAscii": "Chelalet El Adhaoura"
      },
      {
        "name": "شنيقل",
        "nameAscii": "Cheniguel"
      },
      {
        "name": "دراق",
        "nameAscii": "Derrag"
      },
      {
        "name": "جواب",
        "nameAscii": "Djouab"
      },
      {
        "name": "ذراع السمار",
        "nameAscii": "Draa Esmar"
      },
      {
        "name": "العزيزية",
        "nameAscii": "El Azizia"
      },
      {
        "name": "القلب الكبير",
        "nameAscii": "El Guelbelkebir"
      },
      {
        "name": "الحمدانية",
        "nameAscii": "El Hamdania"
      },
      {
        "name": "الحوضان",
        "nameAscii": "El Haoudane"
      },
      {
        "name": "العمارية",
        "nameAscii": "El Omaria"
      },
      {
        "name": "العوينات",
        "nameAscii": "El Ouinet"
      },
      {
        "name": "حناشة",
        "nameAscii": "Hannacha"
      },
      {
        "name": "الكاف الاخضر",
        "nameAscii": "Kef Lakhdar"
      },
      {
        "name": "خمس جوامع",
        "nameAscii": "Khams Djouamaa"
      },
      {
        "name": "قصر البخاري",
        "nameAscii": "Ksar El Boukhari"
      },
      {
        "name": "مفاتحة",
        "nameAscii": "M'fatha"
      },
      {
        "name": "مغراوة",
        "nameAscii": "Maghraoua"
      },
      {
        "name": "المدية",
        "nameAscii": "Medea"
      },
      {
        "name": "مجبر",
        "nameAscii": "Medjebar"
      },
      {
        "name": "مزغنة",
        "nameAscii": "Mezerana"
      },
      {
        "name": "ميهوب",
        "nameAscii": "Mihoub"
      },
      {
        "name": "عوامري",
        "nameAscii": "Ouamri"
      },
      {
        "name": "وادي حربيل",
        "nameAscii": "Oued Harbil"
      },
      {
        "name": "أولاد عنتر",
        "nameAscii": "Ouled Antar"
      },
      {
        "name": "أولاد بوعشرة",
        "nameAscii": "Ouled Bouachra"
      },
      {
        "name": "أولاد إبراهيم",
        "nameAscii": "Ouled Brahim"
      },
      {
        "name": "أولاد دايد",
        "nameAscii": "Ouled Deid"
      },
      {
        "name": "أولاد امعرف",
        "nameAscii": "Ouled Emaaraf"
      },
      {
        "name": "أولاد هلال",
        "nameAscii": "Ouled Hellal"
      },
      {
        "name": "أم الجليل",
        "nameAscii": "Oum El Djellil"
      },
      {
        "name": "وزرة",
        "nameAscii": "Ouzera"
      },
      {
        "name": "الربعية",
        "nameAscii": "Rebaia"
      },
      {
        "name": "السانق",
        "nameAscii": "Saneg"
      },
      {
        "name": "سدراية",
        "nameAscii": "Sedraya"
      },
      {
        "name": "سغوان",
        "nameAscii": "Seghouane"
      },
      {
        "name": "سي المحجوب",
        "nameAscii": "Si Mahdjoub"
      },
      {
        "name": "سيدي دامد",
        "nameAscii": "Sidi Demed"
      },
      {
        "name": "سيدي نعمان",
        "nameAscii": "Sidi Naamane"
      },
      {
        "name": "سيدي الربيع",
        "nameAscii": "Sidi Rabie"
      },
      {
        "name": "سيدي زهار",
        "nameAscii": "Sidi Zahar"
      },
      {
        "name": "سيدي زيان",
        "nameAscii": "Sidi Ziane"
      },
      {
        "name": "السواقي",
        "nameAscii": "Souagui"
      },
      {
        "name": "تابلاط",
        "nameAscii": "Tablat"
      },
      {
        "name": "تفراوت",
        "nameAscii": "Tafraout"
      },
      {
        "name": "تمسقيدة",
        "nameAscii": "Tamesguida"
      },
      {
        "name": "تيزي مهدي",
        "nameAscii": "Tizi Mahdi"
      },
      {
        "name": "ثلاث دوائر",
        "nameAscii": "Tletat Ed Douair"
      },
      {
        "name": "الزبيرية",
        "nameAscii": "Zoubiria"
      }
    ]
  },
  {
    "code": "27",
    "name": "مستغانم",
    "nameAscii": "Mostaganem",
    "communes": [
      {
        "name": "عشعاشة",
        "nameAscii": "Achaacha"
      },
      {
        "name": "عين بودينار",
        "nameAscii": "Ain-Boudinar"
      },
      {
        "name": "عين نويسي",
        "nameAscii": "Ain-Nouissy"
      },
      {
        "name": "عين سيدي الشريف",
        "nameAscii": "Ain-Sidi Cherif"
      },
      {
        "name": "عين تادلس",
        "nameAscii": "Ain-Tedles"
      },
      {
        "name": "بن عبد المالك رمضان",
        "nameAscii": "Benabdelmalek Ramdane"
      },
      {
        "name": "بوقيراط",
        "nameAscii": "Bouguirat"
      },
      {
        "name": "فرناقة",
        "nameAscii": "Fornaka"
      },
      {
        "name": "حجاج",
        "nameAscii": "Hadjadj"
      },
      {
        "name": "حاسي ماماش",
        "nameAscii": "Hassi Mameche"
      },
      {
        "name": "الحسيان (بني ياحي",
        "nameAscii": "Hassiane"
      },
      {
        "name": "خضرة",
        "nameAscii": "Khadra"
      },
      {
        "name": "خير الدين",
        "nameAscii": "Kheir-Eddine"
      },
      {
        "name": "منصورة",
        "nameAscii": "Mansourah"
      },
      {
        "name": "مزغران",
        "nameAscii": "Mazagran"
      },
      {
        "name": "ماسرة",
        "nameAscii": "Mesra"
      },
      {
        "name": "مستغانم",
        "nameAscii": "Mostaganem"
      },
      {
        "name": "نكمارية",
        "nameAscii": "Nekmaria"
      },
      {
        "name": "وادي الخير",
        "nameAscii": "Oued El Kheir"
      },
      {
        "name": "أولاد بوغالم",
        "nameAscii": "Ouled Boughalem"
      },
      {
        "name": "أولاد مع الله",
        "nameAscii": "Ouled-Maalah"
      },
      {
        "name": "صفصاف",
        "nameAscii": "Safsaf"
      },
      {
        "name": "صيادة",
        "nameAscii": "Sayada"
      },
      {
        "name": "سيدي علي",
        "nameAscii": "Sidi Ali"
      },
      {
        "name": "سيدي بلعطار",
        "nameAscii": "Sidi Belaattar"
      },
      {
        "name": "سيدي لخضر",
        "nameAscii": "Sidi-Lakhdar"
      },
      {
        "name": "سيرات",
        "nameAscii": "Sirat"
      },
      {
        "name": "السوافلية",
        "nameAscii": "Souaflia"
      },
      {
        "name": "سور",
        "nameAscii": "Sour"
      },
      {
        "name": "ستيدية",
        "nameAscii": "Stidia"
      },
      {
        "name": "تزقايت",
        "nameAscii": "Tazgait"
      },
      {
        "name": "الطواهرية",
        "nameAscii": "Touahria"
      }
    ]
  },
  {
    "code": "28",
    "name": "المسيلة",
    "nameAscii": "M'Sila",
    "communes": [
      {
        "name": "عين الحجل",
        "nameAscii": "Ain El Hadjel"
      },
      {
        "name": "عين الملح",
        "nameAscii": "Ain El Melh"
      },
      {
        "name": "عين فارس",
        "nameAscii": "Ain Fares"
      },
      {
        "name": "عين الخضراء",
        "nameAscii": "Ain Khadra"
      },
      {
        "name": "عين الريش",
        "nameAscii": "Ain Rich"
      },
      {
        "name": "بلعايبة",
        "nameAscii": "Belaiba"
      },
      {
        "name": "بن سرور",
        "nameAscii": "Ben Srour"
      },
      {
        "name": "بني يلمان",
        "nameAscii": "Beni Ilmane"
      },
      {
        "name": "بن زوه",
        "nameAscii": "Benzouh"
      },
      {
        "name": "برهوم",
        "nameAscii": "Berhoum"
      },
      {
        "name": "بئر فضة",
        "nameAscii": "Bir Foda"
      },
      {
        "name": "بوسعادة",
        "nameAscii": "Bou Saada"
      },
      {
        "name": "بوطي السايح",
        "nameAscii": "Bouti Sayeh"
      },
      {
        "name": "شلال",
        "nameAscii": "Chellal"
      },
      {
        "name": "دهاهنة",
        "nameAscii": "Dehahna"
      },
      {
        "name": "جبل مساعد",
        "nameAscii": "Djebel Messaad"
      },
      {
        "name": "الهامل",
        "nameAscii": "El Hamel"
      },
      {
        "name": "الحوامد",
        "nameAscii": "El Houamed"
      },
      {
        "name": "حمام الضلعة",
        "nameAscii": "Hammam Dalaa"
      },
      {
        "name": "خطوطي سد الجير",
        "nameAscii": "Khettouti Sed-El-Jir"
      },
      {
        "name": "خبانة",
        "nameAscii": "Khoubana"
      },
      {
        "name": "مسيف",
        "nameAscii": "M'cif"
      },
      {
        "name": "المسيلة",
        "nameAscii": "M'sila"
      },
      {
        "name": "المطارفة",
        "nameAscii": "M'tarfa"
      },
      {
        "name": "المعاضيد",
        "nameAscii": "Maadid"
      },
      {
        "name": "معاريف",
        "nameAscii": "Maarif"
      },
      {
        "name": "مقرة",
        "nameAscii": "Magra"
      },
      {
        "name": "امجدل",
        "nameAscii": "Medjedel"
      },
      {
        "name": "مناعة",
        "nameAscii": "Menaa"
      },
      {
        "name": "محمد بوضياف",
        "nameAscii": "Mohamed Boudiaf"
      },
      {
        "name": "ونوغة",
        "nameAscii": "Ouanougha"
      },
      {
        "name": "أولاد عدي لقبالة",
        "nameAscii": "Ouled Addi Guebala"
      },
      {
        "name": "أولاد دراج",
        "nameAscii": "Ouled Derradj"
      },
      {
        "name": "أولاد ماضي",
        "nameAscii": "Ouled Madhi"
      },
      {
        "name": "أولاد منصور",
        "nameAscii": "Ouled Mansour"
      },
      {
        "name": "أولاد سيدي ابراهيم",
        "nameAscii": "Ouled Sidi Brahim"
      },
      {
        "name": "أولاد سليمان",
        "nameAscii": "Ouled Slimane"
      },
      {
        "name": "ولتام",
        "nameAscii": "Oulteme"
      },
      {
        "name": "سيدي عيسى",
        "nameAscii": "Sidi Aissa"
      },
      {
        "name": "سيدي عامر",
        "nameAscii": "Sidi Ameur"
      },
      {
        "name": "سيدي هجرس",
        "nameAscii": "Sidi Hadjeres"
      },
      {
        "name": "سيدي امحمد",
        "nameAscii": "Sidi M'hamed"
      },
      {
        "name": "سليم",
        "nameAscii": "Slim"
      },
      {
        "name": "السوامع",
        "nameAscii": "Souamaa"
      },
      {
        "name": "تامسة",
        "nameAscii": "Tamsa"
      },
      {
        "name": "تارمونت",
        "nameAscii": "Tarmount"
      },
      {
        "name": "زرزور",
        "nameAscii": "Zarzour"
      }
    ]
  },
  {
    "code": "29",
    "name": "معسكر",
    "nameAscii": "Mascara",
    "communes": [
      {
        "name": "عين فارس",
        "nameAscii": "Ain Fares"
      },
      {
        "name": "عين فكان",
        "nameAscii": "Ain Fekan"
      },
      {
        "name": "عين فراح",
        "nameAscii": "Ain Ferah"
      },
      {
        "name": "عين أفرص",
        "nameAscii": "Ain Frass"
      },
      {
        "name": "العلايمية",
        "nameAscii": "Alaimia"
      },
      {
        "name": "عوف",
        "nameAscii": "Aouf"
      },
      {
        "name": "بنيان",
        "nameAscii": "Benian"
      },
      {
        "name": "بوهني",
        "nameAscii": "Bou Henni"
      },
      {
        "name": "بوحنيفية",
        "nameAscii": "Bouhanifia"
      },
      {
        "name": "الشرفاء",
        "nameAscii": "Chorfa"
      },
      {
        "name": "البرج",
        "nameAscii": "El Bordj"
      },
      {
        "name": "القعدة",
        "nameAscii": "El Gaada"
      },
      {
        "name": "الغمري",
        "nameAscii": "El Ghomri"
      },
      {
        "name": "القطنة",
        "nameAscii": "El Gueitena"
      },
      {
        "name": "الحشم",
        "nameAscii": "El Hachem"
      },
      {
        "name": "القرط",
        "nameAscii": "El Keurt"
      },
      {
        "name": "المأمونية",
        "nameAscii": "El Mamounia"
      },
      {
        "name": "المنور",
        "nameAscii": "El Menaouer"
      },
      {
        "name": "فراقيق",
        "nameAscii": "Ferraguig"
      },
      {
        "name": "فروحة",
        "nameAscii": "Froha"
      },
      {
        "name": "غروس",
        "nameAscii": "Gharrous"
      },
      {
        "name": "غريس",
        "nameAscii": "Ghriss"
      },
      {
        "name": "قرجوم",
        "nameAscii": "Guerdjoum"
      },
      {
        "name": "حسين",
        "nameAscii": "Hacine"
      },
      {
        "name": "خلوية",
        "nameAscii": "Khalouia"
      },
      {
        "name": "ماقضة",
        "nameAscii": "Makhda"
      },
      {
        "name": "ماوسة",
        "nameAscii": "Maoussa"
      },
      {
        "name": "معسكر",
        "nameAscii": "Mascara"
      },
      {
        "name": "المطمور",
        "nameAscii": "Matemore"
      },
      {
        "name": "مقطع الدوز",
        "nameAscii": "Mocta-Douz"
      },
      {
        "name": "المحمدية",
        "nameAscii": "Mohammadia"
      },
      {
        "name": "نسمط",
        "nameAscii": "Nesmot"
      },
      {
        "name": "عقاز",
        "nameAscii": "Oggaz"
      },
      {
        "name": "وادي الأبطال",
        "nameAscii": "Oued El Abtal"
      },
      {
        "name": "وادي التاغية",
        "nameAscii": "Oued Taria"
      },
      {
        "name": "رأس عين عميروش",
        "nameAscii": "Ras El Ain Amirouche"
      },
      {
        "name": "سجرارة",
        "nameAscii": "Sedjerara"
      },
      {
        "name": "السهايلية",
        "nameAscii": "Sehailia"
      },
      {
        "name": "سيدي عبد الجبار",
        "nameAscii": "Sidi Abdeldjebar"
      },
      {
        "name": "سيدي عبد المومن",
        "nameAscii": "Sidi Abdelmoumene"
      },
      {
        "name": "سيدي بوسعيد",
        "nameAscii": "Sidi Boussaid"
      },
      {
        "name": "سيدي قادة",
        "nameAscii": "Sidi Kada"
      },
      {
        "name": "سيق",
        "nameAscii": "Sig"
      },
      {
        "name": "تيغنيف",
        "nameAscii": "Tighennif"
      },
      {
        "name": "تيزي",
        "nameAscii": "Tizi"
      },
      {
        "name": "زهانة",
        "nameAscii": "Zahana"
      },
      {
        "name": "زلامطة",
        "nameAscii": "Zelamta"
      }
    ]
  },
  {
    "code": "30",
    "name": "ورقلة",
    "nameAscii": "Ouargla",
    "communes": [
      {
        "name": "عين البيضاء",
        "nameAscii": "Ain Beida"
      },
      {
        "name": "البرمة",
        "nameAscii": "El Borma"
      },
      {
        "name": "حاسي بن عبد الله",
        "nameAscii": "Hassi Ben Abdellah"
      },
      {
        "name": "حاسي مسعود",
        "nameAscii": "Hassi Messaoud"
      },
      {
        "name": "انقوسة",
        "nameAscii": "N'goussa"
      },
      {
        "name": "ورقلة",
        "nameAscii": "Ouargla"
      },
      {
        "name": "الرويسات",
        "nameAscii": "Rouissat"
      },
      {
        "name": "سيدي خويلد",
        "nameAscii": "Sidi Khouiled"
      }
    ]
  },
  {
    "code": "31",
    "name": "وهران",
    "nameAscii": "Oran",
    "communes": [
      {
        "name": "عين البية",
        "nameAscii": "Ain Biya"
      },
      {
        "name": "عين الكرمة",
        "nameAscii": "Ain Kerma"
      },
      {
        "name": "عين الترك",
        "nameAscii": "Ain Turk"
      },
      {
        "name": "أرزيو",
        "nameAscii": "Arzew"
      },
      {
        "name": "بن فريحة",
        "nameAscii": "Ben Freha"
      },
      {
        "name": "بطيوة",
        "nameAscii": "Bethioua"
      },
      {
        "name": "بئر الجير",
        "nameAscii": "Bir El Djir"
      },
      {
        "name": "بوفاتيس",
        "nameAscii": "Boufatis"
      },
      {
        "name": "بوسفر",
        "nameAscii": "Bousfer"
      },
      {
        "name": "بوتليليس",
        "nameAscii": "Boutlelis"
      },
      {
        "name": "العنصر",
        "nameAscii": "El Ancor"
      },
      {
        "name": "البراية",
        "nameAscii": "El Braya"
      },
      {
        "name": "الكرمة",
        "nameAscii": "El Kerma"
      },
      {
        "name": "السانية",
        "nameAscii": "Es Senia"
      },
      {
        "name": "قديل",
        "nameAscii": "Gdyel"
      },
      {
        "name": "حاسي بن عقبة",
        "nameAscii": "Hassi Ben Okba"
      },
      {
        "name": "حاسي بونيف",
        "nameAscii": "Hassi Bounif"
      },
      {
        "name": "حاسي مفسوخ",
        "nameAscii": "Hassi Mefsoukh"
      },
      {
        "name": "مرسى الحجاج",
        "nameAscii": "Marsat El Hadjadj"
      },
      {
        "name": "المرسى الكبير",
        "nameAscii": "Mers El Kebir"
      },
      {
        "name": "مسرغين",
        "nameAscii": "Messerghin"
      },
      {
        "name": "وهران",
        "nameAscii": "Oran"
      },
      {
        "name": "وادي تليلات",
        "nameAscii": "Oued Tlelat"
      },
      {
        "name": "سيدي بن يبقى",
        "nameAscii": "Sidi Ben Yebka"
      },
      {
        "name": "سيدي الشحمي",
        "nameAscii": "Sidi Chami"
      },
      {
        "name": "طفراوي",
        "nameAscii": "Tafraoui"
      }
    ]
  },
  {
    "code": "32",
    "name": "البيض",
    "nameAscii": "El Bayadh",
    "communes": [
      {
        "name": "عين العراك",
        "nameAscii": "Ain El Orak"
      },
      {
        "name": "اربوات",
        "nameAscii": "Arbaouat"
      },
      {
        "name": "بوعلام",
        "nameAscii": "Boualem"
      },
      {
        "name": "بوقطب",
        "nameAscii": "Bougtoub"
      },
      {
        "name": "بوسمغون",
        "nameAscii": "Boussemghoun"
      },
      {
        "name": "بريزينة",
        "nameAscii": "Brezina"
      },
      {
        "name": "الشقيق",
        "nameAscii": "Cheguig"
      },
      {
        "name": "شلالة",
        "nameAscii": "Chellala"
      },
      {
        "name": "البيض",
        "nameAscii": "El Bayadh"
      },
      {
        "name": "البنود",
        "nameAscii": "El Bnoud"
      },
      {
        "name": "الخيثر",
        "nameAscii": "El Kheiter"
      },
      {
        "name": "المحرة",
        "nameAscii": "El Mehara"
      },
      {
        "name": "الغاسول",
        "nameAscii": "Ghassoul"
      },
      {
        "name": "الكاف الأحمر",
        "nameAscii": "Kef El Ahmar"
      },
      {
        "name": "كراكدة",
        "nameAscii": "Krakda"
      },
      {
        "name": "الأبيض سيدي الشيخ",
        "nameAscii": "Labiodh Sidi Cheikh"
      },
      {
        "name": "رقاصة",
        "nameAscii": "Rogassa"
      },
      {
        "name": "سيدي عامر",
        "nameAscii": "Sidi Ameur"
      },
      {
        "name": "سيدي سليمان",
        "nameAscii": "Sidi Slimane"
      },
      {
        "name": "سيدي طيفور",
        "nameAscii": "Sidi Tiffour"
      },
      {
        "name": "ستيتن",
        "nameAscii": "Stitten"
      },
      {
        "name": "توسمولين",
        "nameAscii": "Tousmouline"
      }
    ]
  },
  {
    "code": "33",
    "name": "إليزي",
    "nameAscii": "Illizi",
    "communes": [
      {
        "name": "برج عمر إدريس",
        "nameAscii": "Bordj Omar Driss"
      },
      {
        "name": "دبداب",
        "nameAscii": "Debdeb"
      },
      {
        "name": "إيليزي",
        "nameAscii": "Illizi"
      },
      {
        "name": "إن أمناس",
        "nameAscii": "In Amenas"
      }
    ]
  },
  {
    "code": "34",
    "name": "برج بوعريريج",
    "nameAscii": "Bordj Bou Arreridj",
    "communes": [
      {
        "name": "عين تاغروت",
        "nameAscii": "Ain Taghrout"
      },
      {
        "name": "عين تسرة",
        "nameAscii": "Ain Tesra"
      },
      {
        "name": "برج بوعريرج",
        "nameAscii": "B. B. Arreridj"
      },
      {
        "name": "بليمور",
        "nameAscii": "Belimour"
      },
      {
        "name": "بن داود",
        "nameAscii": "Ben Daoud"
      },
      {
        "name": "بئر قاصد علي",
        "nameAscii": "Bir Kasdali"
      },
      {
        "name": "برج الغدير",
        "nameAscii": "Bordj Ghedir"
      },
      {
        "name": "برج زمورة",
        "nameAscii": "Bordj Zemmoura"
      },
      {
        "name": "القلة",
        "nameAscii": "Colla"
      },
      {
        "name": "جعافرة",
        "nameAscii": "Djaafra"
      },
      {
        "name": "الياشير",
        "nameAscii": "El Achir"
      },
      {
        "name": "العناصر",
        "nameAscii": "El Annasseur"
      },
      {
        "name": "العش",
        "nameAscii": "El Euch"
      },
      {
        "name": "المهير",
        "nameAscii": "El M'hir"
      },
      {
        "name": "الماين",
        "nameAscii": "El Main"
      },
      {
        "name": "الحمادية",
        "nameAscii": "Elhammadia"
      },
      {
        "name": "غيلاسة",
        "nameAscii": "Ghailasa"
      },
      {
        "name": "حرازة",
        "nameAscii": "Haraza"
      },
      {
        "name": "حسناوة",
        "nameAscii": "Hasnaoua"
      },
      {
        "name": "خليل",
        "nameAscii": "Khelil"
      },
      {
        "name": "القصور",
        "nameAscii": "Ksour"
      },
      {
        "name": "المنصورة",
        "nameAscii": "Mansoura"
      },
      {
        "name": "مجانة",
        "nameAscii": "Medjana"
      },
      {
        "name": "أولاد أبراهم",
        "nameAscii": "Ouled Brahem"
      },
      {
        "name": "أولاد دحمان",
        "nameAscii": "Ouled Dahmane"
      },
      {
        "name": "أولاد سيدي ابراهيم",
        "nameAscii": "Ouled Sidi-Brahim"
      },
      {
        "name": "الرابطة",
        "nameAscii": "Rabta"
      },
      {
        "name": "رأس الوادي",
        "nameAscii": "Ras El Oued"
      },
      {
        "name": "سيدي أمبارك",
        "nameAscii": "Sidi-Embarek"
      },
      {
        "name": "تقلعيت",
        "nameAscii": "Taglait"
      },
      {
        "name": "تسامرت",
        "nameAscii": "Tassamert"
      },
      {
        "name": "تفرق",
        "nameAscii": "Tefreg"
      },
      {
        "name": "ثنية النصر",
        "nameAscii": "Teniet En Nasr"
      },
      {
        "name": "تيكستار",
        "nameAscii": "Tixter"
      }
    ]
  },
  {
    "code": "35",
    "name": "بومرداس",
    "nameAscii": "Boumerdès",
    "communes": [
      {
        "name": "أعفير",
        "nameAscii": "Afir"
      },
      {
        "name": "عمال",
        "nameAscii": "Ammal"
      },
      {
        "name": "بغلية",
        "nameAscii": "Baghlia"
      },
      {
        "name": "بن شود",
        "nameAscii": "Ben Choud"
      },
      {
        "name": "بني عمران",
        "nameAscii": "Beni Amrane"
      },
      {
        "name": "برج منايل",
        "nameAscii": "Bordj Menaiel"
      },
      {
        "name": "بودواو",
        "nameAscii": "Boudouaou"
      },
      {
        "name": "بودواو البحري",
        "nameAscii": "Boudouaou El Bahri"
      },
      {
        "name": "بومرداس",
        "nameAscii": "Boumerdes"
      },
      {
        "name": "بوزقزة قدارة",
        "nameAscii": "Bouzegza Keddara"
      },
      {
        "name": "شعبة العامر",
        "nameAscii": "Chabet El Ameur"
      },
      {
        "name": "قورصو",
        "nameAscii": "Corso"
      },
      {
        "name": "دلس",
        "nameAscii": "Dellys"
      },
      {
        "name": "جنات",
        "nameAscii": "Djinet"
      },
      {
        "name": "الخروبة",
        "nameAscii": "El Kharrouba"
      },
      {
        "name": "حمادي",
        "nameAscii": "Hammedi"
      },
      {
        "name": "يسر",
        "nameAscii": "Isser"
      },
      {
        "name": "خميس الخشنة",
        "nameAscii": "Khemis El Khechna"
      },
      {
        "name": "الاربعطاش",
        "nameAscii": "Larbatache"
      },
      {
        "name": "لقاطة",
        "nameAscii": "Leghata"
      },
      {
        "name": "الناصرية",
        "nameAscii": "Naciria"
      },
      {
        "name": "أولاد عيسى",
        "nameAscii": "Ouled Aissa"
      },
      {
        "name": "أولاد هداج",
        "nameAscii": "Ouled Hedadj"
      },
      {
        "name": "أولاد موسى",
        "nameAscii": "Ouled Moussa"
      },
      {
        "name": "سي مصطفى",
        "nameAscii": "Si Mustapha"
      },
      {
        "name": "سيدي داود",
        "nameAscii": "Sidi Daoud"
      },
      {
        "name": "سوق الحد",
        "nameAscii": "Souk El Had"
      },
      {
        "name": "تاورقة",
        "nameAscii": "Taourga"
      },
      {
        "name": "الثنية",
        "nameAscii": "Thenia"
      },
      {
        "name": "تيجلابين",
        "nameAscii": "Tidjelabine"
      },
      {
        "name": "تيمزريت",
        "nameAscii": "Timezrit"
      },
      {
        "name": "زموري",
        "nameAscii": "Zemmouri"
      }
    ]
  },
  {
    "code": "36",
    "name": "الطارف",
    "nameAscii": "El Tarf",
    "communes": [
      {
        "name": "عين العسل",
        "nameAscii": "Ain El Assel"
      },
      {
        "name": "عين الكرمة",
        "nameAscii": "Ain Kerma"
      },
      {
        "name": "عصفور",
        "nameAscii": "Asfour"
      },
      {
        "name": "بن مهيدي",
        "nameAscii": "Ben M Hidi"
      },
      {
        "name": "بريحان",
        "nameAscii": "Berrihane"
      },
      {
        "name": "البسباس",
        "nameAscii": "Besbes"
      },
      {
        "name": "بوقوس",
        "nameAscii": "Bougous"
      },
      {
        "name": "بوحجار",
        "nameAscii": "Bouhadjar"
      },
      {
        "name": "بوثلجة",
        "nameAscii": "Bouteldja"
      },
      {
        "name": "شبيطة مختار",
        "nameAscii": "Chebaita Mokhtar"
      },
      {
        "name": "الشافية",
        "nameAscii": "Chefia"
      },
      {
        "name": "شحاني",
        "nameAscii": "Chihani"
      },
      {
        "name": "الذرعـان",
        "nameAscii": "Drean"
      },
      {
        "name": "الشط",
        "nameAscii": "Echatt"
      },
      {
        "name": "العيون",
        "nameAscii": "El Aioun"
      },
      {
        "name": "القالة",
        "nameAscii": "El Kala"
      },
      {
        "name": "الطارف",
        "nameAscii": "El Tarf"
      },
      {
        "name": "حمام بني صالح",
        "nameAscii": "Hammam Beni Salah"
      },
      {
        "name": "بحيرة الطيور",
        "nameAscii": "Lac Des Oiseaux"
      },
      {
        "name": "وادي الزيتون",
        "nameAscii": "Oued Zitoun"
      },
      {
        "name": "رمل السوق",
        "nameAscii": "Raml Souk"
      },
      {
        "name": "السوارخ",
        "nameAscii": "Souarekh"
      },
      {
        "name": "زريزر",
        "nameAscii": "Zerizer"
      },
      {
        "name": "الزيتونة",
        "nameAscii": "Zitouna"
      }
    ]
  },
  {
    "code": "37",
    "name": "تندوف",
    "nameAscii": "Tindouf",
    "communes": [
      {
        "name": "أم العسل",
        "nameAscii": "Oum El Assel"
      },
      {
        "name": "تندوف",
        "nameAscii": "Tindouf"
      }
    ]
  },
  {
    "code": "38",
    "name": "تيسمسيلت",
    "nameAscii": "Tissemsilt",
    "communes": [
      {
        "name": "عماري",
        "nameAscii": "Ammari"
      },
      {
        "name": "بني شعيب",
        "nameAscii": "Beni Chaib"
      },
      {
        "name": "بني لحسن",
        "nameAscii": "Beni Lahcene"
      },
      {
        "name": "برج بونعامة",
        "nameAscii": "Bordj Bounaama"
      },
      {
        "name": "برج الأمير عبد القادر",
        "nameAscii": "Bordj El Emir Abdelkader"
      },
      {
        "name": "بوقائد",
        "nameAscii": "Boucaid"
      },
      {
        "name": "خميستي",
        "nameAscii": "Khemisti"
      },
      {
        "name": "الأربعاء",
        "nameAscii": "Larbaa"
      },
      {
        "name": "لرجام",
        "nameAscii": "Lardjem"
      },
      {
        "name": "العيون",
        "nameAscii": "Layoune"
      },
      {
        "name": "الأزهرية",
        "nameAscii": "Lazharia"
      },
      {
        "name": "المعاصم",
        "nameAscii": "Maacem"
      },
      {
        "name": "الملعب",
        "nameAscii": "Melaab"
      },
      {
        "name": "أولاد بسام",
        "nameAscii": "Ouled Bessam"
      },
      {
        "name": "سيدي عابد",
        "nameAscii": "Sidi Abed"
      },
      {
        "name": "سيدي بوتوشنت",
        "nameAscii": "Sidi Boutouchent"
      },
      {
        "name": "سيدي العنتري",
        "nameAscii": "Sidi Lantri"
      },
      {
        "name": "سيدي سليمان",
        "nameAscii": "Sidi Slimane"
      },
      {
        "name": "تملاحت",
        "nameAscii": "Tamellahet"
      },
      {
        "name": "ثنية الاحد",
        "nameAscii": "Theniet El Had"
      },
      {
        "name": "تيسمسيلت",
        "nameAscii": "Tissemsilt"
      },
      {
        "name": "اليوسفية",
        "nameAscii": "Youssoufia"
      }
    ]
  },
  {
    "code": "39",
    "name": "الوادي",
    "nameAscii": "El Oued",
    "communes": [
      {
        "name": "البياضة",
        "nameAscii": "Bayadha"
      },
      {
        "name": "بن قشة",
        "nameAscii": "Ben Guecha"
      },
      {
        "name": "الدبيلة",
        "nameAscii": "Debila"
      },
      {
        "name": "دوار الماء",
        "nameAscii": "Douar El Maa"
      },
      {
        "name": "العقلة",
        "nameAscii": "El Ogla"
      },
      {
        "name": "الوادي",
        "nameAscii": "El-Oued"
      },
      {
        "name": "قمار",
        "nameAscii": "Guemar"
      },
      {
        "name": "الحمراية",
        "nameAscii": "Hamraia"
      },
      {
        "name": "حساني عبد الكريم",
        "nameAscii": "Hassani Abdelkrim"
      },
      {
        "name": "حاسي خليفة",
        "nameAscii": "Hassi Khalifa"
      },
      {
        "name": "كوينين",
        "nameAscii": "Kouinine"
      },
      {
        "name": "المقرن",
        "nameAscii": "Magrane"
      },
      {
        "name": "اميه وانسة",
        "nameAscii": "Mih Ouansa"
      },
      {
        "name": "النخلة",
        "nameAscii": "Nakhla"
      },
      {
        "name": "وادي العلندة",
        "nameAscii": "Oued El Alenda"
      },
      {
        "name": "ورماس",
        "nameAscii": "Ourmes"
      },
      {
        "name": "الرقيبة",
        "nameAscii": "Reguiba"
      },
      {
        "name": "الرباح",
        "nameAscii": "Robbah"
      },
      {
        "name": "سيدي عون",
        "nameAscii": "Sidi Aoun"
      },
      {
        "name": "تغزوت",
        "nameAscii": "Taghzout"
      },
      {
        "name": "الطالب العربي",
        "nameAscii": "Taleb Larbi"
      },
      {
        "name": "الطريفاوي",
        "nameAscii": "Trifaoui"
      }
    ]
  },
  {
    "code": "40",
    "name": "خنشلة",
    "nameAscii": "Khenchela",
    "communes": [
      {
        "name": "عين الطويلة",
        "nameAscii": "Ain Touila"
      },
      {
        "name": "بابار",
        "nameAscii": "Babar"
      },
      {
        "name": "بغاي",
        "nameAscii": "Baghai"
      },
      {
        "name": "بوحمامة",
        "nameAscii": "Bouhmama"
      },
      {
        "name": "ششار",
        "nameAscii": "Chechar"
      },
      {
        "name": "شلية",
        "nameAscii": "Chelia"
      },
      {
        "name": "جلال",
        "nameAscii": "Djellal"
      },
      {
        "name": "الحامة",
        "nameAscii": "El Hamma"
      },
      {
        "name": "المحمل",
        "nameAscii": "El Mahmal"
      },
      {
        "name": "الولجة",
        "nameAscii": "El Oueldja"
      },
      {
        "name": "انسيغة",
        "nameAscii": "Ensigha"
      },
      {
        "name": "قايس",
        "nameAscii": "Kais"
      },
      {
        "name": "خنشلة",
        "nameAscii": "Khenchela"
      },
      {
        "name": "خيران",
        "nameAscii": "Khirane"
      },
      {
        "name": "مصارة",
        "nameAscii": "M'sara"
      },
      {
        "name": "متوسة",
        "nameAscii": "M'toussa"
      },
      {
        "name": "أولاد رشاش",
        "nameAscii": "Ouled Rechache"
      },
      {
        "name": "الرميلة",
        "nameAscii": "Remila"
      },
      {
        "name": "طامزة",
        "nameAscii": "Tamza"
      },
      {
        "name": "تاوزيانت",
        "nameAscii": "Taouzianat"
      },
      {
        "name": "يابوس",
        "nameAscii": "Yabous"
      }
    ]
  },
  {
    "code": "41",
    "name": "سوق أهراس",
    "nameAscii": "Souk Ahras",
    "communes": [
      {
        "name": "عين سلطان",
        "nameAscii": "Ain Soltane"
      },
      {
        "name": "عين الزانة",
        "nameAscii": "Ain Zana"
      },
      {
        "name": "بئر بوحوش",
        "nameAscii": "Bir Bouhouche"
      },
      {
        "name": "الدريعة",
        "nameAscii": "Drea"
      },
      {
        "name": "الحدادة",
        "nameAscii": "Haddada"
      },
      {
        "name": "الحنانشة",
        "nameAscii": "Hanencha"
      },
      {
        "name": "الخضارة",
        "nameAscii": "Khedara"
      },
      {
        "name": "خميسة",
        "nameAscii": "Khemissa"
      },
      {
        "name": "مداوروش",
        "nameAscii": "M'daourouche"
      },
      {
        "name": "المشروحة",
        "nameAscii": "Machroha"
      },
      {
        "name": "المراهنة",
        "nameAscii": "Merahna"
      },
      {
        "name": "وادي الكبريت",
        "nameAscii": "Oued Kebrit"
      },
      {
        "name": "ويلان",
        "nameAscii": "Ouillen"
      },
      {
        "name": "أولاد إدريس",
        "nameAscii": "Ouled Driss"
      },
      {
        "name": "أولاد مومن",
        "nameAscii": "Ouled Moumen"
      },
      {
        "name": "أم العظايم",
        "nameAscii": "Oum El Adhaim"
      },
      {
        "name": "الراقوبة",
        "nameAscii": "Ragouba"
      },
      {
        "name": "سافل الويدان",
        "nameAscii": "Safel El Ouiden"
      },
      {
        "name": "سدراتة",
        "nameAscii": "Sedrata"
      },
      {
        "name": "سيدي فرج",
        "nameAscii": "Sidi Fredj"
      },
      {
        "name": "سوق أهراس",
        "nameAscii": "Souk Ahras"
      },
      {
        "name": "تاورة",
        "nameAscii": "Taoura"
      },
      {
        "name": "ترقالت",
        "nameAscii": "Terraguelt"
      },
      {
        "name": "تيفاش",
        "nameAscii": "Tiffech"
      },
      {
        "name": "الزعرورية",
        "nameAscii": "Zaarouria"
      },
      {
        "name": "الزوابي",
        "nameAscii": "Zouabi"
      }
    ]
  },
  {
    "code": "42",
    "name": "تيبازة",
    "nameAscii": "Tipaza",
    "communes": [
      {
        "name": "أغبال",
        "nameAscii": "Aghbal"
      },
      {
        "name": "أحمر العين",
        "nameAscii": "Ahmer El Ain"
      },
      {
        "name": "عين تاقورايت",
        "nameAscii": "Ain Tagourait"
      },
      {
        "name": "الحطاطبة",
        "nameAscii": "Attatba"
      },
      {
        "name": "بني ميلك",
        "nameAscii": "Beni Mileuk"
      },
      {
        "name": "بوهارون",
        "nameAscii": "Bou Haroun"
      },
      {
        "name": "بواسماعيل",
        "nameAscii": "Bou Ismail"
      },
      {
        "name": "بورقيقة",
        "nameAscii": "Bourkika"
      },
      {
        "name": "الشعيبة",
        "nameAscii": "Chaiba"
      },
      {
        "name": "شرشال",
        "nameAscii": "Cherchell"
      },
      {
        "name": "الداموس",
        "nameAscii": "Damous"
      },
      {
        "name": "دواودة",
        "nameAscii": "Douaouda"
      },
      {
        "name": "فوكة",
        "nameAscii": "Fouka"
      },
      {
        "name": "قوراية",
        "nameAscii": "Gouraya"
      },
      {
        "name": "حجوط",
        "nameAscii": "Hadjout"
      },
      {
        "name": "حجرة النص",
        "nameAscii": "Hadjret Ennous"
      },
      {
        "name": "خميستي",
        "nameAscii": "Khemisti"
      },
      {
        "name": "القليعة",
        "nameAscii": "Kolea"
      },
      {
        "name": "الأرهاط",
        "nameAscii": "Larhat"
      },
      {
        "name": "مناصر",
        "nameAscii": "Menaceur"
      },
      {
        "name": "مراد",
        "nameAscii": "Merad"
      },
      {
        "name": "مسلمون",
        "nameAscii": "Messelmoun"
      },
      {
        "name": "الناظور",
        "nameAscii": "Nador"
      },
      {
        "name": "سيدي غيلاس",
        "nameAscii": "Sidi Ghiles"
      },
      {
        "name": "سيدي راشد",
        "nameAscii": "Sidi Rached"
      },
      {
        "name": "سيدي سميان",
        "nameAscii": "Sidi Semiane"
      },
      {
        "name": "سيدي عامر",
        "nameAscii": "Sidi-Amar"
      },
      {
        "name": "تيبازة",
        "nameAscii": "Tipaza"
      }
    ]
  },
  {
    "code": "43",
    "name": "ميلة",
    "nameAscii": "Mila",
    "communes": [
      {
        "name": "أحمد راشدي",
        "nameAscii": "Ahmed Rachedi"
      },
      {
        "name": " عين البيضاء أحريش",
        "nameAscii": "Ain Beida Harriche"
      },
      {
        "name": "عين الملوك",
        "nameAscii": "Ain Mellouk"
      },
      {
        "name": "عين التين",
        "nameAscii": "Ain Tine"
      },
      {
        "name": "اعميرة اراس",
        "nameAscii": "Amira Arres"
      },
      {
        "name": "بن يحي عبد الرحمن",
        "nameAscii": "Benyahia Abderrahmane"
      },
      {
        "name": "بوحاتم",
        "nameAscii": "Bouhatem"
      },
      {
        "name": "شلغوم العيد",
        "nameAscii": "Chelghoum Laid"
      },
      {
        "name": "الشيقارة",
        "nameAscii": "Chigara"
      },
      {
        "name": "دراحي بوصلاح",
        "nameAscii": "Derrahi Bousselah"
      },
      {
        "name": "العياضي برباس",
        "nameAscii": "El Ayadi Barbes"
      },
      {
        "name": "مشيرة",
        "nameAscii": "El Mechira"
      },
      {
        "name": "فرجيوة",
        "nameAscii": "Ferdjioua"
      },
      {
        "name": "القرارم قوقة",
        "nameAscii": "Grarem Gouga"
      },
      {
        "name": "حمالة",
        "nameAscii": "Hamala"
      },
      {
        "name": "ميلة",
        "nameAscii": "Mila"
      },
      {
        "name": "مينار زارزة",
        "nameAscii": "Minar Zarza"
      },
      {
        "name": "وادي العثمانية",
        "nameAscii": "Oued Athmenia"
      },
      {
        "name": "وادي النجاء",
        "nameAscii": "Oued Endja"
      },
      {
        "name": "وادي سقان",
        "nameAscii": "Oued Seguen"
      },
      {
        "name": "أولاد اخلوف",
        "nameAscii": "Ouled Khalouf"
      },
      {
        "name": "الرواشد",
        "nameAscii": "Rouached"
      },
      {
        "name": "سيدي خليفة",
        "nameAscii": "Sidi Khelifa"
      },
      {
        "name": "سيدي مروان",
        "nameAscii": "Sidi Merouane"
      },
      {
        "name": "تاجنانت",
        "nameAscii": "Tadjenanet"
      },
      {
        "name": "تسدان حدادة",
        "nameAscii": "Tassadane Haddada"
      },
      {
        "name": "تسالة لمطاعي",
        "nameAscii": "Tassala Lematai"
      },
      {
        "name": "التلاغمة",
        "nameAscii": "Teleghma"
      },
      {
        "name": "ترعي باينان",
        "nameAscii": "Terrai Bainen"
      },
      {
        "name": "تيبرقنت",
        "nameAscii": "Tiberguent"
      },
      {
        "name": "يحي بني قشة",
        "nameAscii": "Yahia Beniguecha"
      },
      {
        "name": "زغاية",
        "nameAscii": "Zeghaia"
      }
    ]
  },
  {
    "code": "44",
    "name": "عين الدفلة",
    "nameAscii": "Aïn Defla",
    "communes": [
      {
        "name": "عين البنيان",
        "nameAscii": "Ain-Benian"
      },
      {
        "name": "عين بويحيى",
        "nameAscii": "Ain-Bouyahia"
      },
      {
        "name": "عين الدفلى",
        "nameAscii": "Ain-Defla"
      },
      {
        "name": "عين الاشياخ",
        "nameAscii": "Ain-Lechiakh"
      },
      {
        "name": "عين السلطان",
        "nameAscii": "Ain-Soltane"
      },
      {
        "name": "عين التركي",
        "nameAscii": "Ain-Torki"
      },
      {
        "name": "عريب",
        "nameAscii": "Arib"
      },
      {
        "name": "بطحية",
        "nameAscii": "Bathia"
      },
      {
        "name": "بلعاص",
        "nameAscii": "Belaas"
      },
      {
        "name": "بن علال",
        "nameAscii": "Ben Allal"
      },
      {
        "name": "بئر ولد خليفة",
        "nameAscii": "Bir-Ould-Khelifa"
      },
      {
        "name": "بربوش",
        "nameAscii": "Birbouche"
      },
      {
        "name": "برج الأمير خالد",
        "nameAscii": "Bordj-Emir-Khaled"
      },
      {
        "name": "بومدفع",
        "nameAscii": "Boumedfaa"
      },
      {
        "name": "بوراشد",
        "nameAscii": "Bourached"
      },
      {
        "name": "جليدة",
        "nameAscii": "Djelida"
      },
      {
        "name": "جمعة أولاد الشيخ",
        "nameAscii": "Djemaa Ouled Cheikh"
      },
      {
        "name": "جندل",
        "nameAscii": "Djendel"
      },
      {
        "name": "العبادية",
        "nameAscii": "El-Abadia"
      },
      {
        "name": "العامرة",
        "nameAscii": "El-Amra"
      },
      {
        "name": "العطاف",
        "nameAscii": "El-Attaf"
      },
      {
        "name": "الماين",
        "nameAscii": "El-Maine"
      },
      {
        "name": "حمام ريغة",
        "nameAscii": "Hammam-Righa"
      },
      {
        "name": "الحسانية",
        "nameAscii": "Hassania"
      },
      {
        "name": "الحسينية",
        "nameAscii": "Hoceinia"
      },
      {
        "name": "خميس مليانة",
        "nameAscii": "Khemis-Miliana"
      },
      {
        "name": "المخاطرية",
        "nameAscii": "Mekhatria"
      },
      {
        "name": "مليانة",
        "nameAscii": "Miliana"
      },
      {
        "name": "وادي الشرفاء",
        "nameAscii": "Oued Chorfa"
      },
      {
        "name": "واد الجمعة",
        "nameAscii": "Oued Djemaa"
      },
      {
        "name": "الروينة",
        "nameAscii": "Rouina"
      },
      {
        "name": "سيدي الأخضر",
        "nameAscii": "Sidi-Lakhdar"
      },
      {
        "name": "تاشتة زقاغة",
        "nameAscii": "Tacheta Zegagha"
      },
      {
        "name": "طارق بن زياد",
        "nameAscii": "Tarik-Ibn-Ziad"
      },
      {
        "name": "تبركانين",
        "nameAscii": "Tiberkanine"
      },
      {
        "name": "زدين",
        "nameAscii": "Zeddine"
      }
    ]
  },
  {
    "code": "45",
    "name": "النعامة",
    "nameAscii": "Naâma",
    "communes": [
      {
        "name": "عين بن خليل",
        "nameAscii": "Ain Ben Khelil"
      },
      {
        "name": "عين الصفراء",
        "nameAscii": "Ain Sefra"
      },
      {
        "name": "عسلة",
        "nameAscii": "Asla"
      },
      {
        "name": "جنين بورزق",
        "nameAscii": "Djenienne Bourezg"
      },
      {
        "name": "البيوض",
        "nameAscii": "El Biodh"
      },
      {
        "name": "القصدير",
        "nameAscii": "Kasdir"
      },
      {
        "name": "مكمن بن عمار",
        "nameAscii": "Makmen Ben Amar"
      },
      {
        "name": "المشرية",
        "nameAscii": "Mecheria"
      },
      {
        "name": "مغرار",
        "nameAscii": "Moghrar"
      },
      {
        "name": "النعامة",
        "nameAscii": "Naama"
      },
      {
        "name": "سفيسيفة",
        "nameAscii": "Sfissifa"
      },
      {
        "name": "تيوت",
        "nameAscii": "Tiout"
      }
    ]
  },
  {
    "code": "46",
    "name": "عين تيموشنت",
    "nameAscii": "Aïn Témouchent",
    "communes": [
      {
        "name": "أغلال",
        "nameAscii": "Aghlal"
      },
      {
        "name": "عين الأربعاء",
        "nameAscii": "Ain El Arbaa"
      },
      {
        "name": "عين الكيحل",
        "nameAscii": "Ain Kihal"
      },
      {
        "name": "عين تموشنت",
        "nameAscii": "Ain Temouchent"
      },
      {
        "name": "عين الطلبة",
        "nameAscii": "Ain Tolba"
      },
      {
        "name": "عقب الليل",
        "nameAscii": "Aoubellil"
      },
      {
        "name": "بني صاف",
        "nameAscii": "Beni Saf"
      },
      {
        "name": "بوزجار",
        "nameAscii": "Bouzedjar"
      },
      {
        "name": "شعبة اللحم",
        "nameAscii": "Chaabat El Ham"
      },
      {
        "name": "شنتوف",
        "nameAscii": "Chentouf"
      },
      {
        "name": "العامرية",
        "nameAscii": "El Amria"
      },
      {
        "name": "المالح",
        "nameAscii": "El Maleh"
      },
      {
        "name": "المساعيد",
        "nameAscii": "El Messaid"
      },
      {
        "name": "الأمير عبد القادر",
        "nameAscii": "Emir Abdelkader"
      },
      {
        "name": "حمام بوحجر",
        "nameAscii": "Hammam Bou Hadjar"
      },
      {
        "name": "الحساسنة",
        "nameAscii": "Hassasna"
      },
      {
        "name": "حاسي الغلة",
        "nameAscii": "Hassi El Ghella"
      },
      {
        "name": "وادي برقش",
        "nameAscii": "Oued Berkeche"
      },
      {
        "name": "وادي الصباح",
        "nameAscii": "Oued Sebbah"
      },
      {
        "name": "أولاد بوجمعة",
        "nameAscii": "Ouled Boudjemaa"
      },
      {
        "name": "أولاد الكيحل",
        "nameAscii": "Ouled Kihal"
      },
      {
        "name": "ولهاصة الغرابة",
        "nameAscii": "Oulhaca El Gheraba"
      },
      {
        "name": "سيدي بن عدة",
        "nameAscii": "Sidi Ben Adda"
      },
      {
        "name": "سيدي بومدين",
        "nameAscii": "Sidi Boumediene"
      },
      {
        "name": "سيدي ورياش",
        "nameAscii": "Sidi Ouriache"
      },
      {
        "name": "سيدي صافي",
        "nameAscii": "Sidi Safi"
      },
      {
        "name": "تامزورة",
        "nameAscii": "Tamzoura"
      },
      {
        "name": "تارقة",
        "nameAscii": "Terga"
      }
    ]
  },
  {
    "code": "47",
    "name": "غرداية",
    "nameAscii": "Ghardaïa",
    "communes": [
      {
        "name": "بريان",
        "nameAscii": "Berriane"
      },
      {
        "name": "بونورة",
        "nameAscii": "Bounoura"
      },
      {
        "name": "ضاية بن ضحوة",
        "nameAscii": "Dhayet Bendhahoua"
      },
      {
        "name": "العطف",
        "nameAscii": "El Atteuf"
      },
      {
        "name": "القرارة",
        "nameAscii": "El Guerrara"
      },
      {
        "name": "غرداية",
        "nameAscii": "Ghardaia"
      },
      {
        "name": "المنصورة",
        "nameAscii": "Mansoura"
      },
      {
        "name": "متليلي",
        "nameAscii": "Metlili"
      },
      {
        "name": "سبسب",
        "nameAscii": "Sebseb"
      },
      {
        "name": "زلفانة",
        "nameAscii": "Zelfana"
      }
    ]
  },
  {
    "code": "48",
    "name": "غليزان",
    "nameAscii": "Relizane",
    "communes": [
      {
        "name": "عين الرحمة",
        "nameAscii": "Ain Rahma"
      },
      {
        "name": "عين طارق",
        "nameAscii": "Ain-Tarek"
      },
      {
        "name": "عمي موسى",
        "nameAscii": "Ammi Moussa"
      },
      {
        "name": "بلعسل بوزقزة",
        "nameAscii": "Belaassel Bouzagza"
      },
      {
        "name": "بن داود",
        "nameAscii": "Bendaoud"
      },
      {
        "name": "بني درقن",
        "nameAscii": "Beni Dergoun"
      },
      {
        "name": "بني زنطيس",
        "nameAscii": "Beni Zentis"
      },
      {
        "name": "دار بن عبد الله",
        "nameAscii": "Dar Ben Abdelah"
      },
      {
        "name": "جديوية",
        "nameAscii": "Djidiouia"
      },
      {
        "name": "الحمادنة",
        "nameAscii": "El H'madna"
      },
      {
        "name": "الحاسي",
        "nameAscii": "El Hassi"
      },
      {
        "name": "الولجة",
        "nameAscii": "El Ouldja"
      },
      {
        "name": "القطار",
        "nameAscii": "El-Guettar"
      },
      {
        "name": "المطمر",
        "nameAscii": "El-Matmar"
      },
      {
        "name": "حد الشكالة",
        "nameAscii": "Had Echkalla"
      },
      {
        "name": "حمري",
        "nameAscii": "Hamri"
      },
      {
        "name": "القلعة",
        "nameAscii": "Kalaa"
      },
      {
        "name": "لحلاف",
        "nameAscii": "Lahlef"
      },
      {
        "name": "مازونة",
        "nameAscii": "Mazouna"
      },
      {
        "name": "مديونة",
        "nameAscii": "Mediouna"
      },
      {
        "name": "منداس",
        "nameAscii": "Mendes"
      },
      {
        "name": "مرجة سيدي عابد",
        "nameAscii": "Merdja Sidi Abed"
      },
      {
        "name": "واريزان",
        "nameAscii": "Ouarizane"
      },
      {
        "name": "وادي الجمعة",
        "nameAscii": "Oued El Djemaa"
      },
      {
        "name": "وادي السلام",
        "nameAscii": "Oued Essalem"
      },
      {
        "name": "وادي رهيو",
        "nameAscii": "Oued-Rhiou"
      },
      {
        "name": "أولاد يعيش",
        "nameAscii": "Ouled Aiche"
      },
      {
        "name": "أولاد سيدي الميهوب",
        "nameAscii": "Ouled Sidi Mihoub"
      },
      {
        "name": "الرمكة",
        "nameAscii": "Ramka"
      },
      {
        "name": "غليزان",
        "nameAscii": "Relizane"
      },
      {
        "name": "سيدي خطاب",
        "nameAscii": "Sidi Khettab"
      },
      {
        "name": "سيدي لزرق",
        "nameAscii": "Sidi Lazreg"
      },
      {
        "name": "سيدي أمحمد بن علي",
        "nameAscii": "Sidi M'hamed Benali"
      },
      {
        "name": "سيدي امحمد بن عودة",
        "nameAscii": "Sidi M'hamed Benaouda"
      },
      {
        "name": "سيدي سعادة",
        "nameAscii": "Sidi Saada"
      },
      {
        "name": "سوق الحد",
        "nameAscii": "Souk El Had"
      },
      {
        "name": "يلل",
        "nameAscii": "Yellel"
      },
      {
        "name": "زمورة",
        "nameAscii": "Zemmoura"
      }
    ]
  },
  {
    "code": "49",
    "name": "تيميمون",
    "nameAscii": "Timimoun",
    "communes": [
      {
        "name": "أوقروت",
        "nameAscii": "Aougrout"
      },
      {
        "name": "شروين",
        "nameAscii": "Charouine"
      },
      {
        "name": "دلدول",
        "nameAscii": "Deldoul"
      },
      {
        "name": "قصر قدور",
        "nameAscii": "Ksar Kaddour"
      },
      {
        "name": "المطارفة",
        "nameAscii": "Metarfa"
      },
      {
        "name": "أولاد عيسى",
        "nameAscii": "Ouled Aissa"
      },
      {
        "name": "أولاد السعيد",
        "nameAscii": "Ouled Said"
      },
      {
        "name": "طالمين",
        "nameAscii": "Talmine"
      },
      {
        "name": "تيميمون",
        "nameAscii": "Timimoun"
      },
      {
        "name": "تنركوك",
        "nameAscii": "Tinerkouk"
      }
    ]
  },
  {
    "code": "50",
    "name": "برج باجي مختار",
    "nameAscii": "Bordj Badji Mokhtar",
    "communes": [
      {
        "name": "برج باجي مختار",
        "nameAscii": "Bordj Badji Mokhtar"
      },
      {
        "name": "تيمياوين",
        "nameAscii": "Timiaouine"
      }
    ]
  },
  {
    "code": "51",
    "name": "أولاد جلال",
    "nameAscii": "Ouled Djellal",
    "communes": [
      {
        "name": "بسباس",
        "nameAscii": "Besbes"
      },
      {
        "name": "الشعيبة",
        "nameAscii": "Chaiba"
      },
      {
        "name": "الدوسن",
        "nameAscii": "Doucen"
      },
      {
        "name": "أولاد جلال",
        "nameAscii": "Ouled Djellal"
      },
      {
        "name": "رأس الميعاد",
        "nameAscii": "Ras El Miad"
      },
      {
        "name": "سيدي خالد",
        "nameAscii": "Sidi Khaled"
      }
    ]
  },
  {
    "code": "52",
    "name": "بني عباس",
    "nameAscii": "Béni Abbès",
    "communes": [
      {
        "name": "بني عباس",
        "nameAscii": "Beni-Abbes"
      },
      {
        "name": "بن يخلف",
        "nameAscii": "Beni-Ikhlef"
      },
      {
        "name": "الواتة",
        "nameAscii": "El Ouata"
      },
      {
        "name": "إقلي",
        "nameAscii": "Igli"
      },
      {
        "name": "كرزاز",
        "nameAscii": "Kerzaz"
      },
      {
        "name": "القصابي",
        "nameAscii": "Ksabi"
      },
      {
        "name": "أولاد خضير",
        "nameAscii": "Ouled-Khodeir"
      },
      {
        "name": "تامترت",
        "nameAscii": "Tamtert"
      },
      {
        "name": "تيمودي",
        "nameAscii": "Timoudi"
      }
    ]
  },
  {
    "code": "53",
    "name": "عين صالح",
    "nameAscii": "In Salah",
    "communes": [
      {
        "name": "عين صالح",
        "nameAscii": "Ain Salah"
      },
      {
        "name": "فقارة الزوى",
        "nameAscii": "Foggaret Ezzoua"
      },
      {
        "name": "إينغر",
        "nameAscii": "Inghar"
      }
    ]
  },
  {
    "code": "54",
    "name": "عين قزام",
    "nameAscii": "In Guezzam",
    "communes": [
      {
        "name": "عين قزام",
        "nameAscii": "Ain Guezzam"
      },
      {
        "name": "تين زواتين",
        "nameAscii": "Tin Zouatine"
      }
    ]
  },
  {
    "code": "55",
    "name": "تقرت",
    "nameAscii": "Touggourt",
    "communes": [
      {
        "name": "بن ناصر",
        "nameAscii": "Benaceur"
      },
      {
        "name": "بلدة اعمر",
        "nameAscii": "Blidet Amor"
      },
      {
        "name": "العالية",
        "nameAscii": "El Alia"
      },
      {
        "name": "الحجيرة",
        "nameAscii": "El-Hadjira"
      },
      {
        "name": "المنقر",
        "nameAscii": "M'naguer"
      },
      {
        "name": "المقارين",
        "nameAscii": "Megarine"
      },
      {
        "name": "النزلة",
        "nameAscii": "Nezla"
      },
      {
        "name": "سيدي سليمان",
        "nameAscii": "Sidi Slimane"
      },
      {
        "name": "الطيبات",
        "nameAscii": "Taibet"
      },
      {
        "name": "تبسبست",
        "nameAscii": "Tebesbest"
      },
      {
        "name": "تماسين",
        "nameAscii": "Temacine"
      },
      {
        "name": "تقرت",
        "nameAscii": "Touggourt"
      },
      {
        "name": "الزاوية العابدية",
        "nameAscii": "Zaouia El Abidia"
      }
    ]
  },
  {
    "code": "56",
    "name": "جانت",
    "nameAscii": "Djanet",
    "communes": [
      {
        "name": "برج الحواس",
        "nameAscii": "Bordj El Haouass"
      },
      {
        "name": "جانت",
        "nameAscii": "Djanet"
      }
    ]
  },
  {
    "code": "57",
    "name": "المغير",
    "nameAscii": "El Meghaier",
    "communes": [
      {
        "name": "جامعة",
        "nameAscii": "Djamaa"
      },
      {
        "name": "المغير",
        "nameAscii": "El-M'ghaier"
      },
      {
        "name": "المرارة",
        "nameAscii": "M'rara"
      },
      {
        "name": "أم الطيور",
        "nameAscii": "Oum Touyour"
      },
      {
        "name": "سيدي عمران",
        "nameAscii": "Sidi Amrane"
      },
      {
        "name": "سيدي خليل",
        "nameAscii": "Sidi Khelil"
      },
      {
        "name": "سطيل",
        "nameAscii": "Still"
      },
      {
        "name": "تندلة",
        "nameAscii": "Tenedla"
      }
    ]
  },
  {
    "code": "58",
    "name": "المنيعة",
    "nameAscii": "El Menia",
    "communes": [
      {
        "name": "المنيعة",
        "nameAscii": "El Meniaa"
      },
      {
        "name": "حاسي الفحل",
        "nameAscii": "Hassi Fehal"
      },
      {
        "name": "حاسي القارة",
        "nameAscii": "Hassi Gara"
      }
    ]
  }
];
