declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    ttq?: {
      track: (event: string, data?: Record<string, any>) => void;
    };
  }
}

export function trackPurchase(value: number, productName: string) {
  if (typeof window === "undefined") return;
  if (typeof window.fbq !== "function") return;

  window.fbq("track", "Purchase", {
    value,
    currency: "DZD",
    content_name: productName,
    content_type: "product",
  });
}

export function trackInitiateCheckout(productId: string, price: number) {
  if (typeof window === "undefined") return;
  
  if (typeof window.fbq === "function") {
    window.fbq("track", "InitiateCheckout", {
      value: price,
      currency: "DZD",
      content_ids: [productId],
      content_type: "product",
    });
  }
  
  if (window.ttq && typeof window.ttq.track === "function") {
    window.ttq.track("InitiateCheckout", {
      value: price,
      currency: "DZD",
      content_id: productId,
    });
  }
}

export function trackPurchaseComplete(productId: string, price: number, productName: string) {
  if (typeof window === "undefined") return;
  
  if (typeof window.fbq === "function") {
    window.fbq('track', 'Purchase', {
      value: price,
      currency: 'DZD',
      content_ids: [productId],
      content_name: productName,
      content_type: 'product',
    });
  }
  
  if (window.ttq && typeof window.ttq.track === "function") {
    window.ttq.track('CompletePayment', {
      value: price,
      currency: 'DZD',
      content_id: productId,
    });
  }
}