import { SITE } from "./site";

export function getWhatsAppUrl(message?: string) {
  const digits = SITE.whatsappNumber.replace(/\D/g, "");
  if (!digits) return "";
  const text = message ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${digits}${text}`;
}
