import { STRAPI_URL, unwrapStrapi } from "./strapi";

async function fetchProduct(query: string) {
  const res = await fetch(
    `${STRAPI_URL}/api/products?${query}&populate=*`,
    {
      cache: "no-store",
    },
  );
  if (!res.ok) return null;
  const data = await res.json();
  return data.data?.[0] || null;
}

export async function getProductById(id: string) {
  if (!id || id === "null" || id === "undefined") return null;

  const encoded = encodeURIComponent(id);

  try {
    const entry =
      (await fetchProduct(`filters[slug][$eq]=${encoded}`)) ||
      (await fetchProduct(`filters[documentId][$eq]=${encoded}`)) ||
      (await fetchProduct(`filters[id][$eq]=${encoded}`));
    return entry ? unwrapStrapi(entry) : null;
  } catch (err) {
    console.error("Error fetching product from Strapi:", err);
    return null;
  }
}

export async function getRelatedProducts(
  product: { documentId?: string; id?: string | number; category?: any },
  limit = 4,
) {
  const queryParams = new URLSearchParams();
  queryParams.append("populate", "*");
  queryParams.append("pagination[page]", "1");
  queryParams.append("pagination[pageSize]", String(limit + 4));
  queryParams.append("sort[0]", "createdAt:desc");

  const category = unwrapStrapi(product.category);
  const categoryId = category?.id || category?.documentId;
  if (categoryId) {
    queryParams.append("filters[category][id][$eq]", String(categoryId));
  }

  try {
    const res = await fetch(
      `${STRAPI_URL}/api/products?${queryParams.toString()}`,
      { cache: "no-store" },
    );
    if (!res.ok) return [];
    const data = await res.json();
    const currentId = String(product.documentId || product.id);
    return (data.data || [])
      .map((entry: any) => unwrapStrapi(entry))
      .filter(
        (item: any) => String(item.documentId || item.id) !== currentId,
      )
      .slice(0, limit);
  } catch (err) {
    console.error("Error fetching related products:", err);
    return [];
  }
}
