export type Choice = {
  description: string;
  value?: string;
};

export type ProductOption = {
  name: string;
  choices?: Choice[];
};

function asText(value: unknown): string {
  if (value == null) return "";
  return String(value).trim();
}

export function toChoiceList(raw: unknown): Choice[] {
  if (raw == null || raw === "") return [];

  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (!trimmed) return [];
    try {
      return toChoiceList(JSON.parse(trimmed));
    } catch {
      return trimmed
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean)
        .map((part) => ({ description: part, value: part }));
    }
  }

  if (Array.isArray(raw)) {
    return raw.flatMap((item) => {
      if (item == null || item === "") return [];
      if (typeof item === "string" || typeof item === "number") {
        const description = asText(item);
        return description ? [{ description, value: description }] : [];
      }
      if (typeof item === "object") {
        const record = item as Record<string, unknown>;
        const description = asText(
          record.description ??
            record.name ??
            record.label ??
            record.title ??
            record.color ??
            record.size ??
            record.value,
        );
        if (!description) return [];
        const value = asText(record.value ?? record.hex ?? record.code) || description;
        return [{ description, value }];
      }
      return [];
    });
  }

  if (typeof raw === "object") {
    const record = raw as Record<string, unknown>;
    if (Array.isArray(record.data)) return toChoiceList(record.data);
    if (Array.isArray(record.choices)) return toChoiceList(record.choices);
  }

  return [];
}

export function isColorOption(name: string) {
  return /color|couleur|colour|لون/i.test(name);
}

export function isSizeOption(name: string) {
  return /size|taille|pointure|مقاس|حجم/i.test(name);
}

export function looksLikeCssColor(value?: string) {
  if (!value) return false;
  return (
    value.startsWith("#") ||
    value.startsWith("rgb") ||
    value.startsWith("hsl")
  );
}

export function resolveProductOptions({
  productOptions = [],
  colors,
  sizes,
}: {
  productOptions?: ProductOption[];
  colors?: unknown;
  sizes?: unknown;
}): ProductOption[] {
  const fromCms = (productOptions || [])
    .map((option) => ({
      ...option,
      choices: toChoiceList(option.choices),
    }))
    .filter((option) => option.choices.length > 0);

  if (fromCms.length > 0) return fromCms;

  const colorChoices = toChoiceList(colors);
  const sizeChoices = toChoiceList(sizes);

  return [
    ...(colorChoices.length ? [{ name: "Color", choices: colorChoices }] : []),
    ...(sizeChoices.length ? [{ name: "Size", choices: sizeChoices }] : []),
  ];
}
