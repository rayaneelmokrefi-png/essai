import { getStrapiMediaUrl } from "./strapi";

function asUrlList(raw: unknown): string[] {
  if (!raw) return [];

  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (!trimmed) return [];
    if (trimmed.startsWith("http") || trimmed.startsWith("/")) {
      return [trimmed];
    }
    try {
      return asUrlList(JSON.parse(trimmed));
    } catch {
      return trimmed
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean);
    }
  }

  if (Array.isArray(raw)) {
    return raw.flatMap((item) => {
      if (typeof item === "string") return asUrlList(item);
      if (item && typeof item === "object") {
        const record = item as Record<string, unknown>;
        if (typeof record.url === "string") {
          const url = getStrapiMediaUrl(record, "");
          return url ? [url] : [];
        }
        if (record.attributes) return asUrlList(record.attributes);
      }
      return [];
    });
  }

  if (typeof raw === "object") {
    const record = raw as Record<string, unknown>;
    if (Array.isArray(record.data)) return asUrlList(record.data);
    if (typeof record.url === "string") {
      const url = getStrapiMediaUrl(record, "");
      return url ? [url] : [];
    }
  }

  return [];
}

export function getLandingPageImages(product: {
  landingPageImages?: unknown;
  landing_page_images?: unknown;
}): string[] {
  const urls = asUrlList(
    product.landingPageImages ?? product.landing_page_images,
  );
  return Array.from(new Set(urls.filter(Boolean)));
}
