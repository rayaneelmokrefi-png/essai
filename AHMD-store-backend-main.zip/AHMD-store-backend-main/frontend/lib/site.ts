export const SITE = {
  name: "auraShop",
  email: "contact@aurashop.dz",
  facebookUrl: "https://www.facebook.com/",
  instagramUrl: "https://www.instagram.com/",
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "",
};

export const NAV_LINKS = [
  { href: "/", label: "الرئيسية" },
  { href: "/list", label: "المنتجات" },
  { href: "/contact", label: "اتصل بنا" },
] as const;
