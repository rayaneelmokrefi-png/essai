"use client";

import { Menu as MenuIcon, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import BrandLogo from "./BrandLogo";
import { FacebookIcon, InstagramIcon } from "./SocialIcons";
import { NAV_LINKS, SITE } from "@/lib/site";

const Menu = () => {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  // Lock body scroll when menu is open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [open]);

  return (
    <div className="md:hidden">
      <button
        type="button"
        aria-label="فتح القائمة"
        className="p-1 cursor-pointer text-ink"
        onClick={() => setOpen(true)}
      >
        <MenuIcon className="w-6 h-6 stroke-[1.4]" />
      </button>

      {open && (
        <>
          {/* Backdrop overlay */}
          <div
            className="fixed inset-0 z-50 bg-black/50"
            onClick={() => setOpen(false)}
          />
          {/* Drawer */}
          <div className="fixed inset-y-0 right-0 z-[9999] h-screen w-full max-w-xs bg-white shadow-xl flex flex-col overflow-y-auto overflow-x-hidden">
            <div className="flex items-center justify-between px-6 py-5 border-b border-cream-2">
              <BrandLogo size="sm" />
              <button
                type="button"
                aria-label="إغلاق القائمة"
                onClick={() => setOpen(false)}
              >
                <X className="w-6 h-6 stroke-[1.4]" />
              </button>
            </div>

            <nav className="flex flex-col py-6 text-right">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className={`px-6 py-4 text-lg font-display ${
                    pathname === link.href
                      ? "text-brand"
                      : "text-ink hover:text-brand"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            <div className="mt-auto border-t border-cream-2 px-6 py-8 flex flex-col items-center gap-4 text-muted">
              <p className="text-xs">تابعونا</p>
              <div className="flex items-center gap-5">
                <a href={SITE.facebookUrl} target="_blank" rel="noreferrer" aria-label="Facebook">
                  <FacebookIcon className="w-4 h-4" />
                </a>
                <a href={SITE.instagramUrl} target="_blank" rel="noreferrer" aria-label="Instagram">
                  <InstagramIcon className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Menu;
