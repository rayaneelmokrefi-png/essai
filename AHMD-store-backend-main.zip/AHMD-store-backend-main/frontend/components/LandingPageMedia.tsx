type LandingPageMediaProps = {
  images: string[];
  productName: string;
};

export default function LandingPageMedia({
  images,
  productName,
}: LandingPageMediaProps) {
  if (!images.length) return null;

  return (
    <section
      className="mt-8 md:mt-12 w-full bg-white"
      aria-label="عرض المنتج"
    >
      <div className="flex flex-col">
        {images.map((src, index) => (
          // Dynamic CMS URLs can come from any host.
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={`${src}-${index}`}
            src={src}
            alt={`${productName} — صورة ${index + 1}`}
            className="w-full h-auto block"
            loading={index === 0 ? "eager" : "lazy"}
          />
        ))}
      </div>
    </section>
  );
}
