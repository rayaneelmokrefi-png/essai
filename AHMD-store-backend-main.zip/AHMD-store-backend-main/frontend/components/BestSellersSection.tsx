import Link from "next/link";
import ProductGrid from "./ProductGrid";
import { Suspense } from "react";
import Skeleton from "./Skeleton";
import { Star } from "lucide-react";

const BestSellersSection = () => {
  return (
    <section className="w-full py-12 md:py-16 bg-[#FDFBF7]">
      <div className="page-wrap">
        <div className="flex items-center justify-between mb-8 px-4 md:px-0">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2 flex items-center gap-2">
              الأكثر مبيعاً
              <div className="flex items-center gap-1">
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
              </div>
            </h2>
            <p className="text-gray-500 text-sm md:text-base">
              المنتجات الأكثر طلباً ورضاً لدى عملائنا
            </p>
          </div>
          <Link
            href="/list?sort=desc popularity"
            className="text-emerald-700 hover:text-emerald-800 font-medium text-sm md:text-base flex items-center gap-1 transition-colors"
          >
            عرض الكل
            <svg
              className="w-4 h-4 rotate-180"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </Link>
        </div>
        
        <Suspense fallback={<Skeleton />}>
          <ProductGrid limit={8} sortBy="popularity" />
        </Suspense>
      </div>
    </section>
  );
};

export default BestSellersSection;
