import ProductCard from "./ProductCard";
import { STRAPI_URL, unwrapStrapi } from "@/lib/strapi";

const ProductGrid = async ({
  limit = 8,
  sortBy = "createdAt",
}: {
  limit?: number;
  sortBy?: string;
}) => {
  let products: any[] = [];

  const queryParams = new URLSearchParams();
  queryParams.append("populate", "*");
  queryParams.append("pagination[pageSize]", limit.toString());
  queryParams.append("sort[0]", `${sortBy}:desc`);

  try {
    const res = await fetch(
      `${STRAPI_URL}/api/products?${queryParams.toString()}`,
      { next: { revalidate: 60 } },
    );
    const data = await res.json();
    products = data.data || [];
  } catch (err) {
    console.error("Error fetching products from Strapi:", err);
  }

  return (
    <div dir="rtl" className="flex gap-4 px-4 pb-4 overflow-x-auto snap-x snap-mandatory scrollbar-none md:px-0 md:grid md:grid-cols-4 md:gap-4 md:pb-0">
      {products.map((product: any) => {
        const item = unwrapStrapi(product);
        return (
          <div key={product.id || item.documentId || item.id} className="min-w-[240px] w-[260px] flex-shrink-0 snap-start md:w-auto md:min-w-0">
            <ProductCard product={item} />
          </div>
        );
      })}
    </div>
  );
};

export default ProductGrid;
