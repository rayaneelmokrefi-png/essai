import Image from "next/image";
import Link from "next/link";
import { getImageUrl, STRAPI_URL, unwrapStrapi } from "@/lib/strapi";

type Category = {
  id: string;
  documentId?: string;
  name?: string;
  title?: string;
  slug?: string;
  image?: any;
  media?: any;
};

const CategoryList = async () => {
  let categories: Category[] = [];

  try {
    const res = await fetch(`${STRAPI_URL}/api/categories?populate=*`, {
      next: { revalidate: 60 },
    });
    const data = await res.json();
    categories = data.data || [];
  } catch (err) {
    console.error("Error fetching categories from Strapi:", err);
  }

  return (
    <section className="w-full bg-white py-16 md:py-20">
      <div className="page-wrap">
        <div className="flex items-center justify-between mb-8 px-4 md:px-0">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
              التصنيفات
            </h2>
            <p className="text-gray-500 text-sm md:text-base">
              تسوق حسب الفئة
            </p>
          </div>
          <Link
            href="/categories"
            className="text-emerald-700 hover:text-emerald-800 font-medium text-sm md:text-base flex items-center gap-1 transition-colors"
          >
            عرض الكل
            <svg
              className="w-4 h-4 rotate-180"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </Link>
        </div>
        <div dir="rtl" className={`flex gap-4 px-4 pb-4 overflow-x-auto snap-x snap-mandatory scrollbar-none md:px-0 md:grid md:gap-6 ${
          categories.length === 1 
            ? 'md:grid-cols-1 md:justify-center md:max-w-sm md:mx-auto' 
            : 'md:grid-cols-3 lg:grid-cols-4 md:justify-start'
        }`}>
          {categories.map((cat: Category) => {
        const item = unwrapStrapi(cat);
        // Handle new image field and legacy media fields
        const imgData =
          item.image?.data || item.image || 
          item.media?.data || item.media;
        const imageObj = Array.isArray(imgData) ? imgData[0] : imgData;
        const categoryImage = getImageUrl(imageObj, "/category.png");
        const name = item.name || item.title;

        return (
          <Link
            href={`/list?cat=${item.slug || cat.id}`}
            className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-cream-2 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 min-w-[220px] w-[240px] md:w-auto md:max-w-xs snap-start flex-shrink-0"
            key={cat.id || item.documentId}
          >
            <div className="relative w-full aspect-[4/3] overflow-hidden rounded-t-2xl bg-gradient-to-b from-cream to-cream/50">
              <Image
                src={categoryImage}
                alt={name || "تصنيف"}
                fill
                sizes="(max-width: 640px) 240px, (max-width: 1024px) 33vw, 25vw"
                className="object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-ink/20 to-transparent" />
            </div>
            <div className="flex flex-col px-4 sm:px-5 py-4">
              <h3 className="font-semibold text-gray-800 text-base line-clamp-1 text-center group-hover:text-gray-600 transition-colors duration-300">
                {name}
              </h3>
            </div>
          </Link>
        );
      })}
        </div>
      </div>
    </section>
  );
};

export default CategoryList;
