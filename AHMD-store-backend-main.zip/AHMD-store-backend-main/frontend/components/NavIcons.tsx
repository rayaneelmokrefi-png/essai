"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Cookies from "js-cookie";

const NavIcons = () => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const router = useRouter();

  const getAuthToken = () => {
    if (typeof window === "undefined") return null;
    return localStorage.getItem("strapi_token") || Cookies.get("jwt") || null;
  };

  useEffect(() => {
    setIsLoggedIn(!!getAuthToken());
  }, []);

  const handleProfile = () => {
    const token = getAuthToken();

    if (!token) {
      router.push("/login");
    } else {
      setIsProfileOpen((prev) => !prev);
    }
  };

  const handleLogout = () => {
    setIsLoading(true);
    if (typeof window !== "undefined") {
      localStorage.removeItem("strapi_token");
      localStorage.removeItem("strapi_user");
      Cookies.remove("jwt");
    }
    setIsLoading(false);
    setIsProfileOpen(false);
    setIsLoggedIn(false);
    router.push("/");
  };

  return (
    <div className="flex items-center gap-4 xl:gap-6 relative">
      {isLoggedIn ? (
        <Image
          src="/profile.png"
          alt="الحساب"
          width={22}
          height={22}
          className="cursor-pointer"
          onClick={handleProfile}
        />
      ) : (
        <Link
          href="/login"
          className="text-sm font-medium whitespace-nowrap hover:underline"
        >
          تسجيل الدخول
        </Link>
      )}
      {isProfileOpen && (
        <div className="absolute p-4 rounded-md top-12 end-0 bg-white text-sm shadow-[0_3px_10px_rgb(0,0,0,0.2)] z-20 flex flex-col gap-2">
          <Link href="/profile" onClick={() => setIsProfileOpen(false)}>
            الحساب
          </Link>
          <button
            disabled={isLoading}
            className="text-start cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
            onClick={handleLogout}
          >
            {isLoading ? "جاري الخروج..." : "تسجيل الخروج"}
          </button>
        </div>
      )}
    </div>
  );
};

export default NavIcons;
