"use client";

import { Check } from "lucide-react";

type Offer = {
  id: string | number;
  documentId?: string;
  title: string;
  price: number;
  badge?: string;
  isDefault?: boolean;
};

type ProductOffersProps = {
  offers: Offer[];
  selectedOfferId: string | number | null;
  onOfferSelect: (offer: Offer) => void;
  isMielPage?: boolean;
};

const ProductOffers = ({ offers, selectedOfferId, onOfferSelect, isMielPage = false }: ProductOffersProps) => {
  if (!offers || offers.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-lg font-semibold text-center text-ink">اختر العرض</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {offers.map((offer) => {
          const isSelected = selectedOfferId === offer.id || selectedOfferId === offer.documentId;

          return (
            <button
              key={offer.id || offer.documentId}
              type="button"
              onClick={() => onOfferSelect(offer)}
              className={`relative p-4 rounded-xl border-2 transition-all ${
                isSelected
                  ? isMielPage
                    ? "miel-offer-card-selected"
                    : "border-brand bg-brand/5"
                  : isMielPage
                    ? "miel-offer-card hover:border-brand-amber-dark"
                    : "border-cream-2 bg-white hover:border-brand/50"
              }`}
              style={isMielPage && isSelected ? { borderColor: '#fbad25', backgroundColor: 'rgba(251, 173, 37, 0.08)' } : {}}
            >
              {offer.badge && (
                <span className={`absolute top-2 left-2 text-white text-xs px-2 py-1 rounded-md font-semibold ${isMielPage ? 'bg-brand-amber' : 'bg-brand'}`} style={isMielPage ? { backgroundColor: '#fbad25' } : {}}>
                  {offer.badge}
                </span>
              )}
              {isSelected && (
                <div className={`absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center ${isMielPage ? 'bg-brand-amber-dark' : 'bg-brand'}`} style={isMielPage ? { backgroundColor: '#d4820a' } : {}}>
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
              <div className="flex flex-col items-center gap-2 pt-4">
                <h4 className="font-medium text-ink text-center">{offer.title}</h4>
                <p className={`text-xl font-bold ${isMielPage ? 'text-brand-amber-dark' : 'text-emerald-800'}`} style={isMielPage ? { color: '#d4820a' } : {}}>
                  {Number(offer.price).toLocaleString("ar-DZ")} دج
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ProductOffers;
