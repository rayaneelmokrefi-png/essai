"use client";

import Image from "next/image";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { getImageUrl } from "@/lib/strapi";

const ProductImages = ({ items = [] }: { items: any[] }) => {
  const [index, setIndex] = useState(0);

  if (!items || items.length === 0) {
    return (
      <div className="aspect-[4/5] sm:h-[500px] sm:aspect-auto relative w-full bg-cream rounded-2xl flex items-center justify-center text-muted">
        Image indisponible
      </div>
    );
  }

  const currentImageUrl = getImageUrl(items[index]);
  const go = (direction: -1 | 1) => {
    setIndex((prev) => (prev + direction + items.length) % items.length);
  };

  return (
    <div>
      <div className="aspect-[4/5] sm:h-[520px] sm:aspect-auto relative bg-cream rounded-2xl overflow-hidden">
        <Image
          src={currentImageUrl}
          alt="Product image"
          fill
          sizes="(max-width: 1024px) 100vw, 50vw"
          className="object-cover"
          priority
        />
        {items.length > 1 ? (
          <>
            <button
              type="button"
              aria-label="الصورة السابقة"
              onClick={() => go(-1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/90 text-ink flex items-center justify-center shadow"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              aria-label="الصورة التالية"
              onClick={() => go(1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/90 text-ink flex items-center justify-center shadow"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
              {items.map((item: any, i: number) => (
                <button
                  type="button"
                  key={item.id || item._id || i}
                  aria-label={`صورة ${i + 1}`}
                  onClick={() => setIndex(i)}
                  className={`h-1.5 rounded-full transition-all ${
                    i === index ? "w-6 bg-brand" : "w-1.5 bg-white/80"
                  }`}
                />
              ))}
            </div>
          </>
        ) : null}
      </div>

      {items.length > 1 ? (
        <div className="hidden sm:flex justify-start gap-3 mt-4 overflow-x-auto scrollbar-hide">
          {items.map((item: any, i: number) => {
            const imgUrl = getImageUrl(item);
            return (
              <button
                type="button"
                className={`relative h-20 w-20 shrink-0 rounded-xl overflow-hidden border-2 transition-all ${
                  i === index
                    ? "border-brand"
                    : "border-transparent opacity-70 hover:opacity-100"
                }`}
                key={item.id || item._id || i}
                onClick={() => setIndex(i)}
              >
                <Image
                  src={imgUrl}
                  alt={`Thumbnail ${i + 1}`}
                  fill
                  sizes="80px"
                  className="object-cover"
                />
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
};

export default ProductImages;
