"use client";
import Image from "next/image";
import Link from "next/link";
import DOMPurify from "isomorphic-dompurify";
import { getProductHref, getImageUrl } from "@/lib/strapi";
import { ShoppingBag } from "lucide-react";
import { useState } from "react";

function getProductImages(item: any) {
  const raw = item.images?.data || item.images || [];
  const images = Array.isArray(raw) ? raw : raw ? [raw] : [];
  const mainImage = getImageUrl(images[0], "/product.png");
  const hoverImage = images[1]
    ? getImageUrl(images[1], mainImage)
    : mainImage;
  return { mainImage, hoverImage };
}

function calculateDiscountPercentage(originalPrice: number, discountedPrice: number) {
  if (!originalPrice || !discountedPrice || originalPrice <= discountedPrice) return 0;
  return Math.round(((originalPrice - discountedPrice) / originalPrice) * 100);
}

export default function ProductCard({
  product,
  compact = false,
}: {
  product: any;
  compact?: boolean;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const { mainImage, hoverImage } = getProductImages(product);
  const title = product.title || product.name || "منتج";
  const price = product.price || 0;
  const discountedPrice = product.discountedPrice;
  const discountPercentage = calculateDiscountPercentage(price, discountedPrice);

  // Check if product has offers
  const offersData = product.offers?.data || product.attributes?.offers?.data || product.offers || product.attributes?.offers || [];
  const hasValidOffers = Array.isArray(offersData) && offersData.length > 0;

  // Only show price if product has a valid non-zero price AND no offers
  const shouldShowPrice = price > 0 && !hasValidOffers;

  // Only show discount badge if there's a valid discount percentage AND no offers
  const shouldShowDiscountBadge = discountPercentage > 0 && !hasValidOffers;

  const imageSizes = compact
    ? "(max-width: 768px) 50vw, 25vw"
    : "(max-width: 768px) 260px, 25vw";

  return (
    <Link
      href={getProductHref(product)}
      className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
    >
      <div className="relative w-full h-52 overflow-hidden rounded-t-2xl bg-gradient-to-b from-cream to-cream/50">
        <Image
          src={mainImage}
          alt={title}
          fill
          sizes={imageSizes}
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {shouldShowDiscountBadge && (
          <div className="absolute top-3 right-3 bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-sm z-20">
            -{discountPercentage}%
          </div>
        )}
      </div>
      <div className="flex flex-col px-4 sm:px-5 py-4 gap-3">
        <h3 className="font-semibold text-gray-800 text-base line-clamp-1 text-right">
          {title}
        </h3>
        {shouldShowPrice && (
          <>
            {discountedPrice && discountedPrice !== price ? (
              <div className="flex items-center gap-2.5">
                <span className="text-emerald-700 font-bold text-lg">
                  {Number(discountedPrice).toLocaleString("ar-DZ")} دج
                </span>
                <span className="text-gray-400 line-through text-sm">
                  {Number(price).toLocaleString("ar-DZ")}
                </span>
              </div>
            ) : (
              <span className="text-emerald-700 font-bold text-lg">
                {Number(price).toLocaleString("ar-DZ")} دج
              </span>
            )}
          </>
        )}
        <button
          className="w-full py-2.5 rounded-xl text-white font-medium transition-all duration-300 ease-in-out shadow-sm flex items-center justify-center gap-2"
          style={{ backgroundColor: isHovered ? '#C4A870' : '#D4BC8A' }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <ShoppingBag className="w-4 h-4" />
          إشتري الآن
        </button>
      </div>
    </Link>
  );
}
