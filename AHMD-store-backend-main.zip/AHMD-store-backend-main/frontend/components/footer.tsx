"use client";

"use client";

import BrandLogo from "./BrandLogo";
import { FacebookIcon, InstagramIcon } from "./SocialIcons";
import Link from "next/link";
import { NAV_LINKS, SITE } from "@/lib/site";

const FooterLink = ({ href, children }: { href: string; children: React.ReactNode }) => {
  return (
    <Link 
      href={href} 
      className="transition-colors" 
      style={{ color: '#fafaf9' }}
      onMouseEnter={(e) => e.currentTarget.style.color = '#fbad25'}
      onMouseLeave={(e) => e.currentTarget.style.color = '#fafaf9'}
    >
      {children}
    </Link>
  );
};

const Footer = () => {
  return (
    <footer className="mt-24" style={{ backgroundColor: '#1c1917', color: '#fafaf9' }}>
      <div className="page-wrap py-16 md:py-20 flex flex-col items-center text-center">
        <div className="flex flex-col gap-5 max-w-sm mx-auto text-center">
          <BrandLogo size="lg" light />
          <p className="text-sm font-medium tracking-wide" style={{ color: '#fafaf9', opacity: 0.8 }}>
            منتجات عالية الجودة
          </p>
        </div>

        <div className="text-center mt-8">
          <h2 className="text-xs mb-5 font-medium tracking-wider uppercase" style={{ color: '#fafaf9', opacity: 0.5 }}>المتجر</h2>
          <div className="flex flex-col gap-3 text-sm" style={{ color: '#fafaf9', opacity: 0.85 }}>
            <FooterLink href="/contact">
              تواصل معنا
            </FooterLink>
            <FooterLink href="/">
              حول المتجر
            </FooterLink>
            <FooterLink href="/contact">
              الأسئلة الشائعة
            </FooterLink>
          </div>
        </div>


      </div>
      <div className="border-t page-wrap py-5 text-xs text-center" style={{ borderColor: 'rgba(250, 250, 249, 0.1)', color: '#fafaf9', opacity: 0.5 }}>
        جميع الحقوق محفوظة © {new Date().getFullYear()} {SITE.name}
      </div>
    </footer>
  );
};

export default Footer;
