"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ALGERIA_WILAYAS } from "@/lib/algeriaLocations";
import { CHECKOUT_FORM_ID } from "@/lib/constants";
import { trackPurchase, trackInitiateCheckout } from "@/lib/pixel";
import {
  isColorOption,
  isSizeOption,
  looksLikeCssColor,
  resolveProductOptions,
  type ProductOption,
} from "@/lib/productOptions";
import { User, Phone, Map } from "lucide-react";
import ProductOffers from "./ProductOffers";
import { getDeliveryPrice } from "@/lib/deliveryPrices";

type Variant = {
  id: string | number;
  choices: { [key: string]: string };
  stock?: {
    inStock: boolean;
    quantity?: number;
  };
};

type OrderItem = {
  id: string;
  color: string;
  size: string;
  quantity: number;
};

type DeliveryForm = {
  name: string;
  phone: string;
  wilaya: string;
  baladia: string;
};

type OptionsError = {
  color?: string;
  size?: string;
};

type Offer = {
  id: string | number;
  documentId?: string;
  title: string;
  name?: string;
  price: number;
  badge?: string;
  isDefault?: boolean;
  attributes?: {
    title?: string;
    name?: string;
  };
};

const EMPTY_FORM: DeliveryForm = {
  name: "",
  phone: "",
  wilaya: "",
  baladia: "",
};

function optionValue(
  selectedOptions: { [key: string]: string },
  keys: string[],
) {
  const match = Object.entries(selectedOptions).find(([key]) =>
    keys.some((k) => key.toLowerCase() === k.toLowerCase()),
  );
  return match?.[1] || "";
}

const ProductOrderForm = ({
  productName,
  productId,
  price,
  stockNumber = 10,
  variants = [],
  productOptions = [],
  colors = [],
  sizes = [],
  offers = [],
  basePrice,
  isMielPage = false,
  hasValidOffers = false,
}: {
  productName: string;
  productId: string;
  price: number;
  stockNumber?: number;
  variants?: Variant[];
  productOptions?: ProductOption[];
  colors?: unknown;
  sizes?: unknown;
  offers?: Offer[];
  basePrice?: number;
  isMielPage?: boolean;
  hasValidOffers?: boolean;
}) => {
  const resolvedOptions = resolveProductOptions({
    productOptions,
    colors,
    sizes,
  });

  const hasColors = colors && Array.isArray(colors) && colors.length > 0;
  const hasSizes = sizes && Array.isArray(sizes) && sizes.length > 0;
  const hasVariants = hasColors || hasSizes;
  const hasOffers = offers && offers.length > 0;
  
  const defaultOffer = offers.find((offer) => offer.isDefault) || offers[0] || null;
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(defaultOffer);
  
  const [items, setItems] = useState<OrderItem[]>([
    { id: '1', color: '', size: '', quantity: 1 }
  ]);
  const [quantity, setQuantity] = useState(1);
  const [form, setForm] = useState<DeliveryForm>(EMPTY_FORM);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [errors, setErrors] = useState<Partial<Record<keyof DeliveryForm, string>>>({});
  const [itemsErrors, setItemsErrors] = useState<Record<string, OptionsError>>({});
  const [isCooldownActive, setIsCooldownActive] = useState(false);
  const [cooldownEndTime, setCooldownEndTime] = useState<number | null>(null);
  const [hasTrackedInitiateCheckout, setHasTrackedInitiateCheckout] = useState(false);
  const router = useRouter();

  const nameRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);
  const wilayaRef = useRef<HTMLSelectElement>(null);
  const baladiaRef = useRef<HTMLSelectElement>(null);

  useEffect(() => {
    const checkCooldown = () => {
      const orderKey = `order_cooldown_${productId}`;
      const storedOrder = localStorage.getItem(orderKey);
      if (storedOrder) {
        const orderTime = parseInt(storedOrder, 10);
        const now = Date.now();
        const cooldownPeriod = 48 * 60 * 60 * 1000; // 48 hours in milliseconds

        if (now - orderTime < cooldownPeriod) {
          setIsCooldownActive(true);
          setCooldownEndTime(orderTime + cooldownPeriod);
        } else {
          localStorage.removeItem(orderKey);
          setIsCooldownActive(false);
          setCooldownEndTime(null);
        }
      }
    };

    checkCooldown();
    const interval = setInterval(checkCooldown, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [productId]);

  const totalQuantity = hasVariants 
    ? items.reduce((sum, item) => sum + item.quantity, 0)
    : quantity;
  const currentPrice = selectedOffer?.price || price;
  const subtotal = currentPrice * totalQuantity;

  const selectedWilaya = useMemo(
    () => ALGERIA_WILAYAS.find((w) => w.nameAscii === form.wilaya),
    [form.wilaya],
  );
  const communes = selectedWilaya?.communes ?? [];

  const deliveryPrice = useMemo(() => {
    if (!selectedWilaya) return null;
    return getDeliveryPrice(selectedWilaya.code);
  }, [selectedWilaya]);

  const deliveryCost = deliveryPrice?.home || 0;
  const totalAmount = selectedWilaya ? subtotal + deliveryCost : subtotal;

  const handleAddItem = () => {
    const newId = (items.length + 1).toString();
    setItems([...items, { id: newId, color: '', size: '', quantity: 1 }]);
    setItemsErrors(prev => ({ ...prev, [newId]: {} }));
  };

  const handleRemoveItem = (itemId: string) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== itemId));
      setItemsErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[itemId];
        return newErrors;
      });
    }
  };

  const handleItemChange = (itemId: string, field: keyof OrderItem, value: string | number) => {
    setItems(items.map(item => 
      item.id === itemId ? { ...item, [field]: value } : item
    ));
    setItemsErrors(prev => ({
      ...prev,
      [itemId]: { ...prev[itemId], [field]: undefined }
    }));
  };

  const handleItemQuantity = (itemId: string, type: "i" | "d") => {
    setItems(items.map(item => {
      if (item.id === itemId) {
        const maxQuantity = Math.min(stockNumber, 2);
        if (type === "d" && item.quantity > 1) {
          return { ...item, quantity: item.quantity - 1 };
        }
        if (type === "i" && item.quantity < maxQuantity) {
          return { ...item, quantity: item.quantity + 1 };
        }
      }
      return item;
    }));
  };

  const handleQuantity = (type: "i" | "d") => {
    const maxQuantity = Math.min(stockNumber, 2);
    if (type === "d" && quantity > 1) setQuantity((prev) => prev - 1);
    if (type === "i" && quantity < maxQuantity) {
      setQuantity((prev) => prev + 1);
    }
  };

  const handleOfferSelect = (offer: Offer) => {
    setSelectedOffer(offer);
  };



  const handleChange = (field: keyof DeliveryForm, value: string) => {
    setSuccessMessage("");
    setErrorMessage("");
    setErrors((prev) => ({ ...prev, [field]: "" }));
    
    if (!hasTrackedInitiateCheckout && value.trim()) {
      trackInitiateCheckout(productId, price);
      setHasTrackedInitiateCheckout(true);
    }
    
    setForm((prev) => {
      if (field === "wilaya") return { ...prev, wilaya: value, baladia: "" };
      if (field === "phone") {
        const trimmedPhone = value.trim();
        // Validate phone immediately to hide error if valid
        if (trimmedPhone.length === 10 && /^(05|06|07)/.test(trimmedPhone)) {
          setErrors((prev) => ({ ...prev, phone: "" }));
        }
        return { ...prev, [field]: trimmedPhone };
      }
      return { ...prev, [field]: value };
    });
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSuccessMessage("");
    setErrorMessage("");
    setErrors({});
    setItemsErrors({});

    const newErrors: Partial<Record<keyof DeliveryForm, string>> = {};
    const newItemsErrors: Record<string, OptionsError> = {};

    if (!form.name.trim()) {
      newErrors.name = "الاسم الكامل مطلوب";
    }
    const trimmedPhone = form.phone.trim();
    if (!trimmedPhone) {
      newErrors.phone = "رقم الهاتف مطلوب";
    } else if (trimmedPhone.length !== 10) {
      newErrors.phone = "رقم الهاتف يجب أن يكون 10 أرقام";
    } else if (!/^(05|06|07)/.test(trimmedPhone)) {
      newErrors.phone = "رقم الهاتف يجب أن يبدأ بـ 05 أو 06 أو 07";
    }
    if (!form.wilaya) {
      newErrors.wilaya = "الولاية مطلوبة";
    }
    if (!form.baladia) {
      newErrors.baladia = "البلدية مطلوبة";
    }

    // Validate each item only if variants exist
    if (hasVariants) {
      items.forEach((item) => {
        const itemErrors: OptionsError = {};
        
        if (hasColors && !item.color) {
          itemErrors.color = "يرجى اختيار اللون";
        }
        
        if (hasSizes && !item.size) {
          itemErrors.size = "يرجى اختيار المقاس";
        }
        
        if (Object.keys(itemErrors).length > 0) {
          newItemsErrors[item.id] = itemErrors;
        }
      });
    }

    if (Object.keys(newErrors).length > 0 || Object.keys(newItemsErrors).length > 0) {
      setErrors(newErrors);
      setItemsErrors(newItemsErrors);
      setErrorMessage("يرجى ملء جميع الحقول المطلوبة قبل إرسال الطلب");
      
      // Focus on first invalid field
      const firstErrorField = Object.keys(newErrors)[0] as keyof DeliveryForm;
      const refMap = {
        name: nameRef,
        phone: phoneRef,
        wilaya: wilayaRef,
        baladia: baladiaRef,
      };
      refMap[firstErrorField]?.current?.focus();
      refMap[firstErrorField]?.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    if (isCooldownActive) {
      router.push('/order-cooldown');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          phone: form.phone.trim(),
          wilaya: form.wilaya,
          baladia: form.baladia,
          orderItems: hasVariants
            ? items.map(item => ({
                productName,
                color: item.color,
                size: item.size,
                quantity: item.quantity,
                price: currentPrice,
              }))
            : [{
                productName,
                color: '',
                size: '',
                quantity: quantity,
                price: currentPrice,
              }],
          subtotal: subtotal,
          deliveryPrice: deliveryCost,
          totalAmount: totalAmount,
          selectedOffer: selectedOffer ? {
            id: selectedOffer.id || selectedOffer.documentId,
            title: selectedOffer.title,
            price: selectedOffer.price,
          } : null,
          offerTitle: selectedOffer?.attributes?.title || selectedOffer?.attributes?.name || selectedOffer?.title || selectedOffer?.name || '',
        }),
      });

      const data = await response.json().catch(() => ({}));
      
      // التعامل مع استجابة 403 (BLOCKED - BlackList)
      if (response.status === 403 && data.status === 'BLOCKED') {
        router.push('/blocked');
        return;
      }
      
      // التعامل مع استجابة 429 (ORDER_COOLDOWN)
      if (response.status === 429 && data.code === 'ORDER_COOLDOWN') {
        router.push('/order-cooldown');
        return;
      }
      
      if (!response.ok) {
        throw new Error(data.error || "Order failed");
      }

      trackPurchase(subtotal, productName);
      
      // Save order to localStorage for 48-hour cooldown
      const orderKey = `order_cooldown_${productId}`;
      localStorage.setItem(orderKey, Date.now().toString());
      
      // Store order data for pixel tracking on success page
      sessionStorage.setItem('pixel_tracking_data', JSON.stringify({
        productId,
        price: subtotal,
        productName
      }));
      
      setForm(EMPTY_FORM);
      if (hasVariants) {
        setItems([{ id: '1', color: '', size: '', quantity: 1 }]);
      } else {
        setQuantity(1);
      }
      
      // Redirect to success page
      const orderId = data.orderId || data.id;
      router.push(orderId ? `/success?orderId=${orderId}` : "/success");
    } catch (err) {
      console.error("Failed to submit order:", err);
      setErrorMessage("تعذر إرسال الطلب. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const optionLabel = (option: ProductOption) => {
    if (isColorOption(option.name)) return "اللون";
    if (isSizeOption(option.name)) return "المقاس";
    return option.name;
  };

  const renderOrderItem = (item: OrderItem, index: number) => {
    const itemErrors = itemsErrors[item.id] || {};
    
    return (
      <div key={item.id} className={`${isMielPage ? 'miel-surface-card' : 'surface-card'} p-4 sm:p-5 flex flex-col gap-4 relative`} style={isMielPage ? { backgroundColor: '#fff', border: '1px solid #e7e5e4', borderRadius: '1rem' } : {}}>
        {items.length > 1 && (
          <button
            type="button"
            onClick={() => handleRemoveItem(item.id)}
            className="absolute top-2 left-2 text-red-500 hover:text-red-700 text-sm"
          >
            حذف
          </button>
        )}

        <div className="flex items-center justify-between">
          <h4 className={`font-medium ${isMielPage ? 'miel-text-primary' : 'text-ink'}`} style={isMielPage ? { color: '#1c1917' } : {}}>القطعة {index + 1}</h4>
        </div>

        {resolvedOptions.map((option) => {
          if (isColorOption(option.name) && !hasColors) return null;
          if (isSizeOption(option.name) && !hasSizes) return null;

          return (
            <div className="flex flex-col gap-3" key={`${item.id}-${option.name}`}>
              <h4 className={`text-xs tracking-[0.16em] uppercase ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>
                {optionLabel(option)}
              </h4>
              <ul className="flex items-center gap-3 flex-wrap">
                {option.choices?.map((choice) => {
                  const isSelected = 
                    (isColorOption(option.name) && item.color === choice.description) ||
                    (isSizeOption(option.name) && item.size === choice.description);
                  
                  const clickHandler = () => {
                    if (isColorOption(option.name)) {
                      handleItemChange(item.id, 'color', choice.description);
                    } else if (isSizeOption(option.name)) {
                      handleItemChange(item.id, 'size', choice.description);
                    }
                  };
                  
                  const swatch = looksLikeCssColor(choice.value);

                  return isColorOption(option.name) && swatch ? (
                    <li
                      className={`w-8 h-8 rounded-full ring-1 relative ${isMielPage ? 'ring-stone-300' : 'ring-cream-2'}`}
                      style={{
                        backgroundColor: choice.value,
                        cursor: "pointer",
                      }}
                      onClick={clickHandler}
                      key={choice.description}
                    >
                      {isSelected && (
                        <div className={`absolute w-10 h-10 rounded-full ring-2 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 ${isMielPage ? 'ring-brand-amber-dark' : 'ring-brand'}`} />
                      )}
                    </li>
                  ) : (
                    <li
                      className={`rounded-lg py-1.5 px-4 text-sm border cursor-pointer ${
                        isSelected
                          ? isMielPage
                            ? "bg-brand-amber-dark text-white border-brand-amber-dark"
                            : "bg-brand text-white border-brand"
                          : "bg-white text-ink border-cream-2"
                      }`}
                      key={choice.description}
                      onClick={clickHandler}
                    >
                      {choice.description}
                    </li>
                  );
                })}
              </ul>
              {isColorOption(option.name) && itemErrors.color && (
                <p className="text-xs text-red-500 mt-1">{itemErrors.color}</p>
              )}
              {isSizeOption(option.name) && itemErrors.size && (
                <p className="text-xs text-red-500 mt-1">{itemErrors.size}</p>
              )}
            </div>
          );
        })}

        <div className={`${isMielPage ? 'bg-stone-100/50' : 'bg-cream/70'} rounded-2xl p-4 sm:p-5`} style={isMielPage ? { backgroundColor: 'rgba(245, 245, 244, 0.5)' } : {}}>
          <div className="flex items-center justify-between gap-4">
            <p className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>الكمية</p>
            <div className={`flex items-center justify-between w-32 rounded-full border bg-white py-1.5 px-3 ${isMielPage ? 'border-stone-300' : 'border-cream-2'}`} style={isMielPage ? { borderColor: '#d6d3d1' } : {}}>
              <button
                type="button"
                className="cursor-pointer text-lg disabled:opacity-20"
                onClick={() => handleItemQuantity(item.id, "d")}
                disabled={item.quantity === 1}
              >
                -
              </button>
              <span>{item.quantity}</span>
              <button
                type="button"
                className="cursor-pointer text-lg disabled:opacity-20"
                onClick={() => handleItemQuantity(item.id, "i")}
                disabled={item.quantity === Math.min(stockNumber, 2) || stockNumber < 1}
              >
                +
              </button>
            </div>
            <p className={`font-semibold text-start ${isMielPage ? 'miel-text-price' : ''}`} style={isMielPage ? { color: '#d4820a' } : {}}>
              {Number(currentPrice * item.quantity).toLocaleString("ar-DZ")} دج
            </p>
          </div>
        </div>
      </div>
    );
  };

  const renderSimpleQuantity = () => (
    <div className={`${isMielPage ? 'bg-stone-100/50' : 'bg-cream/70'} rounded-2xl p-4 sm:p-5`} style={isMielPage ? { backgroundColor: 'rgba(245, 245, 244, 0.5)' } : {}}>
      <div className="flex items-center justify-between gap-4">
        <p className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>الكمية</p>
        <div className={`flex items-center justify-between w-32 rounded-full border bg-white py-1.5 px-3 ${isMielPage ? 'border-stone-300' : 'border-cream-2'}`} style={isMielPage ? { borderColor: '#d6d3d1' } : {}}>
          <button
            type="button"
            className="cursor-pointer text-lg disabled:opacity-20"
            onClick={() => handleQuantity("d")}
            disabled={quantity === 1}
          >
            -
          </button>
          <span>{quantity}</span>
          <button
            type="button"
            className="cursor-pointer text-lg disabled:opacity-20"
            onClick={() => handleQuantity("i")}
            disabled={quantity === Math.min(stockNumber, 2) || stockNumber < 1}
          >
            +
          </button>
        </div>
        <p className={`font-semibold text-start ${isMielPage ? 'miel-text-price' : ''}`} style={isMielPage ? { color: '#d4820a' } : {}}>
          {Number(currentPrice * quantity).toLocaleString("ar-DZ")} دج
        </p>
      </div>
    </div>
  );

  return (
    <form
      id={CHECKOUT_FORM_ID}
      onSubmit={handleSubmit}
      className="flex flex-col gap-6 scroll-mt-28"
      noValidate
    >
      {hasOffers && (
        <ProductOffers
          offers={offers}
          selectedOfferId={selectedOffer?.id || selectedOffer?.documentId || null}
          onOfferSelect={handleOfferSelect}
          isMielPage={isMielPage}
        />
      )}

      {hasVariants ? (
        <>
          <h3 className={`text-lg font-semibold text-center ${isMielPage ? 'miel-text-primary' : 'text-ink'}`} style={isMielPage ? { color: '#1c1917' } : {}}>اختر المنتجات</h3>

          {items.map((item, index) => renderOrderItem(item, index))}

          <button
            type="button"
            onClick={handleAddItem}
            className="w-full rounded-xl border-2 border-dashed border-brand text-brand py-3 px-4 font-semibold tracking-wide hover:bg-brand hover:text-white transition"
          >
            + إضافة قطعة أخرى
          </button>
        </>
      ) : (
        renderSimpleQuantity()
      )}

      <h3 className={`text-lg font-semibold text-center mt-4 ${isMielPage ? 'miel-text-primary' : 'text-ink'}`} style={isMielPage ? { color: '#1c1917' } : {}}>املأ الإستمارة</h3>

      <div className="flex flex-col gap-4">
        {successMessage && (
          <div
            role="status"
            className="rounded-xl bg-cream px-4 py-3 text-sm text-brand"
          >
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div
            role="alert"
            className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-600"
          >
            {errorMessage}
          </div>
        )}

        <div className="flex flex-col gap-2">
          <label htmlFor="name" className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>
            الاسم الكامل
          </label>
          <div className="relative">
            <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted/50" />
            <input
              ref={nameRef}
              id="name"
              name="name"
              type="text"
              required
              placeholder="الاسم واللقب"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className={`${isMielPage ? 'miel-field-input' : 'field-input'} pr-10 border border-stone-200 rounded-lg focus:border-[#fbad25] focus:ring-2 focus:ring-[#fbad25]/20 ${errors.name ? "border-red-500 ring-1 ring-red-500" : ""}`}
              style={isMielPage ? { border: '1px solid #d6d3d1', borderRadius: '0.75rem', padding: '0.8rem 1rem', background: '#fff', outline: 'none', fontSize: '0.9rem' } : {}}
            />
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <label htmlFor="phone" className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>
            رقم الهاتف
          </label>
          <div className="relative">
            <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted/50" />
            <input
              ref={phoneRef}
              id="phone"
              name="phone"
              type="tel"
              required
              inputMode="tel"
              placeholder="05XXXXXXXX"
              value={form.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              className={`${isMielPage ? 'miel-field-input' : 'field-input'} pr-10 border border-stone-200 rounded-lg focus:border-[#fbad25] focus:ring-2 focus:ring-[#fbad25]/20 transition-all duration-300 ease-in-out ${errors.phone ? "border-red-400 ring-1 ring-red-400" : ""}`}
              style={isMielPage ? { border: '1px solid #d6d3d1', borderRadius: '0.75rem', padding: '0.8rem 1rem', background: '#fff', outline: 'none', fontSize: '0.9rem' } : {}}
            />
          </div>
          {errors.phone && (
            <div className="flex items-center gap-2 text-xs text-red-500 mt-1">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span>يرجى إدخال رقم هاتف مكتمل مكون من 10 أرقام</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="wilaya" className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>
              الولاية
            </label>
            <div className="relative">
              <Map className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted/50" />
              <select
                ref={wilayaRef}
                id="wilaya"
                name="wilaya"
                required
                value={form.wilaya}
                onChange={(e) => handleChange("wilaya", e.target.value)}
                className={`${isMielPage ? 'miel-field-input' : 'field-input'} pr-10 appearance-none border border-stone-200 rounded-lg focus:border-[#fbad25] focus:ring-2 focus:ring-[#fbad25]/20 ${errors.wilaya ? "border-red-500 ring-1 ring-red-500" : ""}`}
                style={isMielPage ? { border: '1px solid #d6d3d1', borderRadius: '0.75rem', padding: '0.8rem 1rem', background: '#fff', outline: 'none', fontSize: '0.9rem' } : {}}
              >
                <option value="">اختر الولاية</option>
                {ALGERIA_WILAYAS.map((wilaya) => (
                  <option key={wilaya.code} value={wilaya.nameAscii}>
                    {wilaya.code} — {wilaya.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="baladia" className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>
              البلدية
            </label>
            <div className="relative">
              <Map className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted/50" />
              <select
                ref={baladiaRef}
                id="baladia"
                name="baladia"
                required
                disabled={!form.wilaya}
                value={form.baladia}
                onChange={(e) => handleChange("baladia", e.target.value)}
                className={`${isMielPage ? 'miel-field-input' : 'field-input'} pr-10 appearance-none border border-stone-200 rounded-lg focus:border-[#fbad25] focus:ring-2 focus:ring-[#fbad25]/20 disabled:bg-cream disabled:cursor-not-allowed ${errors.baladia ? "border-red-500 ring-1 ring-red-500" : ""}`}
                style={isMielPage ? { border: '1px solid #d6d3d1', borderRadius: '0.75rem', padding: '0.8rem 1rem', background: '#fff', outline: 'none', fontSize: '0.9rem' } : {}}
              >
                <option value="">
                  {form.wilaya ? "اختر البلدية" : "اختر الولاية أولاً"}
                </option>
                {communes.map((commune) => (
                  <option key={commune.nameAscii} value={commune.nameAscii}>
                    {commune.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

      </div>

      <div className={`${isMielPage ? 'bg-stone-100/50 border-stone-200' : 'bg-cream/70 border-cream-2'} rounded-2xl border p-4 sm:p-5 flex flex-col gap-3`} style={isMielPage ? { backgroundColor: 'rgba(245, 245, 244, 0.5)', borderColor: '#e7e5e4' } : {}}>
        {!hasValidOffers && (
          <div className="flex items-center justify-between gap-4">
            <p className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>سعر العرض</p>
            <p className={`font-semibold text-start ${isMielPage ? 'miel-text-price' : ''}`} style={isMielPage ? { color: '#d4820a' } : {}}>
              {Number(currentPrice).toLocaleString("ar-DZ")} دج
            </p>
          </div>
        )}
        <div className="flex items-center justify-between gap-4">
          <p className={`text-sm ${isMielPage ? 'miel-text-secondary' : 'text-muted'}`} style={isMielPage ? { color: '#57534e' } : {}}>مصاريف التوصيل للمنزل</p>
          {!selectedWilaya ? (
            <p className="font-semibold text-start">---</p>
          ) : deliveryPrice?.noDelivery ? (
            <p className="font-semibold text-red-600 text-start">
              التوصيل غير متاح
            </p>
          ) : (
            <p className="font-semibold text-start">
              {deliveryCost > 0 ? `${Number(deliveryCost).toLocaleString("ar-DZ")} دج` : "مجاني"}
            </p>
          )}
        </div>
        <div className={`flex items-center justify-between gap-4 border-t ${isMielPage ? 'border-stone-200' : 'border-cream-2'} pt-3`} style={isMielPage ? { borderColor: '#e7e5e4' } : {}}>
          <p className={`text-sm font-semibold ${isMielPage ? 'miel-text-primary' : 'text-ink'}`} style={isMielPage ? { color: '#1c1917' } : {}}>الإجمالي (شامل التوصيل)</p>
          <p className={`font-bold text-lg text-start ${isMielPage ? 'miel-text-success' : 'text-emerald-800'}`} style={isMielPage ? { color: '#047857' } : {}}>
            {Number(totalAmount).toLocaleString("ar-DZ")} دج
          </p>
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting || stockNumber < 1 || deliveryPrice?.noDelivery}
        className={`form-shake w-full rounded-xl py-4 px-4 font-semibold tracking-wide transition disabled:cursor-not-allowed disabled:opacity-75 ${isMielPage ? 'text-white' : 'bg-brand text-white hover:bg-brand-soft'}`}
        style={isMielPage ? { backgroundColor: '#fbad25', color: '#1c1917' } : {}}
        onMouseEnter={(e) => {
          if (isMielPage) {
            e.currentTarget.style.backgroundColor = '#d4820a';
          }
        }}
        onMouseLeave={(e) => {
          if (isMielPage) {
            e.currentTarget.style.backgroundColor = '#fbad25';
          }
        }}
      >
        {deliveryPrice?.noDelivery ? "التوصيل غير متاح لهذه الولاية" : isSubmitting ? "جاري الإرسال..." : "إشتري الآن"}
      </button>
    </form>
  );
};

export default ProductOrderForm;
