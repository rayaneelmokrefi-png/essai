"use client";

import { useEffect, useState } from "react";
import { CHECKOUT_FORM_ID } from "@/lib/constants";
import { getWhatsAppUrl } from "@/lib/whatsapp";

export default function ProductFloatingBar({
  productName,
  isMielPage = false,
}: {
  productName: string;
  isMielPage?: boolean;
}) {
  const [formInView, setFormInView] = useState(true);
  const whatsappUrl = getWhatsAppUrl(
    `مرحبا، أريد طلب: ${productName}`,
  );

  useEffect(() => {
    const form = document.getElementById(CHECKOUT_FORM_ID);
    if (!form) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setFormInView(entry.isIntersecting);
      },
      { threshold: 0.12 },
    );

    observer.observe(form);
    return () => observer.disconnect();
  }, []);

  const scrollToForm = () => {
    document
      .getElementById(CHECKOUT_FORM_ID)
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  if (formInView) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
      <div className="page-wrap pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2">
        <div className={`pointer-events-auto flex items-center gap-3 rounded-2xl border px-3 py-3 backdrop-blur-md shadow-[0_-8px_30px_rgb(0,0,0,0.12)] ${isMielPage ? 'border-stone-200 bg-white/95' : 'border-cream-2 bg-white/95'}`}>
          {whatsappUrl ? (
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noreferrer"
              aria-label="WhatsApp"
              className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-white shadow-md ${isMielPage ? 'bg-[#25D366]' : 'bg-[#25D366]'}`}
            >
              <WhatsAppIcon />
            </a>
          ) : null}

          <button
            type="button"
            onClick={scrollToForm}
            className={`form-shake flex-1 rounded-xl py-3.5 px-4 font-semibold tracking-wide ${isMielPage ? 'text-white' : 'bg-brand text-white'}`}
            style={isMielPage ? { backgroundColor: '#fbad25', color: '#1c1917' } : {}}
            onMouseEnter={(e) => {
              if (isMielPage) {
                e.currentTarget.style.backgroundColor = '#d4820a';
              }
            }}
            onMouseLeave={(e) => {
              if (isMielPage) {
                e.currentTarget.style.backgroundColor = '#fbad25';
              }
            }}
          >
            إشتري الآن
          </button>
        </div>
      </div>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor" aria-hidden>
      <path d="M19.05 4.91A9.84 9.84 0 0 0 12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.28-1.38a9.9 9.9 0 0 0 4.76 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.91-7.01Zm-7.01 15.24h-.01a8.2 8.2 0 0 1-4.18-1.15l-.3-.18-3.13.82.84-3.05-.2-.31a8.2 8.2 0 0 1-1.26-4.37c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.42 5.83c0 4.55-3.7 8.23-8.25 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.12-.17.25-.64.8-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.24-1.47-1.38-1.72-.15-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.84-.2-.48-.41-.42-.56-.42h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.24 3.74.59.26 1.06.41 1.42.52.6.19 1.14.16 1.57.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.23-.17-.48-.29Z" />
    </svg>
  );
}
