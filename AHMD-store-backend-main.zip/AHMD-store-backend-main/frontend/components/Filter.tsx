"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";

const Filter = () => {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { replace } = useRouter();

  const handleFilterChange = (
    e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>
  ) => {
    const { name, value } = e.target;
    if (!name) return;

    const params = new URLSearchParams(searchParams.toString());

    if (value) {
      params.set(name, value);
    } else {
      params.delete(name);
    }

    replace(`${pathname}?${params.toString()}`);
  };

  const selectClass =
    "py-2.5 px-4 rounded-full text-xs font-medium bg-white text-gray-700 border border-gray-200 min-h-[44px] focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all hover:border-gray-300";

  const inputClass =
    "py-2.5 px-4 rounded-full text-sm font-medium bg-white text-gray-700 border border-gray-200 min-h-[44px] focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all hover:border-gray-300";

  return (
    <div className="flex gap-3 flex-wrap">
      <input
        type="number"
        name="min"
        placeholder="أدنى سعر"
        className={inputClass}
        onChange={handleFilterChange}
      />

      <input
        type="number"
        name="max"
        placeholder="أعلى سعر"
        className={inputClass}
        onChange={handleFilterChange}
      />

      <select
        name="sort"
        className={selectClass}
        onChange={handleFilterChange}
      >
        <option value="">الترتيب</option>
        <option value="desc createdAt">الأحدث</option>
        <option value="asc price">السعر: من الأقل للأعلى</option>
        <option value="desc price">السعر: من الأعلى للأقل</option>
      </select>
    </div>
  );
};

export default Filter;
