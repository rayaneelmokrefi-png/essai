import Link from "next/link";
import BrandLogo from "./BrandLogo";
import Menu from "./Menu";
import SearchBar from "./SearchBar";
import { NAV_LINKS } from "@/lib/site";

const Navbar = () => {
  return (
    <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-md">
      <header className="h-[4.25rem] md:h-20 border-b border-cream-2">
        <nav className="page-wrap h-full grid grid-cols-3 items-center">
          <div className="flex items-center gap-8">
            <Menu />
            <div className="hidden md:flex items-center gap-7 text-[13px] tracking-[0.06em] text-ink/80">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="hover:text-brand transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
          <div className="flex justify-center">
            <BrandLogo />
          </div>
          <SearchBar />
        </nav>
      </header>
    </div>
  );
};

export default Navbar;
