"use client";

import { Search, X, Clock, ArrowRight } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useEffect, useRef } from "react";

const SearchBar = () => {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  
  const formRef = useRef<HTMLFormElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load search history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("searchHistory");
    if (saved) {
      setSearchHistory(JSON.parse(saved));
    }
  }, []);

  // Save search history to localStorage
  const saveToHistory = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    
    const updated = [trimmed, ...searchHistory.filter((h) => h !== trimmed)].slice(0, 5);
    setSearchHistory(updated);
    localStorage.setItem("searchHistory", JSON.stringify(updated));
  };

  // Mock auto-suggestions (replace with actual API call)
  const generateSuggestions = (input: string) => {
    if (!input) return [];
    const mockProducts = ["قميص", "بنطال", "حذاء", "جاكيت", "فستان", "حقيبة", "ساعة", "نظارة"];
    return mockProducts.filter((p) => p.toLowerCase().includes(input.toLowerCase()));
  };

  // Update suggestions when query changes
  useEffect(() => {
    if (query.length > 0) {
      setSuggestions(generateSuggestions(query));
      setShowDropdown(true);
    } else {
      setSuggestions([]);
      setShowDropdown(searchHistory.length > 0);
    }
  }, [query, searchHistory.length]);

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (query) {
      saveToHistory(query);
      router.push(`/list?name=${encodeURIComponent(query.trim())}`);
      setOpen(false);
      setShowDropdown(false);
      setQuery("");
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    saveToHistory(suggestion);
    router.push(`/list?name=${encodeURIComponent(suggestion.trim())}`);
    setOpen(false);
    setShowDropdown(false);
    setQuery("");
  };

  const handleClear = () => {
    setQuery("");
    inputRef.current?.focus();
  };

  const handleClose = () => {
    setOpen(false);
    setShowDropdown(false);
    setQuery("");
  };

  // Close on ESC key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) {
        handleClose();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [open]);

  // Focus input when opened
  useEffect(() => {
    if (open && inputRef.current) {
      inputRef.current.focus();
    }
  }, [open]);

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (formRef.current && !formRef.current.contains(e.target as Node) && 
          dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        handleClose();
      }
    };
    if (open) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  return (
    <div className="relative flex items-center justify-end">
      {/* Backdrop overlay for mobile */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={handleClose}
        />
      )}
      
      {open && (
        <div className="fixed inset-x-0 top-0 z-50 bg-white px-4 py-3 flex items-center gap-3 shadow-lg md:relative md:inset-auto md:bg-transparent md:shadow-none md:px-0 md:py-0 transition-all duration-300 ease-in-out">
          <form
            ref={formRef}
            className="relative flex-1 transition-all duration-300 ease-in-out"
            onSubmit={handleSearch}
          >
            <div className="relative flex items-center bg-white border-2 border-gray-200 rounded-full shadow-lg focus-within:border-brand focus-within:shadow-xl transition-all duration-300">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 stroke-[1.4] text-muted-foreground pointer-events-none" />
              <input
                ref={inputRef}
                type="text"
                name="name"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="بحث عن المنتجات..."
                className="w-full bg-transparent outline-none text-sm pr-12 pl-12 py-3 placeholder:text-muted-foreground"
              />
              {query && (
                <button
                  type="button"
                  aria-label="مسح"
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-1 cursor-pointer text-muted-foreground hover:text-ink transition-colors"
                  onClick={handleClear}
                >
                  <X className="w-4 h-4 stroke-[1.4]" />
                </button>
              )}
            </div>

            {/* Dropdown for suggestions and history */}
            {showDropdown && (suggestions.length > 0 || searchHistory.length > 0) && (
              <div
                ref={dropdownRef}
                className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden animate-in slide-in-from-top-2 duration-200"
              >
                {suggestions.length > 0 && (
                  <div className="p-2">
                    <p className="px-3 py-2 text-xs font-semibold text-muted-foreground">اقتراحات</p>
                    {suggestions.map((suggestion, index) => (
                      <button
                        key={`suggestion-${index}`}
                        type="button"
                        className="w-full flex items-center gap-3 px-3 py-2 text-right hover:bg-gray-50 rounded-lg transition-colors group"
                        onClick={() => handleSuggestionClick(suggestion)}
                      >
                        <Search className="w-4 h-4 stroke-[1.4] text-muted-foreground group-hover:text-brand transition-colors" />
                        <span className="text-sm">{suggestion}</span>
                        <ArrowRight className="w-4 h-4 stroke-[1.4] text-muted-foreground mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))}
                  </div>
                )}
                
                {suggestions.length > 0 && searchHistory.length > 0 && (
                  <div className="border-t border-gray-100" />
                )}
                
                {searchHistory.length > 0 && (
                  <div className="p-2">
                    <div className="flex items-center justify-between px-3 py-2">
                      <p className="text-xs font-semibold text-muted-foreground">عمليات البحث الأخيرة</p>
                      <button
                        type="button"
                        className="text-xs text-muted-foreground hover:text-brand transition-colors"
                        onClick={() => {
                          setSearchHistory([]);
                          localStorage.removeItem("searchHistory");
                        }}
                      >
                        مسح
                      </button>
                    </div>
                    {searchHistory.map((item, index) => (
                      <button
                        key={`history-${index}`}
                        type="button"
                        className="w-full flex items-center gap-3 px-3 py-2 text-right hover:bg-gray-50 rounded-lg transition-colors group"
                        onClick={() => handleSuggestionClick(item)}
                      >
                        <Clock className="w-4 h-4 stroke-[1.4] text-muted-foreground group-hover:text-brand transition-colors" />
                        <span className="text-sm">{item}</span>
                        <ArrowRight className="w-4 h-4 stroke-[1.4] text-muted-foreground mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </form>
          
          <button
            type="button"
            aria-label="إغلاق"
            className="p-2 cursor-pointer text-ink hover:bg-gray-100 rounded-full transition-colors flex-shrink-0"
            onClick={handleClose}
          >
            <X className="w-5 h-5 stroke-[1.4]" />
          </button>
        </div>
      )}
      
      {!open && (
        <button
          type="button"
          aria-label="بحث"
          className="p-2 cursor-pointer text-ink hover:bg-gray-100 rounded-full transition-all duration-200 hover:scale-105"
          onClick={() => setOpen(true)}
        >
          <Search className="w-5 h-5 stroke-[1.4]" />
        </button>
      )}
    </div>
  );
};

export default SearchBar;
