"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";

const SIZE = {
  sm: "text-xl",
  md: "text-[1.65rem] md:text-[1.85rem]",
  lg: "text-3xl md:text-4xl",
};

export default function BrandLogo({
  size = "md",
  light = false,
}: {
  size?: keyof typeof SIZE;
  light?: boolean;
}) {
  const pathname = usePathname();
  const isMielPage = pathname.toLowerCase().includes("miel");

  return (
    <Link
      href="/"
      className={`leading-none ${light ? "text-white" : "text-ink"}`}
    >
      {isMielPage ? (
        <Image
          src="/miel.PNG"
          alt="Miel Logo"
          width={50}
          height={50}
          className="object-contain"
        />
      ) : (
        <span className={`${SIZE[size]}`}>
          <span className="font-brand italic">el</span>
          <span className="font-medium tracking-tight">Nahla</span>
        </span>
      )}
    </Link>
  );
}
