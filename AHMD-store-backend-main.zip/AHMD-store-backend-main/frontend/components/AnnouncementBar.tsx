const AnnouncementBar = () => {
  const messages = [
    "🚚 توصيل سريع لجميع 58 ولاية",
    "🤝 الدفع عند الاستلام",
    "✨ منتجات عالية الجودة",
    "⭐ خدمة عملاء متميزة",
  ];

  return (
    <div className="bg-emerald-900 text-white py-2 text-xs font-medium overflow-hidden whitespace-nowrap">
      <div className="marquee inline-block">
        {messages.map((message, index) => (
          <span key={index} className="mx-8">
            {message}
          </span>
        ))}
        {messages.map((message, index) => (
          <span key={`duplicate-${index}`} className="mx-8">
            {message}
          </span>
        ))}
      </div>
    </div>
  );
};

export default AnnouncementBar;
