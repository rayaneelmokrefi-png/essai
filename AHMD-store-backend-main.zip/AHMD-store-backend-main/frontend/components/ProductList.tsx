import Pagination from "./Pagination";
import ProductCard from "./ProductCard";
import { STRAPI_URL, unwrapStrapi } from "@/lib/strapi";

const PRODUCT_PER_PAGE = 8;

const ProductList = async ({
  categoryId,
  limit,
  searchParams,
  products: providedProducts,
}: {
  categoryId?: string;
  limit?: number;
  searchParams?: any;
  products?: any[];
}) => {
  const page = searchParams?.page ? parseInt(String(searchParams.page)) : 1;
  const pageSize = limit || PRODUCT_PER_PAGE;

  let products: any[] = providedProducts || [];
  let paginationMeta: any = {};

  if (!providedProducts) {
    const queryParams = new URLSearchParams();
    queryParams.append("populate", "*");
    queryParams.append("pagination[page]", page.toString());
    queryParams.append("pagination[pageSize]", pageSize.toString());

    if (searchParams?.name) {
      queryParams.append("filters[title][$containsi]", String(searchParams.name));
    }

    const categorySlug =
      searchParams?.cat && searchParams.cat !== "all-products"
        ? String(searchParams.cat)
        : undefined;

    if (categoryId && categoryId !== "all" && categoryId !== "all-products") {
      queryParams.append("filters[category][id][$eq]", String(categoryId));
    } else if (categorySlug) {
      queryParams.append("filters[category][slug][$eq]", categorySlug);
    }

    if (searchParams?.min) {
      queryParams.append("filters[price][$gte]", String(searchParams.min));
    }

    if (searchParams?.max) {
      queryParams.append("filters[price][$lte]", String(searchParams.max));
    }

    if (searchParams?.sort) {
      const [sortType, sortBy] = String(searchParams.sort).split(" ");
      const field = sortBy === "lastUpdated" ? "createdAt" : sortBy || "createdAt";
      queryParams.append("sort[0]", `${field}:${sortType || "desc"}`);
    }

    try {
      let res = await fetch(
        `${STRAPI_URL}/api/products?${queryParams.toString()}`,
        { cache: "no-store" },
      );

      if (!res.ok) {
        queryParams.delete("filters[category][id][$eq]");
        queryParams.delete("filters[category][slug][$eq]");
        res = await fetch(
          `${STRAPI_URL}/api/products?${queryParams.toString()}`,
          { cache: "no-store" },
        );
      }

      const data = await res.json();
      products = data.data || [];
      paginationMeta = data.meta?.pagination || {};
    } catch (err) {
      console.error("Error fetching products from Strapi:", err);
    }
  }

  return (
    <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
      {products.map((product: any) => {
        const item = unwrapStrapi(product);
        return (
          <ProductCard
            product={item}
            key={product.id || item.documentId || item.id}
          />
        );
      })}
      {searchParams?.cat || searchParams?.name ? (
        <Pagination
          currentPage={paginationMeta.page || 1}
          hasPrev={(paginationMeta.page || 1) > 1}
          hasNext={(paginationMeta.page || 1) < (paginationMeta.pageCount || 1)}
        />
      ) : null}
    </div>
  );
};

export default ProductList;
