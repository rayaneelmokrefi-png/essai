import { Truck, Handshake, Headphones } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: Truck,
      title: "توصيل سريع من 1-3 أيام",
      description: "طلبك يصلك بخف ورعاية",
    },
    {
      icon: Handshake,
      title: "تخلص كي توصلك السلعة",
      description: "إشتري بكل ثقة وأمان",
    },
    {
      icon: Headphones,
      title: "خدمة الزبائن VIP",
      description: "من 9 صباحاً - 8 مساءً ما عدا الجمعة",
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-2 p-3 border border-emerald-100 rounded-2xl my-6" style={{ backgroundColor: '#f4f6f4' }}>
      {features.map((feature, index) => {
        const Icon = feature.icon;
        return (
          <div
            key={index}
            className="flex flex-col items-center text-center gap-1"
            style={{ backgroundColor: '#f4f6f4' }}
          >
            <Icon className="w-5 h-5" strokeWidth={2} style={{ color: '#059669' }} />
            <h3 className="text-xs md:text-sm font-bold text-gray-800">{feature.title}</h3>
            <p className="text-[10px] md:text-xs text-gray-500">{feature.description}</p>
          </div>
        );
      })}
    </div>
  );
};

export default FeaturesSection;
