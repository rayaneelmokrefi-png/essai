"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";

const Pagination = ({
  currentPage,
  hasPrev,
  hasNext,
}: {
  currentPage: number;
  hasPrev: boolean;
  hasNext: boolean;
}) => {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { replace } = useRouter();

  const createPageUrl = (pageNumber: number) => {
    const params = new URLSearchParams(searchParams);
    params.set("page", pageNumber.toString());
    replace(`${pathname}?${params.toString()}`);
  };

  return (
    <div className="mt-12 col-span-full flex justify-between w-full">
      <button
        className="btn-primary w-28 disabled:opacity-40"
        disabled={!hasPrev}
        onClick={() => createPageUrl(currentPage - 1)}
      >
        السابق
      </button>
      <button
        className="btn-primary w-28 disabled:opacity-40"
        disabled={!hasNext}
        onClick={() => createPageUrl(currentPage + 1)}
      >
        التالي
      </button>
    </div>
  );
};

export default Pagination;