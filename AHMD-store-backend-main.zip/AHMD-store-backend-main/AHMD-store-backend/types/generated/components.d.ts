import type { Schema, Struct } from '@strapi/strapi';

export interface ProductOffer extends Struct.ComponentSchema {
  collectionName: 'components_product_offers';
  info: {
    displayName: 'offer';
    icon: 'priceTag';
  };
  attributes: {
    badge: Schema.Attribute.String;
    isDefault: Schema.Attribute.Boolean;
    price: Schema.Attribute.Decimal;
    title: Schema.Attribute.String;
  };
}

declare module '@strapi/strapi' {
  export namespace Public {
    export interface ComponentSchemas {
      'product.offer': ProductOffer;
    }
  }
}
