/**
 * black-list router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::black-list.black-list');
