/**
 * black-list service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::black-list.black-list');
