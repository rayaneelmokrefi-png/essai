/**
 * black-list controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::black-list.black-list');
