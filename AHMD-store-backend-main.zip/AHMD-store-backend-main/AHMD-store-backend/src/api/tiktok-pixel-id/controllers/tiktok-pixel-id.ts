/**
 * tiktok-pixel-id controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::tiktok-pixel-id.tiktok-pixel-id');
