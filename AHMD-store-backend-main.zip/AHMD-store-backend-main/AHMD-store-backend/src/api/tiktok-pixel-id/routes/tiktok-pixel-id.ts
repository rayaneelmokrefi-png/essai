/**
 * tiktok-pixel-id router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::tiktok-pixel-id.tiktok-pixel-id');
