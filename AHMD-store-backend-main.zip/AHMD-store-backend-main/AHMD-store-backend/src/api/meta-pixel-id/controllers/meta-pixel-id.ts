/**
 * meta-pixel-id controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::meta-pixel-id.meta-pixel-id');
