/**
 * meta-pixel-id service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::meta-pixel-id.meta-pixel-id');
