/**
 * meta-pixel-id router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::meta-pixel-id.meta-pixel-id');
